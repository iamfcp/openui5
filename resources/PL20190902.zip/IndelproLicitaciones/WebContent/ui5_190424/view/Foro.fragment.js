sap.ui.jsfragment(sap.ui.getCore().AppContext.version+".view.Foro", {
    postMessage: function(oController, message, idPregunta) {
		var textos = [
		              ["Su mensaje ha sido recibido y será revisado y respondido a la brevedad", "Your message has been received and will be responded shortly"],
		              ["Ocurrió un error de comunicación", "Server error"],
		              ["Éxito", "Success"],
		];        
    	var model = oController.getView().getModel();
    	var nl = model.getProperty("/numeroLicitacion");
        var data = {data: {numeroLicitacion: nl, mensaje: message, idPregunta: idPregunta, 
        	idArchivo: oController.idArchivoForo, archivo: oController.archivoForo}};
        var url = idPregunta === null ? sap.ui.getCore().AppContext.path + "/pregunta.action": sap.ui.getCore().AppContext.path + "/respuesta.action"; 
        $.ajax({
            url: url,
            type: "POST",
            data: JSON.stringify(data),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(data) {
                sap.ui.core.BusyIndicator.hide();
        		sap.ui.commons.MessageBox.show(textos[0][oController.lang],
                        sap.ui.commons.MessageBox.Icon.SUCCESS,
                        textos[2][oController.lang],
                        [sap.ui.commons.MessageBox.Action.OK],
                        function(){
//        					var oModelForo = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/foro.action?numeroLicitacion="+nl);
//        					sap.ui.getCore().byId("tableForo").setModel(oModelForo);
        					sap.ui.getCore().getElementById('dialogForoEnET').destroy();
        				}, sap.ui.commons.MessageBox.Action.OK);
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
        		sap.ui.commons.MessageBox.show(textos[1][oController.lang],
                        sap.ui.commons.MessageBox.Icon.ERROR,
                        "Error",
                        [sap.ui.commons.MessageBox.Action.OK],
                        '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },
    
    createContent: function(oController) {
		oController.idArchivoForo = "";
		oController.archivoForo = "";

        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "100%",
            height: "90%",
        });
        var model = oController.getView().getModel();
    	var nl = model.getProperty("/numeroLicitacion");
		var textos = [
		              ["Enviar", "Post"],
		              ["Responder", "Reply"],
		              ["No seleccionó un mensaje para responder", "No message selected to reply"],
		];
    	var oModelForo = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/foro.action?numeroLicitacion="+nl);
//    	var oTable = new sap.ui.table.TreeTable("tableForo", {
//            visibleRowCount: sap.ui.table.VisibleRowCountMode.Auto,
//            selectionMode: sap.ui.table.SelectionMode.Single,
//            columnHeaderVisible: false,
//            noData: "-",
//            rowHeight: 50,
//        	expandFirstLevel: true,
//        });
//    	oTable.addColumn(new sap.ui.table.Column({
//            label: new sap.ui.commons.Label({text: ""}),
//            template: new sap.ui.commons.TextArea({editable: false, wrapping: sap.ui.core.Wrapping.HardInserts, width: '95%'}).bindProperty("value", "TEXTO"),
//            width : '97%',
//			flexible: true,
//			resizable: true,
//			autoResizable: true,
//        }));
//    	oTable.addColumn(new sap.ui.table.Column({
//            label: new sap.ui.commons.Label({text: "Descargar"}),
//            hAlign: sap.ui.core.HorizontalAlign.Center,
//            template: new sap.ui.core.Icon({
//                src: sap.ui.core.IconPool.getIconURI("download"),
//                press: function () {
//                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
//                			this.getBindingContext().getProperty("ID_ANEXO") + 
//                			"&fileName=" + this.getBindingContext().getProperty("NOMBRE_ANEXO"), 
//                			"_archivo" + this.getBindingContext().getProperty("ID_ANEXO"),
//                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
//                }
//            }).bindProperty("visible","TIENE_ANEXO")
//        }));
//		oTable.setModel(oModelForo);
//		oTable.bindRows("/data/foro");
//    	oLayout.createRow(oTable);

    	var oListForo = new sap.m.List({
		});
		oListForo.setModel(oModelForo);
		var oItemListForo = new sap.m.FeedListItem({
			senderPress: function(oEvent) {
	    		oController.preguntaAResponder = oEvent.getSource().getBindingContext().getProperty("ID_PREGUNTA");
		    },
			iconPress: function(oEvent) {
				if(!oEvent.getSource().getBindingContext().getProperty("TIENE_ANEXO"))
					return;
            	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
            			oEvent.getSource().getBindingContext().getProperty("ID_ANEXO") + 
            			"&fileName=" + oEvent.getSource().getBindingContext().getProperty("NOMBRE_ANEXO"), 
            			"_archivo" + oEvent.getSource().getBindingContext().getProperty("ID_ANEXO"),
            			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
		    }
		});
		if(oController.modo !== "p")
			oItemListForo.bindProperty("sender", "SENDER");
		oItemListForo.bindProperty("text", "TEXTO");
		oItemListForo.bindProperty("icon", "ICON");
		oListForo.bindItems("/data/foro", oItemListForo);
    	oLayout.createRow(oListForo);
    	
    	var self = this;
	    var tComentario = new sap.ui.commons.TextArea({value: "", width: "500px", rows: 2, MaxLength:7000});
	    var btnPost = new sap.ui.commons.Button({text: textos[0][oController.lang], 
	    	press: function() {
	    		self.postMessage(oController, tComentario.getValue(), null);
	    		tComentario.setValue("");
	    	}})
	    var btnReply = new sap.ui.commons.Button({text: textos[1][oController.lang], press: function() {
    		console.log(oController.preguntaAResponder);
	    	if(oController.preguntaAResponder)
	    		self.postMessage(
	    				oController, 
	    				tComentario.getValue(), 
	    				oController.preguntaAResponder);
	    	else
	    		sap.ui.commons.MessageBox.alert(textos[2][oController.lang], null, "Error");
//	    	if(oTable.getSelectedIndex() >= 0)
//	    		self.postMessage(
//	    				oController, 
//	    				tComentario.getValue(), 
//	    				oTable.getContextByIndex(oTable.getSelectedIndex()).getObject().ID_PREGUNTA);
//	    	else
//	    		sap.ui.commons.MessageBox.alert(textos[2][oController.lang], null, "Error");
	    	}});
	    
        var archivoAnexo = 
		     new sap.ui.unified.FileUploader({
	        	 uploadOnChange: true,
	        	 name: "archivoUno",
	        	 placeholder: "Incluir anexo",
	        	 fileType: ["pdf", "xls", "xlsx"],
	        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
	        	 uploadComplete: function(oControlEvent) {
	        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
	        		 console.log(oControlEvent.getSource().getValue());
	        		 console.log(oControlEvent.getParameters().response.trim());
	        		 var res = oControlEvent.getParameters().response.trim().split('|');
	        		 oController.idArchivoForo = res[1];
	        		 oController.archivoForo = res[2].replace(/[^a-zA-Z.0-9]+/g,'');
	        	 }

	         }).attachTypeMissmatch(null,
	        		 function() {
       	 		sap.ui.commons.MessageBox.alert("Solo se permiten archivos de tipo PDF, XLS, XLSX", null, "Error"); 
       		 }, null);
        
	    if(oController.modo === "p")
		    oLayout.createRow(new sap.m.FlexBox({
		    	width: "650px",
	            alignItems: sap.m.FlexAlignItems.Stretch,
	            justifyContent: sap.m.FlexJustifyContent.SpaceAround,
	            items: [tComentario, btnPost],
	            direction: "Row"
	        }));
	    else {
		    oLayout.createRow(new sap.m.FlexBox({
		    	width: "650px",
	            alignItems: sap.m.FlexAlignItems.Stretch,
	            justifyContent: sap.m.FlexJustifyContent.SpaceAround,
	            items: [tComentario, btnPost, btnReply],
	            direction: "Row"
	        }));
		    oLayout.createRow(new sap.m.FlexBox({
		    	width: "650px",
	            alignItems: sap.m.FlexAlignItems.Stretch,
	            justifyContent: sap.m.FlexJustifyContent.SpaceAround,
	            items: [archivoAnexo],
	            direction: "Row"
	        }));
	    }
//      var label = new sap.m.Label({text: "Comentario de aprobación"});
//      oLayout.createRow(label);
//      var tComentario = new sap.ui.commons.TextArea({value: "", width: "490px", rows: 10});
//      oLayout.createRow(tComentario);

    	return oLayout;
    }
});