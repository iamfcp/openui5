sap.ui.controller(sap.ui.getCore().AppContext.version+".view.EnvioPropuesta", {
	nombrePropuestaTecnica: '',
	nombrePropuestaEconomica: '',
	idPropuestaTecnica: '',
	idPropuestaEconomica: '',

    onInit: function() {},

    logout: function() {
        var data = {
            "modo": "logout"
        };
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/logout.action",
            type: "POST",
            data: data,
            beforeSend: function(xhr) {
            },
            success: function() {
                location.replace("http://www.indelpro.com");
            }
        });
    },
    
    onAfterRendering: function(oEvent) {
    	jQuery.sap.require("sap.ui.commons.MessageBox");
		var dataJ = {data: {}};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/obtenLicitacionParaProveedor.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var c = sap.ui.getCore().byId("EnvioPropuesta").getController();
                if(dataRet.codigo !== 200) {
    				sap.ui.commons.MessageBox.show(dataRet.mensaje,
    		                sap.ui.commons.MessageBox.Icon.ERROR,
    		                "Error",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                function(){
    							c.logout();
    						}, 
    		                sap.ui.commons.MessageBox.Action.OK);
                }
            	var oModel = c.getView().getModel();
            	if(!oModel) {
            		oModel = new sap.ui.model.json.JSONModel();
            		c.getView().setModel(oModel);
            	}
            	dataRet.data.fechaLimite = sap.ui.getCore().byId("MainAppView").getController().getFormattedDate(dataRet.data.fechaLimite);
            	oModel.setData(dataRet.data);
        		oModel.refresh();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },

    onEnviar: function(data) {
    	data.nombrePropuestaTecnica = this.nombrePropuestaTecnica;
    	data.nombrePropuestaEconomica = this.nombrePropuestaEconomica;
    	data.idPropuestaTecnica = this.idPropuestaTecnica;
    	data.idPropuestaEconomica = this.idPropuestaEconomica;
    	console.log(data);

		var re = /\$|,/g;
		var floatValue = parseFloat(data.importeEstimado.replace(re,''));
		if(data.importeEstimado === '' || isNaN(floatValue) || floatValue <= 1000) {
			sap.ui.commons.MessageBox.show("Ingrese un importe estimado correcto",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incorrectos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}
		data.importeEstimado = floatValue;
//		if(data.idPropuestaTecnica === '') {
//			sap.ui.commons.MessageBox.show("No ha cargado el archivo de propuesta técnica",
//                    sap.ui.commons.MessageBox.Icon.ERROR,
//                    "Datos Incompletos",
//                    [sap.ui.commons.MessageBox.Action.OK],
//                    '', sap.ui.commons.MessageBox.Action.OK);      
//			return;
//		}
//		if(data.idPropuestaEconomica === '') {
//			sap.ui.commons.MessageBox.show("No ha cargado el archivo de propuesta económica",
//                    sap.ui.commons.MessageBox.Icon.ERROR,
//                    "Datos Incompletos",
//                    [sap.ui.commons.MessageBox.Action.OK],
//                    '', sap.ui.commons.MessageBox.Action.OK);      
//			return;
//		}
    	
        sap.ui.core.BusyIndicator.show(0);
        var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/guardaPropuesta.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(data) {
                sap.ui.core.BusyIndicator.hide();
                if(data.codigo && data.codigo == 200) {
            		sap.ui.commons.MessageBox.show("Agradecemos su participación en esta licitación.\nSe le contactará como parte del seguimiento de la misma.",
                            sap.ui.commons.MessageBox.Icon.SUCCESS,
                            "Éxito",
                            [sap.ui.commons.MessageBox.Action.OK],
                            function(){sap.ui.getCore().byId("EnvioPropuesta").getController().logout();}, sap.ui.commons.MessageBox.Action.OK);
                } else {
					sap.ui.commons.MessageBox.show(data.mensaje,
			                sap.ui.commons.MessageBox.Icon.ERROR,
			                "Error",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);      
                }
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
        		sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
                        sap.ui.commons.MessageBox.Icon.ERROR,
                        "Error",
                        [sap.ui.commons.MessageBox.Action.OK],
                        function(){sap.ui.getCore().byId("EnvioPropuesta").getController().logout();}, sap.ui.commons.MessageBox.Action.OK);      
            }
        });


    },
    
});