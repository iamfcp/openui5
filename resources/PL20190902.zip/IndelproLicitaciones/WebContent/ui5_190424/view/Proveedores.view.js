sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.Proveedores", {

    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.Proveedores";
    },
    
    createDialog: function(oController, modo, provAct) {
        var oDialog = new sap.ui.commons.Dialog("dialogCreaProv", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogCreaProv').destroy();
            }
        });
        oDialog.setTitle(modo === 'new'? "Nuevo Proveedor": "Actualizar Proveedor");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            width: "100%"
        });
        var oLabel = new sap.ui.commons.Label( {
            text: 'Número SAP',
            labelFor: oTF
        });
        var oTF = new sap.ui.commons.TextField("tNumeroSAP", {
            tooltip: 'Número SAP',
            editable: modo === 'new',
            width: '150px',
            required: true,
            value: modo !== 'new'? provAct.numeroSAP : ''
        });
        oLayout.createRow(oLabel, oTF);
        var oLabel = new sap.ui.commons.Label( {
            text: 'RFC',
            labelFor: oTF
        });
        var oTF = new sap.ui.commons.TextField("tRFC", {
            tooltip: 'RFC',
            editable: true,
            width: '150px',
            required: true,
            value: modo !== 'new'? provAct.rfc : ''
        });
        oLayout.createRow(oLabel, oTF);
        var oLabel = new sap.ui.commons.Label( {
            text: 'Nombre',
            labelFor: oTF
        });
        var oTF = new sap.ui.commons.TextField("tNombre", {
            tooltip: 'Nombre',
            editable: true,
            width: '400px',
            required: true,
            value: modo !== 'new'? provAct.nombre : ''
        });
        oLayout.createRow(oLabel, oTF);
        var oLabel = new sap.ui.commons.Label( {
            text: 'Correo',
            labelFor: oTF
        });
        var oTF = new sap.ui.commons.TextField("tCorreo", {
            tooltip: 'Correo',
            editable: true,
            width: '200px',
            required: true,
            value: modo !== 'new'? provAct.correo : ''
        });
        oLayout.createRow(oLabel, oTF);
        var oLabel = new sap.ui.commons.Label( {
            text: 'Notas',
            labelFor: oTF
        });
        var oTF = new sap.ui.commons.TextField("tNotas", {
            tooltip: 'Notas',
            editable: true,
            width: '450px',
            required: false,
            value: modo !== 'new'? provAct.notas : ''
        });
        oLayout.createRow(oLabel, oTF);
        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: modo === 'new'? "Crear":"Guardar Cambios", 
    		press:function(){
	            var data = { 
	                "numeroSAP": sap.ui.getCore().getControl("tNumeroSAP").getValue().trim(),
	                "rfc": sap.ui.getCore().getControl("tRFC").getValue().trim(),
	                "nombre": sap.ui.getCore().getControl("tNombre").getValue().trim(),
	                "correo": sap.ui.getCore().getControl("tCorreo").getValue().trim(),
	                "notas": sap.ui.getCore().getControl("tNotas").getValue().trim()
	            };
	            oController.createUpdate(data, modo);
	            oDialog.close();
	        }
        }));
        oDialog.open();
    },
    
    createContent: function(oController) {


        //Create an instance of the table control
        var oTable = new sap.ui.table.Table("tableProveedores", {
                title: "Catálogo de Proveedores",
                visibleRowCountMode: sap.ui.table.VisibleRowCountMode.Auto,
                selectionMode: sap.ui.table.SelectionMode.Single,
                toolbar: new sap.ui.commons.Toolbar({items: [
	                 new sap.ui.commons.Button({text: "Nuevo Proveedor", press: function() { oController.getView().createDialog(oController, 'new'); }}),
	                 new sap.ui.commons.Button({text: "Actualizar", press: function() { 
	                	 oController.getView().createDialog(oController, 'act', oTable.getContextByIndex(oTable.getSelectedIndex()).getObject());}})
                ]})
        });


        oTable.addColumn(new sap.ui.table.Column({
	            label: new sap.ui.commons.Label({text: "Número SAP"}),
	            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
	            width: "120px",
				flexible: true,
				resizable: true,
				autoResizable: true,
	            sortProperty: "numeroSAP",
	            filterProperty: "numeroSAP"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "RFC"}),
                template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "rfc"),
                width: "150px",
    			flexible: true,
    			resizable: true,
    			autoResizable: true,
                sortProperty: "rfc",
                filterProperty: "rfc"
        }));
        oTable.addColumn(new sap.ui.table.Column({
	            label: new sap.ui.commons.Label({text: "Razón Social"}),
	            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
	            width: "300px",
				flexible: true,
				resizable: true,
				autoResizable: true,
	            sortProperty: "nombre",
	            filterProperty: "nombre"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Correo"}),
                template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "correo"),
                width: "200px",
    			flexible: true,
    			resizable: true,
    			autoResizable: true,
                sortProperty: "correo",
                filterProperty: "correo"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Notas"}),
                template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "notas"),
    			flexible: true,
    			resizable: true,
    			autoResizable: true,
                sortProperty: "notas",
                filterProperty: "notas"
        }));


        // create a simple matrix layout
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
                id : "matrixProveedores",
                layoutFixed : true,
                height: "100%"
                });


        oLayout.createRow( oTable );


        var page = new sap.m.Page();
        page.setEnableScrolling(true);
		var oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Administración de Proveedores");
        page.setCustomHeader(oBar);
        page.addContent(oLayout);
        //Bring the table onto the UI


        return page;
    },
    
    onBeforeRendering: function(oController) {
    }
    
});        
        