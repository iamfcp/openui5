sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.App", {

    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.App";
    },
    
    createContent: function(oController) {

        // set device model
        var oDeviceModel = new sap.ui.model.json.JSONModel({
            isTouch: sap.ui.Device.support.touch,
            isNoTouch: !sap.ui.Device.support.touch,
            isPhone: sap.ui.Device.system.phone,
            isNoPhone: !sap.ui.Device.system.phone,
            listMode: (sap.ui.Device.system.phone) ? "None" : "SingleSelectMaster",
            listItemType: (sap.ui.Device.system.phone) ? "Active" : "Inactive",
            launchpadMode: true
        });
        oDeviceModel.setDefaultBindingMode("OneWay");
        sap.ui.getCore().setModel(oDeviceModel, "device");
        this.setModel(oDeviceModel, "device");

        // to avoid scrollbars on desktop the root view must be set to block display
        this.setDisplayBlock(true);

        this.app = new sap.m.SplitApp({
            afterDetailNavigate: function() {
                this.hideMaster();
            },
            homeIcon: {
                'phone': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'phone@2': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'tablet': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'tablet@2': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'favicon': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'precomposed': false
            }
        });
        this.app.setMode(sap.m.SplitAppMode.HideMode);


        this.app.addMasterPage(sap.ui.jsview("Menu", sap.ui.getCore().AppContext.version+".view.Menu"));

        this.app.addDetailPage(sap.ui.jsview("Launchpad", sap.ui.getCore().AppContext.version+".view.Launchpad"));
        this.app.addDetailPage(sap.ui.jsview("CreaLicitacion", sap.ui.getCore().AppContext.version+".view.CreaLicitacion"));
        this.app.addDetailPage(sap.ui.xmlview("Info", sap.ui.getCore().AppContext.version+".view.Info"));
        this.app.addDetailPage(sap.ui.jsview("Usuarios", sap.ui.getCore().AppContext.version+".view.Usuarios"));
        this.app.addDetailPage(sap.ui.jsview("Proveedores", sap.ui.getCore().AppContext.version+".view.Proveedores"));
        this.app.addDetailPage(sap.ui.jsview("ConsultaLicitaciones", sap.ui.getCore().AppContext.version+".view.ConsultaLicitaciones"));
        this.app.addDetailPage(sap.ui.jsview("LiberaPropuestasTecnicas", sap.ui.getCore().AppContext.version+".view.LiberaPropuestasTecnicas"));
        this.app.addDetailPage(sap.ui.jsview("EvaluaPropuestasTecnicas", sap.ui.getCore().AppContext.version+".view.EvaluaPropuestasTecnicas"));
        this.app.addDetailPage(sap.ui.jsview("AperturaEconomica", sap.ui.getCore().AppContext.version+".view.AperturaEconomica"));
        this.app.addDetailPage(sap.ui.jsview("Aprobacion", sap.ui.getCore().AppContext.version+".view.Aprobacion"));
        this.app.addDetailPage(sap.ui.jsview("AprobacionEvaluacion", sap.ui.getCore().AppContext.version+".view.AprobacionEvaluacion"));


        this.app.toDetail("Launchpad");

        return this.app;
    }
    
});        
        