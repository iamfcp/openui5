
sap.ui.controller(sap.ui.getCore().AppContext.version+".view.Proveedores", {

    onInit: function() {
    },
    
    onAfterRendering : function() {
    },
      
    inicializa: function() {
    	this.obtieneDatos();
    },
    
    obtieneDatos: function() {
		var oTable = sap.ui.getCore().getControl("tableProveedores");
		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaProveedores.action");
		oTable.setModel(oModel);
		oTable.bindRows("/proveedores");

        oTable.sort(oTable.getColumns()[0]);
    },
    
    createUpdate: function(data, modo) {
        var view = this.getView();
		if(data.numeroSAP === '') {
			sap.ui.commons.MessageBox.show("Ingrese el número de proveedor en SAP",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}
		if(data.rfc === '') {
			sap.ui.commons.MessageBox.show("Ingrese el RFC",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}
		if(data.nombre === '') {
			sap.ui.commons.MessageBox.show("Ingrese el nombre o razón social del proveedor",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}
		if(data.correo === '') {
			sap.ui.commons.MessageBox.show("Ingrese el correo del proveedor",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}

        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: modo === 'new'? sap.ui.getCore().AppContext.path + "/creaProveedor.action": sap.ui.getCore().AppContext.path + "/actualizaProveedor.action",
            type: "POST",
            data: data,
            success: function(data) {
                sap.ui.core.BusyIndicator.hide();
	            var mdl = sap.ui.getCore().byId("tableProveedores").getModel();
				var modelDataTmp = mdl.getData(), len = modelDataTmp.proveedores.length;
				if(modo === 'new') 
					modelDataTmp.proveedores.push(data);
				else
					for (i=0; i<len; ++i) {
						if(modelDataTmp.proveedores[i].numeroSAP === data.numeroSAP) {
							modelDataTmp.proveedores[i].rfc = data.rfc;
							modelDataTmp.proveedores[i].nombre = data.nombre;
							modelDataTmp.proveedores[i].correo = data.correo;
							modelDataTmp.proveedores[i].notas = data.notas;
							break;
						}
					}
	            mdl.refresh();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
            }
        });

//		var oTable = sap.ui.getCore().getControl("tableProveedores");
//        var f = oTable.getBinding("rows").aFilters;
//        console.log(f);
//        this.obtieneDatos();
//        oTable.getBinding("rows").aFilters = f;
//        oTable.getBinding("rows").filter(f, "Application");
    }
    
    
});