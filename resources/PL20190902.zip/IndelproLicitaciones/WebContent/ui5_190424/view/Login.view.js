var app;
sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.Login", {
	
    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.Login";
    },

    createContent: function(oController) {

        function getUIBox() {
            var box = new sap.m.FlexBox({
                alignItems: sap.m.FlexAlignItems.Stretch,
                justifyContent: sap.m.FlexJustifyContent.SpaceAround,
                items: [
                    new sap.ui.commons.Image( {  
                        src : "images/indelpro.png",  
                        height : "100px"
                    }),
                    new sap.m.Label({
                        text: "Portal de Licitaciones",
                        design: sap.m.LabelDesign.Bold
                    }).addStyleClass("login_title"),
                    new sap.m.Label({
                        text: "Acceso al Sistema",
                        design: sap.m.LabelDesign.Standard
                    }).addStyleClass("login_subtitle"),
                    new sap.ui.commons.layout.HorizontalLayout({
                        id: "login_error_box",
                        content: [
                            new sap.ui.core.Icon({
                                src: "sap-icon://error",
                                backgroundColor: "transparent",
                                color: "red",
                                visible: false
                            }).addStyleClass("login_error"),
                            new sap.m.Label({
                                id: "login_error",
                                text: "Usuario o Contraseña Incorrectos",
                                design: sap.m.LabelDesign.Standard,
                            }).addStyleClass("login_error"),
                        ]
                    }),
                    new sap.m.Input({
                        id: "xs_username",
                        placeholder: "Usuario",
                    }).addStyleClass("login_username"),
                    new sap.m.Input({
                        id: "xs_password",
                        type: sap.m.InputType.Password,
                        placeholder: "Contraseña",
                    }).addStyleClass("login_password"),
                    new sap.m.Button({
                        id: "logon_button",
                        text: "Iniciar Sesión",
                        type: sap.m.ButtonType.Emphasized,
                        press: function() {
                            oController.sendForm();
                        }
                    }).addStyleClass("sapMLabelBold").setWidth("100%"),
//                    new sap.m.Link({
//                        text: "Solicitar Contraseña",
//                        href: "#",
//                        press: function(oControlEvent) {
//                        	app.to("ui.pwdchange.page");
//                        }
//                    }).addStyleClass("login_forgotpassword_link")
                ],
                direction: "Column"
            }).addStyleClass("login_box");

            return box;

        };
        
        function getLinks() {
//            var box = new sap.m.FlexBox({
//                alignItems: sap.m.FlexAlignItems.End,
//                justifyContent: sap.m.FlexJustifyContent.End,
//                direction: "Column"
//            }).addStyleClass("login_links_box");
//
//            box.addItem(new sap.m.Link({
//                text: "Solicitar Contraseña",
//                href: "#",
//                press: function(oControlEvent) {
//                	app.to("ui.pwdchange.page");
//                }
//            }).addStyleClass("login_forgotpassword_link"));
//
//            return box;
        };
        
        function getPwdChangeBox() {
            var box = new sap.m.FlexBox({
                alignItems: sap.m.FlexAlignItems.Stretch,
                justifyContent: sap.m.FlexJustifyContent.SpaceAround,
                items: [
                        new sap.ui.commons.Image( {  
                            src : "images/indelpro.png",  
                            height : "100px"
                        }),
                        new sap.m.Label({
                            text: "Portal de Licitaciones",
                            design: sap.m.LabelDesign.Bold
                        }).addStyleClass("login_title"),
                        new sap.m.Label({
                            text: "Solicitar Nueva Contraseña",
                            design: sap.m.LabelDesign.Standard
                        }).addStyleClass("login_subtitle"),
                        new sap.m.Input({
                            id: "xs_username_new_pass",
                            placeholder: "Usuario",
                        }).addStyleClass("login_username"),
                        new sap.m.Button({
                            id: "new_pass_button",
                            text: "Solicitar",
                            type: sap.m.ButtonType.Emphasized,
                            press: function() {
                                oController.requestNewPassword();
                            }
                        }).addStyleClass("sapMLabelBold").setWidth("100%"),
                        new sap.m.Link({
                            text: "Regresar",
                            href: "#",
                            press: function(oControlEvent) {
                            	app.to("ui.login.page");
                            }
                        }).addStyleClass("login_forgotpassword_link")
                    ],
                    direction: "Column"
                }).addStyleClass("login_pwdchange_box");
            return box;

        };
        

        var loginPage = new sap.m.Page("ui.login.page", {
            showHeader: false,
            content: [getUIBox(), getLinks()]
        });
        var changePasswordPage = new sap.m.Page("ui.pwdchange.page", {
            showHeader: false,
            content: [getPwdChangeBox()]
        });
        
        this.setDisplayBlock(false);
        this.app = new sap.m.App();
        app = this.app;
        
        this.app.addPage(loginPage, false);
        this.app.addPage(changePasswordPage, false);
        return this.app;
    }
});        
        