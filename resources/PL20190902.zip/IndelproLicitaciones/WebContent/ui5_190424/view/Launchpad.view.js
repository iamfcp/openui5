sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.Launchpad", {

    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.Launchpad";
    },

    createContent: function(oController) {

        var tc = new sap.m.TileContainer("tc", {});

        var model = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/Menu.action");
        model.attachRequestCompleted(null, function() {
            function navFn(target) {
                return function() {
                    oController.doNavOnSelect(target);
                }
            }

            var data = null,
                m = 0,
                menu = null;
            data = model.getData();
            if (data && data.menu) {
                for (m = 0; m < data.menu.length; m++) {
                    menu = data.menu[m];
                    tc.addTile(new sap.m.StandardTile({
                        icon: menu.icon,
                        title: menu.title,
//                        info: menu.title,
                        press: navFn(menu.targetPage)
                    }));
                }
            }

        });
        var page = new sap.m.Page({
            footer: new sap.m.Bar({
                contentMiddle: [new sap.m.Link("Indelpro", {
                    text: "v2.0.0",
                    href: "http://indelpro.com"
                })]
            })
        });

		var oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader(null);
        page.setCustomHeader(oBar);  
        page.setEnableScrolling(false);
        page.addContent(tc);

        return page;
    }

});