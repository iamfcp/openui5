sap.ui.controller(sap.ui.getCore().AppContext.version+".view.LoginProveedor", {

    onInit: function() {
    	jQuery.sap.require("sap.ui.commons.MessageBox");
        sap.ui.getCore().getControl("login_error_box").setVisible(false);
//        sap.ui.getCore().getControl("login_pwdchange_error_box").setVisible(false);
        this.checkSession();
        this.loadINIParameters();
    },

    onAfterRendering: function() {
        var view = this.getView();
        sap.ui.getCore().getControl("xs_username").focus();
        view.addDelegate({
            onsapenter: function(e) {
                view.getController().sendForm();
            }
        });

        if (this.getOwnerComponent() && this.getOwnerComponent().getBackgroundImage()) {
            app.setModel(new sap.ui.model.json.JSONModel({
                d: {
                    VALUE: this.getOwnerComponent().getBackgroundImage()
                }
            }));
        }

    },

    to: function(pageId, context) {

    },

    back: function(pageId) {

    },

    getBaseURL: function() {
        return location.protocol + "//" + location.hostname + (location.port && ":" + location.port);
    },

    loadINIParameters: function() {
//        var paramModel = new sap.ui.model.json.JSONModel();
//      paramModel.loadData("/sap/hana/xs/selfService/user/db/iniParams.xsodata/parameters('login_screen_background_image')", null,true,"GET",false,false,{"X-Content-Type-Options": "nosniff"});
//        paramModel.attachRequestFailed(function(oEvent) {
//            console.info(oBundle.getText("LOGIN_SCREEN_INI_NOT_SET"));
//        });
//        app.setModel(paramModel);
//        app.bindProperty("backgroundImage", "/d/VALUE");

    },

    loadConfigParameters: function() {

        $.ajax({
            url: "/sap/hana/xs/selfService/user/selfService.xsjs?action=getParameters",
            type: "GET",
            async: false,
            success: function(data) {
                configParameters = data;
            },
            error: function(xhr, err, responseText) {
                console.info(oBundle.getText("USS_USER_NOT_SET"));
            }
        });
    },

    redirectToProfileLocation: function(data) {

        var newLocation = this.getBaseURL() + sap.ui.getCore().AppContext.path + "/welcomeProveedor.action";
        location.replace(newLocation);
        return;

    },

    redirectToOriginLocation: function(data) {

        var hashValue = self.document.location.hash.substring(1);
        if (hashValue !== "") {
            hashValue = "#" + hashValue;
        }

        var originLocation = decodeURIComponent(this.getParameterByName("x-sap-origin-location"));

        if (isMobile.any() === true || jQuery.browser.safari === true) {
            var date = new Date();
            var timestampParameter = 'x-sap-timestamp=' + date.getTime();
            var regex = /x-sap-timestamp=(\d*)/g;
            if (originLocation.match(regex)) {
                originLocation = originLocation.replace(regex, timestampParameter);
            } else {
                var hasParameter = originLocation.indexOf('?') >= 0;
                originLocation += (hasParameter) ? '&' : '?';
                originLocation += timestampParameter;
            }
        }

        var newLocation = this.getBaseURL() + originLocation + hashValue;
        location.replace(newLocation);
        return;

    },

    handleSuccessfulLogin: function(data) {
        if (data.pwdChange) {
            app.to("ui.pwdchange.page");
            sap.m.MessageToast.show(oBundle.getText("CHANGE_PASSWORD_MESSAGE"), {
                duration: 4000,
            });
            return;
        }

        if (this.getParameterByName("x-sap-origin-location") !== null) {
            this.redirectToOriginLocation(data);
            return;
        }

        this.redirectToProfileLocation();
    },

    handleFailureLogin: function(data) {
        if (!data.login) {
            sap.ui.getCore().getControl("login_error_box").setVisible(true);
//            sap.ui.getCore().getControl("login_error").setText(oBundle.getText("LOGIN_FAILED"));
            sap.ui.getCore().getControl("xs_username").setValueState("Error");
            sap.ui.getCore().getControl("xs_password").setValueState("Error");
        }
    },

    handleFailurePwdChange: function(data) {
        if (!data.login) {
            sap.ui.getCore().getControl("login_pwdchange_error_box").setVisible(true);
            sap.ui.getCore().getControl("login_pwdchange_error").setText(data.exception);
            sap.ui.getCore().getControl("xs_oldpassword").setValueState("Error");
            sap.ui.getCore().getControl("xs_newpassword").setValueState("Error");
            sap.ui.getCore().getControl("xs_confirmpassword").setValueState("Error");
        }
    },

    checkSession: function() {
        var view = this.getView();
        var origin = this.getParameterByName("x-sap-origin-location");
        $.ajax({
            url: "/sap/hana/xs/formLogin/checkSession.xsjs",
            type: "GET",
            data: origin !== null ? {
                "x-sap-origin-location": decodeURIComponent(origin)
            } : {},
            success: function(resp) {
                if (resp) {
                    if (resp["x-sap-origin-location-ok"] === false) {
                        app.to("ui.phishing.page");
                        return;
                    }

                    if (resp.login === true) {
                        view.getController().handleSuccessfulLogin(resp);
                    } else {
                        app.to("ui.login.page");
                    }
                }
            }
        });
    },


    getParameterByName: function(name) {
        var match = RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search);
        return match && match[1].replace(/\+/g, ' ');
    },

    logout: function() {
        var view = this.getView();
        var send = function() {
            $.ajax({
                url: "logout.xscfunc",
                type: "POST",
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("X-CSRF-Token", CSRFToken);
                },
                success: function() {
                    view.getController().checkSession();
                }
            });
        };
        this.getCSRFToken(send);

    },

    sendForm: function() {
        sap.ui.core.BusyIndicator.show(0);
        var view = this.getView();

        var send = function() {
            var origin = view.getController().getParameterByName("x-sap-origin-location");
            var data = {
                "username": sap.ui.getCore().getControl("xs_username").getValue().trim(),
                "password": sap.ui.getCore().getControl("xs_password").getValue(),
                "licitacion": sap.ui.getCore().getControl("xs_licitacion").getValue().trim()
            };
            if(sap.ui.getCore().getControl("xs_username").getValue().length >2048){
                sap.ui.getCore().getControl("xs_username").setValueStateText(oBundle.getText("USERNAME_EXCEEDED"));
                sap.ui.getCore().getControl("xs_username").setValueState("Error");
            }
            $.ajax({
                url: sap.ui.getCore().AppContext.path + "/loginProveedor.action",
                type: "POST",
                data: data,
                beforeSend: function(xhr) {
//                    xhr.setRequestHeader("X-CSRF-Token", CSRFToken);
                },
                success: function(data) {
//                    sap.ui.core.BusyIndicator.hide();
                    view.getController().handleSuccessfulLogin(data);
                },
                error: function(data) {
                    sap.ui.core.BusyIndicator.hide();
                    view.getController().handleFailureLogin(data);
                }
            });
        };
        this.getCSRFToken(send);
    },

    requestNewPassword: function() {
        sap.ui.core.BusyIndicator.show(0);
        var view = this.getView();

        var send = function() {
            var data = {
                "username": sap.ui.getCore().getControl("xs_username_new_pass").getValue().trim()
            };
            if(sap.ui.getCore().getControl("xs_username_new_pass").getValue().length >2048){
                sap.ui.getCore().getControl("xs_username_new_pass").setValueStateText(oBundle.getText("USERNAME_EXCEEDED"));
                sap.ui.getCore().getControl("xs_username_new_pass").setValueState("Error");
            }
            $.ajax({
                url: sap.ui.getCore().AppContext.path + "/resetPass.action",
                type: "POST",
                data: data,
                beforeSend: function(xhr) {
                },
                success: function(data) {
                    sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.show("Se le ha enviado una nueva contraseña",
			                sap.ui.commons.MessageBox.Icon.SUCCESS,
			                "Éxito",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);
                    app.to("ui.login.page");
                },
                error: function(data) {
                    sap.ui.core.BusyIndicator.hide();
                }
            });
        };
        this.getCSRFToken(send);
    },

    sendChangePwdForm: function() {
        var view = this.getView();
        if (sap.ui.getCore().getControl("xs_oldpassword").getValue() == sap.ui.getCore().getControl("xs_newpassword").getValue()) {
            sap.ui.getCore().getControl("xs_oldpassword").setValueState("Error");
            sap.ui.getCore().getControl("xs_oldpassword").setValueStateText(oBundle.getText("CURRENT_NEW_PASSWORD_ERROR"));
            sap.ui.getCore().getControl("xs_newpassword").setValueState("Error");
            sap.ui.getCore().getControl("xs_newpassword").setValueStateText(oBundle.getText("CURRENT_NEW_PASSWORD_ERROR"));
            return;
        }

        if (sap.ui.getCore().getControl("xs_newpassword").getValue() == sap.ui.getCore().getControl("xs_confirmpassword").getValue()) {
            var send = function() {
                var data = {
                    "xs-password-old": sap.ui.getCore().getControl("xs_oldpassword").getValue(),
                    "xs-password-new": sap.ui.getCore().getControl("xs_newpassword").getValue()
                };

                $.ajax({
                    url: "pwchange.xscfunc",
                    type: "POST",
                    data: {
                        "xs-password-old": sap.ui.getCore().getControl("xs_oldpassword").getValue(),
                        "xs-password-new": sap.ui.getCore().getControl("xs_newpassword").getValue()
                    },
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader("X-CSRF-Token", CSRFToken);
                    },
                    success: function(data) {
                        view.getController().handleSuccessfulLogin(data);
                    },
                    error: function(data) {
                        view.getController().handleFailurePwdChange(data.responseJSON);
                    }
                });
            };
            this.getCSRFToken(send);
        } else {
            sap.ui.getCore().getControl("xs_newpassword").setValueState("Error");
            sap.ui.getCore().getControl("xs_newpassword").setValueStateText(oBundle.getText("NEW_CONFIRM_PASSWORD_ERROR"));
            sap.ui.getCore().getControl("xs_confirmpassword").setValueState("Error");
            sap.ui.getCore().getControl("xs_confirmpassword").setValueStateText(oBundle.getText("NEW_CONFIRM_PASSWORD_ERROR"));
        }
    },

    getCSRFToken: function(callback) {
//        $.ajax({
//            url: "/sap/hana/xs/formLogin/token.xsjs",
//            type: "GET",
//            beforeSend: function(xhr) {
//                xhr.setRequestHeader("X-CSRF-Token", "Fetch");
//            },
//            success: function(data, textStatus, XMLHttpRequest) {
//                CSRFToken = XMLHttpRequest.getResponseHeader('X-CSRF-Token');
                callback();
//            }
//        });
    },


});

var isMobile = {
    Android: function() {
        var regex = /Android/i;
        return regex.test(navigator.userAgent);
    },
    BlackBerry: function() {
        var regex = /BlackBerry/i;
        return regex.test(navigator.userAgent);
    },
    iOS: function() {
        var regex = /iPhone|iPad|iPod/i;
        return regex.test(navigator.userAgent);
    },
    Opera: function() {
        var regex = /Opera Mini/i;
        return regex.test(navigator.userAgent);
    },
    Windows: function() {
        var regex = /IEMobile/i;
        return regex.test(navigator.userAgent);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};