sap.ui.controller(sap.ui.getCore().AppContext.version+".view.LiberaPropuestasTecnicas", {
	pagina: null,
	panelLista: null,
	panelLicitacion: null,
	datosLicitacion: null,
	
    onInit: function() {
    	jQuery.sap.require("sap.ui.commons.MessageBox");
    },
    
    inicializa: function() {
    	this.veAListado();
    },
    
    veAListado: function() {
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLista);
        sap.ui.core.BusyIndicator.show(0);

		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaLicitaciones.action?estatus=2");
		var oTable = sap.ui.getCore().byId("tableListaLicLiberaPT");
		oTable.setModel(oModel);
		oTable.bindRows("/licitaciones");
		
		oModel.attachRequestCompleted(null, function() { 
            sap.ui.core.BusyIndicator.hide();
		});
    },
 
    veALicitacion: function(numeroLicitacion) {
        sap.ui.core.BusyIndicator.show(0);
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLicitacion);
		var data = {};
		data.numeroLicitacion = numeroLicitacion;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/obtenLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var c = sap.ui.getCore().byId("LiberaPropuestasTecnicas").getController();
            	var oModel = c.getView().getModel();
            	if(!oModel) {
            		oModel = new sap.ui.model.json.JSONModel();
            		c.getView().setModel(oModel);
            	}
//            	var len = dataRet.data.listaProveedores.length;
//            	for(var i=0; i<len; i++) {
//            		dataRet.data.listaProveedores[i].NOLIBERADA = !dataRet.data.listaProveedores[i].LIBERADA;
//            	}
        		oModel.setData(dataRet.data);
        		oModel.refresh();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },
 
    valida: function() {
        var listaProveedores = this.getView().getModel().getProperty("/listaProveedores");
    	var len = listaProveedores.length;
    	for(var i=0; i<len; i++) {
        	var len2 = listaProveedores[i].listaProveedores.length;
        	for(var j=0; j<len2; j++)
	    		if((listaProveedores[i].listaProveedores[j].NOLIBERADA && listaProveedores[i].listaProveedores[j].LIBERADA) ||
	    				(!listaProveedores[i].listaProveedores[j].NOLIBERADA && !listaProveedores[i].listaProveedores[j].LIBERADA)) {
					sap.ui.commons.MessageBox.show("Debe seleccionar solo un estatus para cada propuesta",
			                sap.ui.commons.MessageBox.Icon.ERROR,
			                "Error",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);
					return false;
	    		}
    	}
    	return true;
    },
    
    liberaPT: function(claveLib, numLic) {
        sap.ui.core.BusyIndicator.show(0);
        var data = {
        		claveLiberacion: claveLib, 
        		numeroLicitacion: numLic,
        		listaProveedores: this.getView().getModel().getProperty("/listaProveedores")};
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/liberaPTLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
            	if(dataRet.codigo !== 200) {
                    sap.ui.core.BusyIndicator.hide();
    				sap.ui.commons.MessageBox.show(dataRet.mensaje,
    		                sap.ui.commons.MessageBox.Icon.ERROR,
    		                "Error",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                '', sap.ui.commons.MessageBox.Action.OK);
//    				if(dataRet.codigo === 401) TODO Mandar a login
            	} else {
                    sap.ui.core.BusyIndicator.hide();
    				sap.ui.commons.MessageBox.show("Se han liberado las propuestas",
    		                sap.ui.commons.MessageBox.Icon.SUCCESS,
    		                "Éxito",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                function(){sap.ui.getCore().byId("LiberaPropuestasTecnicas").getController().veAListado()},
    		                sap.ui.commons.MessageBox.Action.OK);      
            	}
                sap.ui.core.BusyIndicator.hide();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    }
 
});