sap.ui.controller(sap.ui.getCore().AppContext.version+".view.EvaluaPropuestasTecnicas", {
	pagina: null,
	panelLista: null,
	panelLicitacion: null,
	datosLicitacion: null,
	idArchivoResultados: null,
	nombreArchivoResultados: null,
	
    onInit: function() {
    	jQuery.sap.require("sap.ui.commons.MessageBox");
    },
    
    inicializa: function() {
    	this.veAListado();
    },
    
    veAListado: function() {
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLista);
        sap.ui.core.BusyIndicator.show(0);

		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaLicitaciones.action?estatus=3");
		oModel.attachRequestCompleted(null, function() { 
			var oTable = sap.ui.getCore().byId("tableListaLicEvalTec");
			oTable.setModel(oModel);
			var usuario = oModel.getProperty("/data/usuario");
			var f1 = new  sap.ui.model.Filter('responsable', "EQ", usuario);  
			oTable.bindRows({path: "/licitaciones",filters: [f1]});
            sap.ui.core.BusyIndicator.hide();
		});
    },
 
    veALicitacion: function(numeroLicitacion) {
        sap.ui.core.BusyIndicator.show(0);
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLicitacion);
		var data = {};
		data.numeroLicitacion = numeroLicitacion;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/obtenLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var c = sap.ui.getCore().byId("EvaluaPropuestasTecnicas").getController();
            	var oModel = c.getView().getModel();
            	if(!oModel) {
            		oModel = new sap.ui.model.json.JSONModel();
            		c.getView().setModel(oModel);
            	}
        		for(var i = 0; i < dataRet.data.lResultadosEvaluacion.length; i++) {
        			dataRet.data.lResultadosEvaluacion[i].grupo = dataRet.data.lResultadosEvaluacion[i].numeroSAP + i; 
        			dataRet.data.lResultadosEvaluacion[i].cal1 = dataRet.data.lResultadosEvaluacion[i].calificacion === 1; 
        			dataRet.data.lResultadosEvaluacion[i].cal2 = dataRet.data.lResultadosEvaluacion[i].calificacion === 2; 
        			dataRet.data.lResultadosEvaluacion[i].cal3 = dataRet.data.lResultadosEvaluacion[i].calificacion === 3; 
        			dataRet.data.lResultadosEvaluacion[i].cal4 = dataRet.data.lResultadosEvaluacion[i].calificacion === 4; 
        			dataRet.data.lResultadosEvaluacion[i].cal5 = dataRet.data.lResultadosEvaluacion[i].calificacion === 5; 
        			dataRet.data.lResultadosEvaluacion[i].subtotal = 
        				(dataRet.data.lResultadosEvaluacion[i].porcentaje / 5) * 
        				dataRet.data.lResultadosEvaluacion[i].calificacion;
        		}
        		oModel.setData(dataRet.data);
        		console.log(oModel.getData());
        		c.calculaCalificaciones();
        		c.idArchivoResultados = dataRet.data.idArchivoResultados;
        		c.nombreArchivoResultados = dataRet.data.nombreArchivoResultados;
        		oModel.refresh();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },

	getSubTotal: function(proveedor, fase) {
		var lResultadosEvaluacion = this.getView().getModel().getProperty("/lResultadosEvaluacion");
		for(var i = 0; i < lResultadosEvaluacion.length; i++) {
			lResultadosEvaluacion[i].calificacion = 
				lResultadosEvaluacion[i].cal1 == true ? 1 :
					lResultadosEvaluacion[i].cal2 == true ? 2 : 
						lResultadosEvaluacion[i].cal3 == true ? 3 :
							lResultadosEvaluacion[i].cal4 == true ? 4 :
								lResultadosEvaluacion[i].cal5 == true ? 5 : 0;
			lResultadosEvaluacion[i].subtotal = (lResultadosEvaluacion[i].porcentaje / 5) * lResultadosEvaluacion[i].calificacion;
		}
		return this.getTotal(proveedor, fase);
	},

	getTotal: function(proveedor, fase) {
		var total = 0;
		var lResultadosEvaluacion = this.getView().getModel().getProperty("/lResultadosEvaluacion");
		for(var i = 0; i < lResultadosEvaluacion.length; i++) 
			if(lResultadosEvaluacion[i].numeroSAP === proveedor) 
				if(fase === 0 || fase === lResultadosEvaluacion[i].fase)
					total += (lResultadosEvaluacion[i].porcentaje / 5) * lResultadosEvaluacion[i].calificacion;
		return total;
	},

	calculaCalificaciones: function() {
		var listaProveedores = this.getView().getModel().getProperty("/listaProveedores");
		for(var j = 0; j < listaProveedores.length; j++) {
			listaProveedores[j].totalFase1 = this.getTotal(listaProveedores[j].numeroSAP, 1);
			listaProveedores[j].totalFase2 = this.getTotal(listaProveedores[j].numeroSAP, 2);
			listaProveedores[j].total = listaProveedores[j].totalFase1 + listaProveedores[j].totalFase2;
		}
	},
	
	guardaResultadosEvaluacion: function() {
        sap.ui.core.BusyIndicator.show(0);
        var c = sap.ui.getCore().byId("EvaluaPropuestasTecnicas").getController();
    	var oModel = c.getView().getModel();
		var data = {
				numeroLicitacion: oModel.getData().numeroLicitacion, 
				lResultadosEvaluacion: oModel.getData().lResultadosEvaluacion,
				idArchivoResultados: this.idArchivoResultados,
				nombreArchivoResultados: this.nombreArchivoResultados
		};
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/guardaResultadosEvaluacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se han guardado los cambios",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },
	
	terminaEvaluacion: function() {
        sap.ui.core.BusyIndicator.show(0);
        var c = sap.ui.getCore().byId("EvaluaPropuestasTecnicas").getController();
    	var oModel = c.getView().getModel();
		var data = {
				numeroLicitacion: oModel.getData().numeroLicitacion, 
				estatus: 4
		};
		var dataJ = {data: data};
		if(this.idArchivoResultados === null || this.idArchivoResultados === '') {
	        sap.ui.core.BusyIndicator.hide();
			sap.ui.commons.MessageBox.show("No ha cargado el archivo de resultados de evaluación",
	                sap.ui.commons.MessageBox.Icon.ERROR,
	                "Error",
	                [sap.ui.commons.MessageBox.Action.OK],
	                '', sap.ui.commons.MessageBox.Action.OK);
			return;
		}

        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/cambiaEstatus.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se han guardado los cambios",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                function(){sap.ui.getCore().byId("MainAppView").getController().doNavBackLaunchpad();},
		                sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    }

});