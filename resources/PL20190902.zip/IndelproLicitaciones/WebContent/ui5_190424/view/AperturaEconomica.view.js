sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.AperturaEconomica", {

	getControllerName: function() {
		return sap.ui.getCore().AppContext.version+".view.AperturaEconomica";
	},

	editaPonderacion : function(oController) {
		var oDialog = new sap.ui.commons.Dialog("dialogEditaPonderacion",
				{
					modal : true,
					closed : function(oControlEvent) {
						sap.ui.getCore().getElementById('dialogEditaPonderacion')
								.destroy();
					}
				});
		oDialog.setTitle("Cambiar Ponderación de Evaluación");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "500px"
        });
        var model = oController.getView().getModel();
        oDialog.setModel(model);
		var dataMdl = model.getData();

		////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 1
        ////////////////////////////////////////////////////////////////////////////////////////////
        var lTotE1 = new sap.ui.commons.Label();
        var oLayoutF1 = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Total"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE1]})
	                ]
            	})
            ]
        });
        var tablaFase1 = new sap.ui.table.Table({
            visibleRowCount: 5,
            width: "250px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF1
        });
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Conceptos Generales"}),
            template: new sap.ui.commons.Label().bindProperty("text", "concepto"),
            width: "160px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Porcentaje"}),
            template: new sap.ui.commons.TextField({
            	change: function(oControlEvent){
					if(isNaN(oControlEvent.getParameters().newValue))
						sap.ui.commons.MessageBox.alert("Utilice solo números", null, "Error"); 
            		var t = 0;
					for (i=0; i<dataMdl.lConceptosEvaluacion.length; ++i)
						if(dataMdl.lConceptosEvaluacion[i].fase === 1)
							t += dataMdl.lConceptosEvaluacion[i].porcentaje;
					lTotE1.setText(t + ' %');
            	},
            	value: {
                    path: "porcentaje",
                    type: new sap.ui.model.type.Integer()
                }
            }),
            sortProperty: "porcentaje",
            filterProperty: "porcentaje"
        }));
        var f1 = new  sap.ui.model.Filter('fase', "EQ", 1);  
        tablaFase1.bindRows({path: "/lConceptosEvaluacion",filters: [f1]});
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 2
        ////////////////////////////////////////////////////////////////////////////////////////////
        var lTotE2 = new sap.ui.commons.Label();
        var oLayoutF2 = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Total"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE2]})
	                ]
            	})
            ]
        });
        var tablaFase2 = new sap.ui.table.Table({
            visibleRowCount: 5,
            width: "250px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF2
        });
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Conceptos Técnicos"}),
            template: new sap.ui.commons.Label().bindProperty("text", "concepto"),
            width: "160px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Porcentaje"}),
            template: new sap.ui.commons.TextField({
            	change: function(oControlEvent){
					if(isNaN(oControlEvent.getParameters().newValue))
						sap.ui.commons.MessageBox.alert("Utilice solo números", null, "Error"); 
            		var t = 0;
					for (i=0; i<dataMdl.lConceptosEvaluacion.length; ++i)
						if(dataMdl.lConceptosEvaluacion[i].fase === 2)
							t += dataMdl.lConceptosEvaluacion[i].porcentaje;
					lTotE2.setText(t + ' %');
            	},
            	value: {
                    path: "porcentaje",
                    type: new sap.ui.model.type.Integer()
                }
            }),
            sortProperty: "porcentaje",
            filterProperty: "porcentaje"
        }));
        var f2 = new  sap.ui.model.Filter('fase', "EQ", 2);  
        tablaFase2.bindRows({path: "/lConceptosEvaluacion",filters: [f2]});
///
        var t1 = 0, t2 = 0;
		for (i=0; i<dataMdl.lConceptosEvaluacion.length; ++i)
			if(dataMdl.lConceptosEvaluacion[i].fase === 1)
				t1 += dataMdl.lConceptosEvaluacion[i].porcentaje;
			else if(dataMdl.lConceptosEvaluacion[i].fase === 2)
				t2 += dataMdl.lConceptosEvaluacion[i].porcentaje;
		lTotE1.setText(t1 + ' %');
		lTotE2.setText(t2 + ' %');
        oDialog.addContent(new sap.m.FlexBox({
            alignItems: sap.m.FlexAlignItems.Stretch,
            justifyContent: sap.m.FlexJustifyContent.SpaceAround,
            items: [tablaFase1, tablaFase2],
            direction: "Row"
        }));

		oDialog.addButton(new sap.ui.commons.Button({
			text : "Guardar",
			press : function() {
				t1 = 0;
				for (i=0; i<dataMdl.lConceptosEvaluacion.length; ++i)
					t1 += dataMdl.lConceptosEvaluacion[i].porcentaje;
				if(t1 !== 100) {
					sap.ui.commons.MessageBox.show("El porcentaje total en las fases de evaluación no es 100: " + t1,
			                sap.ui.commons.MessageBox.Icon.ERROR,
			                "Error",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);
					return;
				}
				oDialog.close();
				oController.actualizaPonderacion(
						model.getProperty("/numeroLicitacion"),
						model.getProperty("/lConceptosEvaluacion")
				);
			}
		}));
		oDialog.addButton(new sap.ui.commons.Button({
			text : "Cancelar",
			press : function() {
				oDialog.close();
			}
		}));
		oDialog.open();
	}, // editaPonderacion

    createDialogAprobacion : function(oController) {
		var oDialog = new sap.ui.commons.Dialog("dialogAprobacion",
				{
					modal : true,
					closed : function(oControlEvent) {
						sap.ui.getCore().getElementById('dialogAprobacion')
								.destroy();
					}
				});
		oDialog.setTitle("Confirme Aprobación de Ganador");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "500px"
        });
        var model = oController.getView().getModel();
        if(model.getProperty("/proveedorGanador") !== model.getProperty("/proveedorPropuesto")) 
        	oLayout.createRow(new sap.ui.commons.TextArea({value: "El comité ha seleccionado un proveedor que no tiene la propuesta económica mas baja. " +
    			"Favor de solicitar la aprobación y justificar la selección de ganador.", width:'450px', editable:false}));
        
        var label = new sap.m.Label({text: "Comentario de aprobación"});
        oLayout.createRow(label);
        var tComentario = new sap.ui.commons.TextArea({value: "", width: "490px", rows: 10});
        oLayout.createRow(tComentario);
        
        oDialog.addContent(oLayout);
		oDialog.addButton(new sap.ui.commons.Button({
			text : "Finalizar",
			press : function() {
				oDialog.close();
				oController.asignaLicitacion(
						model.getProperty("/numeroLicitacion"),
						model.getProperty("/proveedorGanador"), 
						tComentario.getValue().replace(/(\r\n|\n|\r)/gm, ""),
						model.getProperty("/proveedorPropuesto")
				);
			}
		}));
		oDialog.addButton(new sap.ui.commons.Button({
			text : "Cancelar",
			press : function() {
				oDialog.close();
			}
		}));
		oDialog.open();
	},

    createDialog : function(numeroLicitacion, oController) {
		var oDialog = new sap.ui.commons.Dialog("dialogAperturaEcon",
				{
					modal : true,
					closed : function(oControlEvent) {
						sap.ui.getCore().getElementById('dialogAperturaEcon')
								.destroy();
					}
				});
		oDialog.setTitle("Ingrese Claves de Liberación");
		var oLayout = new sap.ui.commons.layout.MatrixLayout({
			columns : 2,
			width : "500px"
		});

		var tfUsuarioLib = new sap.m.Input({
			// id: "lptClaveLib",
			type : sap.m.InputType.Text,
			placeholder : "Usuario 1",
		});
		var tfClaveLib = new sap.m.Input({
			// id: "lptClaveLib",
			type : sap.m.InputType.Password,
			placeholder : "Clave de liberación",
		});
		oLayout.createRow(tfUsuarioLib, tfClaveLib);
		var tfUsuarioLib2 = new sap.m.Input({
			// id: "lptClaveLib",
			type : sap.m.InputType.Text,
			placeholder : "Usuario 2",
		});
		var tfClaveLib2 = new sap.m.Input({
			// id: "lptClaveLib",
			type : sap.m.InputType.Password,
			placeholder : "Clave de liberación",
		});
		oLayout.createRow(tfUsuarioLib2, tfClaveLib2);

		oDialog.addContent(oLayout);
		oDialog.addButton(new sap.ui.commons.Button({
			text : "Validar",
			press : function() {
				if(tfUsuarioLib.getValue() === tfUsuarioLib2.getValue()) {
					sap.ui.commons.MessageBox.show("Los usuarios deben ser distintos",
			                sap.ui.commons.MessageBox.Icon.ERROR,
			                "Error",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);
					oDialog.close();
					return;
				}
				oDialog.close();
				var data = {
					numeroLicitacion: numeroLicitacion, 
					liberador1: tfUsuarioLib.getValue(),
					liberador2: tfUsuarioLib2.getValue(),
					claveLiberacion1: tfClaveLib.getValue(),
					claveLiberacion2: tfClaveLib2.getValue(),
				};
				oController.liberar(data);
			}
		}));
		oDialog.open();
	},

    creaPanelLicitacion: function(oController) {
        // //////////////////////////////////////////////////////////////////////////////////////////
        // //////////////////////////////////////////////////////////////////////////////////////////
        var tablaProveedores = new sap.ui.table.Table("tablaProveedoresAperturaEcon", {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None
        });
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            width: "400px",
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Propuesta Técnica", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
                press: function () {
                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PT");
                	if(pdf)
	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
	                			pdf + 
	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PT"), 
	                			"indelproLicitacionesPDF", 
	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                	else
        				sap.ui.commons.MessageBox.show("No se ha cargado el documento",
        		                sap.ui.commons.MessageBox.Icon.WARNING,
        		                "Advertencia",
        		                [sap.ui.commons.MessageBox.Action.OK],
        		                '', sap.ui.commons.MessageBox.Action.OK);
                }
            })
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ponderación Conceptos Generales", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase1",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"})
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ponderación Conceptos Técnicos", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase2",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"})
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Total Evaluación Técnica", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "total",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"})
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Propuesta Económica", textAlign: "Center", wrapping: true}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
                press: function () {
                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PE");
                	var disponible = this.getBindingContext().getProperty("disponible");
                	if(pdf !== null && disponible === true)
	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
	                			pdf + 
	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PE"), 
	                			"indelproLicitacionesPDF", 
	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                	else
        				sap.ui.commons.MessageBox.show("No se puede mostrar el documento",
        		                sap.ui.commons.MessageBox.Icon.WARNING,
        		                "Advertencia",
        		                [sap.ui.commons.MessageBox.Action.OK],
        		                '', sap.ui.commons.MessageBox.Action.OK);
                }
            })
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Monto", textAlign: "Center", editable: false}),
	        template: new sap.ui.commons.Label({text: {
	            path : "IMPORTE",
	            formatter : function(oVal) {
	        		var formatter = new Intl.NumberFormat('en-US', {  
	    		          style: "currency",  
	    		          currency: "USD"  
	    		        });
	                return isNaN(oVal)? 'Bloqueado':formatter.format(oVal);
	            }
	        }, textAlign: "Center"})
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ganador", textAlign: "Center"}),
            template: new sap.ui.commons.CheckBox({
            	change: function(oEvent){
            		oController.marcaGanador(this.getBindingContext().getProperty("numeroSAP"));
            	}
            }).bindProperty("checked", "ganador").bindProperty("enabled", "disponible"),
            hAlign: "Center" 
        }));
//        tablaProveedores.bindRows("/listaProveedores");        
//        var f1 = new  sap.ui.model.Filter('total', "GE", 70);  
        var f1 = new  sap.ui.model.Filter('LIBERADA', "EQ", true);  
        tablaProveedores.bindRows({path: "/listaProveedores",filters: [f1]});
        

        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 4,
            width: "90%"
        });
        
		var oToolbar1 = new sap.ui.commons.Toolbar({width: "600px"});
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		var oButton1 = new sap.ui.commons.Button({
			text : "Regresar",
			press : function(event) {
				oController.veAListado();
			}
		});
		oButton1.setIcon("sap-icon://nav-back");
		oToolbar1.addItem(oButton1);		
		var oButton3 = new sap.ui.commons.Button("btnReevaluacionApEc", {
			text : "Re-evaluación",
			press : function(event) {
				oController.reevaluacion();
			}
		});
		oButton3.setIcon("sap-icon://undo");
		oToolbar1.addItem(oButton3);		

		var oButtonEditaPonderacion = new sap.ui.commons.Button("btnEditaPonderacionApEc", {
			text : "Edita Ponderaciones de Evaluación",
			press : function(event) {
				oController.getView().editaPonderacion(oController);
			}
		});
		oButtonEditaPonderacion.setIcon("sap-icon://to-be-reviewed");
		oToolbar1.addItem(oButtonEditaPonderacion);		
		
		oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
	       		{content: [oToolbar1],
   	       		 colSpan: 4 }));
        
        oLayout.createRow(new sap.ui.commons.Label({text:"Datos de la Licitación", design: "Bold"}));
        oLayout.createRow(new sap.ui.commons.Label({text:"Número"}), 
        		new sap.ui.commons.TextField({value:"{/numeroLicitacion}", editable: false, width: "200px"}));
        oLayout.createRow(
        		new sap.ui.commons.layout.MatrixLayoutCell(
                		{content: [new sap.ui.commons.Label({text:"Descripción"})] }),
	    		new sap.ui.commons.layout.MatrixLayoutCell(
	    	       		{content: [new sap.ui.commons.TextField({value:"{/descripcion}", editable: false, width: "400px"})],
	    	       		 colSpan: 2 })
		        );
        oLayout.createRow(new sap.ui.commons.Label({text:"Resultados de Evaluación", wraping: true}), 
        		new sap.m.Link({
                    text: "{/nombreArchivoResultados}",
                    href: "{/urlArchivoResultados}"
                }));
        oLayout.createRow(new sap.ui.commons.Label({text:"Importe Estimado", wraping: true}), 
        		new sap.ui.commons.Label({text: {path : "/importeEstimado",
        			formatter : function(oVal) {
    	        		var formatter = new Intl.NumberFormat('en-US', {  
    	    		          style: "currency",  
    	    		          currency: "USD"  
    	    		        });
    	                return formatter.format(oVal);
        			}}}));
        oLayout.createRow(new sap.ui.commons.Label({text:"Detalle Presupuesto", wraping: true}), 
        		new sap.m.Link({
                    text: "{/nombreArchivoPresupuesto}",
                    href: "#",
                    press: function(oControlEvent) {
                    	var model = sap.ui.getCore().byId("AperturaEconomica").getModel();
                    	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
                    			model.getProperty("/idArchivoPresupuesto") + 
                    			"&fileName=" + model.getProperty("/nombreArchivoPresupuesto"), 
                    			"_archivoPresupuesto", 
                    			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                    }
                })
        );
        
        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [tablaProveedores],
        		 colSpan: 4 }));
        
        var archivoSoporte = 
		     new sap.ui.unified.FileUploader({
	        	 name: "archivoUno",
	        	 uploadOnChange: true,
	        	 value: "{/nombreArchivoSoporteAsignacion}",
	        	 fileType: ["pdf", "xls", "xlsx"],
	        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
	        	 uploadComplete: function(oControlEvent) {
	        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
	        		 console.log(oControlEvent.getSource().getValue());
	        		 console.log(oControlEvent.getParameters().response.trim());
	        		 var res = oControlEvent.getParameters().response.trim().split('|');
	        		 oController.idArchivoSoporteAsignacion = res[1];
	        		 oController.nombreArchivoSoporteAsignacion = res[2].replace(/[^a-zA-Z.0-9]+/g,'');;
	        	 }

	         }).attachTypeMissmatch(null,
	        		 function() {
       	 		sap.ui.commons.MessageBox.alert("Solo se permiten archivos de tipo PDF, XLS, XLSX", null, "Error"); 
       		 }, null);
       archivoSoporte.setIcon("");
       oLayout.createRow(
       		new sap.ui.commons.layout.MatrixLayoutCell(
               		{content: [new sap.ui.commons.Label({text:"Archivo de Resultados"})] }),
	    		new sap.ui.commons.layout.MatrixLayoutCell(
	    	       		{content: [archivoSoporte],
	    	       		 colSpan: 2 })
		        );

        
		var oToolbar2 = new sap.ui.commons.Toolbar("toolBarAperturaEconLic");
		oToolbar2.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		
		var oButton1 = new sap.ui.commons.Button("bAperturaEcon",{
			text : "Liberar Propuestas",
			tooltip : "Liberar Propuestas",
			press : function(event) {
				console.log(this.getModel().getProperty("/proveedorGanador"));
				if(this.getModel().getProperty("/proveedorGanador"))
					oController.getView().createDialog(this.getModel().getProperty("/numeroLicitacion"), oController);
				else
					sap.ui.commons.MessageBox.show("No se pudo determinar un ganador",
			                sap.ui.commons.MessageBox.Icon.ERROR,
			                "Error",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);
			}
		});
		oButton1.setIcon("sap-icon://payment-approval");
		oToolbar2.addItem(oButton1);		
		
		var oButton2 = new sap.ui.commons.Button("bSolicitaAprobacion", {
			text : "Solicitar Aprobación",
			enabled: "{/puedeAsignar}",
			tooltip : "Solicitar Aprobación",
			press : function(event) {
				oController.getView().createDialogAprobacion(oController);
			}
		});
		oButton2.setIcon("sap-icon://accept");
		oToolbar2.addItem(oButton2);		
        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [oToolbar2],
        		 colSpan: 4 }));    	
        
        return oLayout;
    },
    
    creaListadoSolicitudes: function(oController) {

        //Create an instance of the table control
        var oTable = new sap.ui.table.Table("tableListaLicAperturaEcon", {
                title: "Licitaciones Disponibles para Asignación de Ganador",
                visibleRowCount: 10,
                firstVisibleRow: 1,
                selectionMode: sap.ui.table.SelectionMode.None
        });


        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Licitación"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "numeroLicitacion"),
            width: "100px",
            sortProperty: "numeroLicitacion",
            filterProperty: "numeroLicitacion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Descripción"}),
                template: new sap.ui.commons.TextField().bindProperty("value", "descripcion"),
                width: "150px",
                sortProperty: "descripcion",
                filterProperty: "descripcion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Estatus"}),
            template: new sap.ui.commons.Label({text: {
	            path : "estatus",
	            formatter : function(oVal) {
	                return sap.ui.getCore().byId("MainAppView").getController().descripcionEstatus(oVal);
	            }
	        }}),
            width: "100px",
            sortProperty: "estatus",
            filterProperty: "estatus"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Evaluar", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            width: "80px",
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("edit"),
                press: function () {
                	console.log(this.getBindingContext().getProperty("numeroLicitacion"));
                	oController.veALicitacion(this.getBindingContext().getProperty("numeroLicitacion"));
                }
            })
        }));
        
        // create a simple matrix layout
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
                layoutFixed : true
                });
        
        oLayout.createRow( oTable );

        return oLayout;
    },
    
    createContent: function(oController) {
		var page = new sap.m.Page();
		oController.pagina = page;
		oController.panelLicitacion = this.creaPanelLicitacion(oController);
		oController.panelLista = this.creaListadoSolicitudes(oController);
		var oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Junta de Comité para Apertura Económica");
		page.setCustomHeader(oBar);  
		page.setEnableScrolling(true);
		page.addContent(oController.panelLista);
//		page.addContent(oController.panelLista);
		return page;
	},

});