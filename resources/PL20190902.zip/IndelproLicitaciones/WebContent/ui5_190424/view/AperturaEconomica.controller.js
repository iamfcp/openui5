sap.ui.controller(sap.ui.getCore().AppContext.version+".view.AperturaEconomica", {
	pagina: null,
	panelLista: null,
	panelLicitacion: null,
	idArchivoSoporteAsignacion: null,
	nombreArchivoSoporteAsignacion: null,
	
    onInit: function() {
    	jQuery.sap.require("sap.ui.commons.MessageBox");
    },
    
    inicializa: function() {
    	this.veAListado();
    },
    
    veAListado: function() {
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLista);

		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaLicitaciones.action?estatus=4");
		var oTable = sap.ui.getCore().byId("tableListaLicAperturaEcon");
		oTable.setModel(oModel);
		oTable.bindRows("/licitaciones");
    },
    
    cambiaVisibilidadColumnasEcon: function(visible) {
    	var t = sap.ui.getCore().byId("tablaProveedoresAperturaEcon");
    	t.getColumns()[5].setProperty("visible",visible);
    	t.getColumns()[6].setProperty("visible",visible);
    	t.getColumns()[7].setProperty("visible",visible);
    },

    asignaLicitacion: function(numeroLicitacion, proveedorGanador, mensaje, proveedorPropuesto) {
        sap.ui.core.BusyIndicator.show(0);
		var data = {
				numeroLicitacion: numeroLicitacion, 
				proveedorGanador: proveedorGanador, 
				mensajeAdjudicacion: mensaje,
				proveedorPropuesto: proveedorPropuesto
		};
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/asignaLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
            	if(dataRet.codigo !== 200) {
                    sap.ui.core.BusyIndicator.hide();
    				sap.ui.commons.MessageBox.show(dataRet.mensaje,
    		                sap.ui.commons.MessageBox.Icon.ERROR,
    		                "Error",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                '', sap.ui.commons.MessageBox.Action.OK);
            	} else {
                    sap.ui.core.BusyIndicator.hide();
    				sap.ui.commons.MessageBox.show("Se ha solicitado la aprobación",
    		                sap.ui.commons.MessageBox.Icon.SUCCESS,
    		                "Éxito",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                '', sap.ui.commons.MessageBox.Action.OK);
    				sap.ui.getCore().byId("AperturaEconomica").getController().veAListado();
            	}
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },

    liberar: function(data) {
        sap.ui.core.BusyIndicator.show(0);
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLicitacion);
		data.nombreArchivoSoporteAsignacion = this.nombreArchivoSoporteAsignacion;
		data.idArchivoSoporteAsignacion = this.idArchivoSoporteAsignacion;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/liberaPELicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
            	if(dataRet.codigo !== 200) {
                    sap.ui.core.BusyIndicator.hide();
    				sap.ui.commons.MessageBox.show(dataRet.mensaje,
    		                sap.ui.commons.MessageBox.Icon.ERROR,
    		                "Error",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                '', sap.ui.commons.MessageBox.Action.OK);
//    				if(dataRet.codigo === 401) TODO Mandar a login
            	} else {
                    sap.ui.core.BusyIndicator.hide();
    				sap.ui.commons.MessageBox.show("Se han liberado las propuestas",
    		                sap.ui.commons.MessageBox.Icon.SUCCESS,
    		                "Éxito",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                '', sap.ui.commons.MessageBox.Action.OK);
    				var c = sap.ui.getCore().byId("AperturaEconomica").getController();
    				c.cambiaVisibilidadColumnasEcon(true);
                    c.getView().getModel().setProperty("/puedeAsignar", true);
                    if(sap.ui.getCore().byId("btnEditaPonderacionApEc")) 
                    	sap.ui.getCore().byId("btnEditaPonderacionApEc").setVisible(false);
                    if(sap.ui.getCore().byId("btnReevaluacionApEc")) 
                    	sap.ui.getCore().byId("btnReevaluacionApEc").setVisible(false);
            	}
                sap.ui.core.BusyIndicator.hide();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },
    
    veALicitacion: function(numeroLicitacion) {
        sap.ui.core.BusyIndicator.show(0);
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLicitacion);
        if(sap.ui.getCore().byId("btnEditaPonderacionApEc")) 
        	sap.ui.getCore().byId("btnEditaPonderacionApEc").setVisible(true);
        if(sap.ui.getCore().byId("btnReevaluacionApEc")) 
        	sap.ui.getCore().byId("btnReevaluacionApEc").setVisible(true);
		var data = {};
		data.numeroLicitacion = numeroLicitacion;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/obtenLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var c = sap.ui.getCore().byId("AperturaEconomica").getController();
            	var oModel = c.getView().getModel();
            	if(!oModel) {
            		oModel = new sap.ui.model.json.JSONModel();
            		c.getView().setModel(oModel);
            	}
        		oModel.setData(dataRet.data);
        		var urlArchivoResultados =  
        			sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + oModel.getProperty("/idArchivoResultados") + 
        			"&fileName=" + oModel.getProperty("/nombreArchivoResultados");
        		oModel.setProperty("/urlArchivoResultados", urlArchivoResultados);
        		oModel.setProperty("/puedeAsignar", false);
        		c.marcaGanador(oModel.getProperty("/proveedorPropuesto"));
//        		c.calculaCalificaciones();
        		oModel.refresh();
        		c.cambiaVisibilidadColumnasEcon(false);
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },

	marcaGanador: function(proveedor) {
		var model = this.getView().getModel();
		var listaProveedores = model.getProperty("/listaProveedores");
		for(var j = 0; j < listaProveedores.length; j++) {
			if(!listaProveedores[j].disponible)
				listaProveedores[j].IMPORTE = "-";
			listaProveedores[j].ganador = listaProveedores[j].numeroSAP === proveedor;
		}
		model.setProperty("/proveedorGanador", proveedor);
	},
	
	reevaluacion: function() {
        sap.ui.core.BusyIndicator.show(0);
        var c = sap.ui.getCore().byId("AperturaEconomica").getController();
    	var oModel = c.getView().getModel();
		var data = {
				numeroLicitacion: oModel.getData().numeroLicitacion, 
				estatus: 3
		};
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/cambiaEstatus.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se han guardado los cambios",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                function(){sap.ui.getCore().byId("MainAppView").getController().doNavBackLaunchpad();},
		                sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },

    actualizaPonderacion: function(numeroLicitacion, lConceptosEvaluacion) {
        sap.ui.core.BusyIndicator.show(0);
		var data = {
			numeroLicitacion: numeroLicitacion, 
			lConceptosEvaluacion: lConceptosEvaluacion
		};
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/actualizaPonderacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se han guardado los cambios",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                function(){sap.ui.getCore().byId("AperturaEconomica").getController().veALicitacion(numeroLicitacion);},
		                sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                function(){sap.ui.getCore().byId("AperturaEconomica").getController().veALicitacion(numeroLicitacion);}, 
		                sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    }
    
//	getTotal: function(proveedor, fase) {
//		var total = 0;
//		var lResultadosEvaluacion = this.getView().getModel().getProperty("/lResultadosEvaluacion");
//		for(var i = 0; i < lResultadosEvaluacion.length; i++) 
//			if(lResultadosEvaluacion[i].numeroSAP === proveedor) 
//				if(fase === 0 || fase === lResultadosEvaluacion[i].fase)
//					total += (lResultadosEvaluacion[i].porcentaje / 5) * lResultadosEvaluacion[i].calificacion;
//		return total;
//	},
//
//	calculaCalificaciones: function() {
//		var model = this.getView().getModel();
//		var listaProveedores = model.getProperty("/listaProveedores");
//		var nuevaListaProveedores = [];
//		for(var j = 0; j < listaProveedores.length; j++)  // quita proveedores sin propuesta
//			if(listaProveedores[j].IMPORTE > 0)
//				nuevaListaProveedores.push(listaProveedores[j]);
//		listaProveedores = nuevaListaProveedores;
//		model.setProperty("/listaProveedores", listaProveedores);
//		var montoGanador = 1000000000, proveedorGanador;
//		for(var j = 0; j < listaProveedores.length; j++) {
//			listaProveedores[j].totalFase1 = this.getTotal(listaProveedores[j].numeroSAP, 1);
//			listaProveedores[j].totalFase2 = this.getTotal(listaProveedores[j].numeroSAP, 2);
//			listaProveedores[j].total = listaProveedores[j].totalFase1 + listaProveedores[j].totalFase2;
//			listaProveedores[j].disponible = listaProveedores[j].total > 69;
//			if(!listaProveedores[j].disponible) {
//				listaProveedores[j].IMPORTE = 0;
//				listaProveedores[j].ID_ARCHIVO_PE = null;
//			}
//			listaProveedores[j].ganador = false;
//			if((j === 0 && listaProveedores[j].IMPORTE > 0)|| 
//					(listaProveedores[j].IMPORTE < montoGanador && listaProveedores[j].IMPORTE > 0)){
//				montoGanador = listaProveedores[j].IMPORTE;
//				proveedorGanador = listaProveedores[j].numeroSAP;
//			}
//		}
//		model.setProperty("/proveedorPropuesto", proveedorGanador);
//		this.marcaGanador(proveedorGanador);
//	},

});