sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.EnvioPropuesta", {

	getControllerName: function() {
		return sap.ui.getCore().AppContext.version+".view.EnvioPropuesta";
	},

    createDialogForo : function(oController, lang) {
		var textos = [
		              ["Preguntas y Respuestas", "Questions and Answers"],
		              ["Cerrar", "Close"],
		              ];
		try {sap.ui.getCore().getElementById('dialogForoEnET').destroy();} catch(err) {}
		var oDialog = new sap.ui.commons.Dialog("dialogForoEnET",
				{
					width: "95%",
					height: "95%",
					modal : true,
					closed : function(oControlEvent) {
						sap.ui.getCore().getElementById('dialogForoEnET')
								.destroy();
					}
				});
		oDialog.setTitle(textos[0][lang]);
		oController.modo = "p";
		oController.lang = lang;
		
        var foro = sap.ui.jsfragment(sap.ui.getCore().AppContext.version+".view.Foro", oController);
        
        oDialog.addContent(foro);
		oDialog.addButton(new sap.ui.commons.Button({
			text : textos[1][lang],
			press : function() {
				oDialog.close();
			}
		}));
		oDialog.open();
	},

	createContent: function(oController) {
        var formatter = new Intl.NumberFormat('en-US', {  
	          style: "currency",  
	          currency: "USD"  
	        });

		var numeroLicitacion = new sap.ui.commons.TextField("numeroLicitacion", {value:"{/numeroLicitacion}", width: "200px", editable: false});
		var descripcion = new sap.ui.commons.TextField("descripcion", {value:"{/descripcion}", editable: false});
		var fechaLimite = new sap.ui.commons.TextField("fechaLimite", {value:"{/fechaLimite}", width: "200px", editable: false});
		var importeEstimado = new sap.ui.commons.TextField("ponderacion3_1", {
			value:"", 
			width: "150px"
			,change : function(oEvent) {  
		        var value = oEvent.getSource().getValue();  
				var re = /\$|,/g;
				var floatValue = parseFloat(value.replace(re,''));
		        this.setValue(formatter.format(floatValue));  
			}
		});
		importeEstimado.attachBrowserEvent("focus", function() {
			if(this.getValue().trim()) {
				var re = /\$|,/g;
				var floatValue = parseFloat(this.getValue().replace(re,''));
				this.setValue(floatValue);
			}
		});
		var nombreEmpresa = new sap.ui.commons.TextField("nombreEmpresa", {value:"{/nombreEmpresa}", editable: false});

        var tablaArchivos = new sap.ui.table.Table("tablaArchivos", {
            visibleRowCount: 5,
            columnHeaderVisible: false,
            selectionMode: sap.ui.table.SelectionMode.None,
            width: "350px"
        });
        tablaArchivos.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Nombre"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            width: "250px"
        }));
        tablaArchivos.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Descargar"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("download"),
                press: function () {
                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
                			this.getBindingContext().getProperty("id") + 
                			"&fileName=" + this.getBindingContext().getProperty("nombre"), 
                			"_archivo" + this.getBindingContext().getProperty("id"),
                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                }
            })
        }));
        tablaArchivos.bindRows("/listaArchivosAdicionales");

        
		var oComboBoxMoneda = new sap.ui.commons.ComboBox("comboBoxMonedaEnvioProp",{
			tooltip: "Moneda",
			width: "100px",
			displaySecondaryValues: false,
			items : [
				new sap.ui.core.ListItem({key:"USD", text:"USD", additionalText:"Dólar Americano"}),
				new sap.ui.core.ListItem({key:"MXN", text:"MXN", additionalText:"Peso Mexicano"}),
				new sap.ui.core.ListItem({key:"EUR", text:"EUR", additionalText:"Euro"})]
		});

		////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
		var lang = 1;
		var textos = [
		              ["English", "Español"],
		              ["Enviar Información", "Send Proposal"],
		              ["Datos de la Licitación", "Bid Details"],
		              ["Número", "Number"],
		              ["Nombre del Proyecto o Servicio", "Project Name"],
		              ["Fecha Límite", "Deadline"],
		              ["Aviso Importante", "Important Notice"],
		              ["Aviso Importante: Toda licitación recibida por medio de este Portal deberá de ser ingresada a través del mismo. Quedan prohibidas las propuestas técnicas y económicas recibidas por cualquier otro medio, estás serán consideradas una violación a los lineamientos de la licitación y quedarán automáticamente descalificados.", 
		               "We encourage you to please take into consideration that all requests for quotation or proposals received through this Portal must be replied in the same manner. Any technical and/or economic proposals received by other means will be consider grounds for violation of requirements and will be automatically disqualified from the bid in question."],		               
		              ["Proveedor", "Provider"],
		              ["Nombre / Razón Social", "Name"],
		              ["Datos Para Recibir Notificaciones", "Contact Information"],
		              ["Propuesta", "Proposal"],
		              ["Propuesta Técnica", "Technical Proposal"],
		              ["Nota Propuesta Técnica: Ningún documento deberá contener datos económicos, en caso de incluirlos la propuesta quedará invalidada.", 
		               "Technical Proposal Note: Technical proposals shall not contain any monetary data in order to be considered."],
		              ["Propuesta Económica", "Economic Proposal"],
		              ["Nota Propuesta Económica: La propuesta económica deberá estar firmada por el representante legal, en caso de que no se presente la firma la participación queda invalidada.",
		               "Economic Proposal Note: Economic proposals shall contain a signature from the Legal Representative of the Company in order to be considered."],
		              ["Solo se permiten 1 archivo en formato PDF por propuesta. Máximo 50MB.", "Only PDF files allowed, 50MB Maximum"],
		              ["Importe Total en ", "Total Amount in "],
		              ["Nota: Colocar el monto total del presupuesto sin IVA, sumando todos los conceptos del catálogo de conceptos o para el caso de los contratos anuales sumar los precios unitarios considerados en el alcance.",
		               "Total Note: Please submit the grand total before taxes for the bid. Annual contracts must contemplate the total unitary prices considered in the scope."],
		              ["Enviar Propuesta", "Send Proposal"],
		              ["Archivos", "Files"],
		              ["Bases", "Guidelines"],
		              ["Alcance", "Scope"],
		              ["Documentos Adicionales", "Additional Documents"],
		              ["La moneda de su propuesta no coincide con la moneda de la licitación", "The currency of your proposal does not match the currency of the bid"],
		              ["Preguntas y Respuestas", "Questions and Answers"],
		              ["Cerrar", "Close"],
		              ["Salir", "Exit"],
		              ];

		var oForm = new sap.ui.layout.form.SimpleForm(
				"sf1",
				{
					layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
					editable: false,
					content:[
					         new sap.ui.core.Title("txt2", {text:textos[2][0]}),
					         new sap.ui.commons.Label("txt3", {text:textos[3][0]}),
					         numeroLicitacion,
					         new sap.ui.commons.Label("txt4", {text:textos[4][0]}),
					         descripcion,
					         new sap.ui.commons.Label("txt5", {text:textos[5][0]}),
					         fechaLimite,
					         new sap.ui.commons.Label("txt6", {text:textos[6][0]}),
				        	 new sap.ui.commons.TextView("txt7", {
				        		    text:textos[7][0],
				        			design: sap.ui.commons.TextViewDesign.Bold,
				        			semanticColor: sap.ui.commons.TextViewColor.Default,
		        			 }),

					         new sap.ui.core.Title("txt8", {text:textos[8][0]}),
					         new sap.ui.commons.Label("txt9", {text:textos[9][0]}),
					         nombreEmpresa,
					         new sap.ui.commons.Label("txt10", {text:textos[10][0]}),
					         new sap.ui.commons.TextField("contacto", {value:"{/correo}", width: "200px", editable: false}),

					         new sap.ui.core.Title("txt11", {text:textos[11][0]}),
					         new sap.ui.commons.Label("txt12", {text:textos[12][0]}),
					         new sap.ui.unified.FileUploader("archivoUno", {
					        	 uploadOnChange: true,
					        	 fileType: ["pdf"],
					        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
					        	 uploadComplete: function(oControlEvent) {
					        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
					        		 console.log(oControlEvent.getSource().getValue());
					        		 console.log(oControlEvent.getParameters().response.trim());
					        		 var res = oControlEvent.getParameters().response.trim().split('|');
					        		 oController.idPropuestaTecnica = res[1];
					        		 oController.nombrePropuestaTecnica = res[2].replace(/[^a-zA-Z.0-9]+/g,'');
					        	 }

					         }).attachTypeMissmatch(null,
					        		 function() {
				        	 		sap.ui.commons.MessageBox.alert("Solo se permiten archivos de tipo PDF/Only PDF type files", null, "Error"); 
				        		 }, null),
				        	 new sap.ui.commons.TextView("txt13", {text:textos[13][0],
				        			design: sap.ui.commons.TextViewDesign.Bold,
				        			semanticColor: sap.ui.commons.TextViewColor.Default,
				        	 }),
					         new sap.ui.commons.Label("txt14", {text:textos[14][0]}),
					         new sap.ui.unified.FileUploader("archivoDos", {
					        	 uploadOnChange: true,
					        	 fileType: ["pdf"],
					        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
					        	 uploadComplete: function(oControlEvent) {
					        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
					        		 console.log(oControlEvent.getSource().getValue());
					        		 console.log(oControlEvent.getParameters().response.trim());
					        		 var res = oControlEvent.getParameters().response.trim().split('|');
						        		 oController.idPropuestaEconomica = res[1];
						        		 oController.nombrePropuestaEconomica = res[2].replace(/[^a-zA-Z.0-9]+/g,'');
					        	 }}).attachTypeMissmatch(null,
						        		 function() {
					        	 		sap.ui.commons.MessageBox.alert("Solo se permiten archivos de tipo PDF/Only PDF type files", null, "Error"); 
					        		 }, null),
				        	 new sap.ui.commons.TextView("txt15", {text:textos[15][0],
				        			design: sap.ui.commons.TextViewDesign.Bold,
				        			semanticColor: sap.ui.commons.TextViewColor.Default,
				        	 }),
						         
					         new sap.ui.commons.Label({text:""}),
				        	 new sap.ui.commons.TextView("txt16", {text:textos[16][0],
				        			semanticColor: sap.ui.commons.TextViewColor.Positive,
		        			 }),
		        			  
					         new sap.ui.commons.Label("txt17", {text: {
						            path : "/moneda",
						            formatter : function(oVal) {
						                return textos[17][lang % 1] + oVal;
						            }
						        }, textAlign: "Center"}),
					         importeEstimado,
					         oComboBoxMoneda,
					         new sap.ui.commons.Label({text:""}),
				        	 new sap.ui.commons.TextView("txt18", {text:textos[18][0],
				        			design: sap.ui.commons.TextViewDesign.Bold,
				        			semanticColor: sap.ui.commons.TextViewColor.Default,
		        			 }),

					         new sap.ui.core.Title("txt20", {text:textos[20][0]}),
					         new sap.ui.commons.Label("txt21", {text:textos[21][0]}),
					         new sap.m.Link({
			                        text: "{/nombreArchivoBases}",
			                        href: "#",
			                        press: function(oControlEvent) {
			                        	var model = oController.getView().getModel();
			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
			                        			model.getProperty("/idArchivoBases") + 
			                        			"&fileName=" + model.getProperty("/nombreArchivoBases"), 
			                        			"indelproLicitacionesPDF", 
			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
			                        }
			                    }),
					         new sap.ui.commons.Label("txt22", {text:textos[22][0]}),
					         new sap.m.Link({
			                        text: "{/nombreArchivoEvaluacion}",
			                        href: "#",
			                        press: function(oControlEvent) {
			                        	var model = oController.getView().getModel();
			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
			                        			model.getProperty("/idArchivoEvaluacion") + 
			                        			"&fileName=" + model.getProperty("/nombreArchivoEvaluacion"), 
			                        			"indelproLicitacionesPDF", 
			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
			                        }
		                     }),
					         new sap.ui.commons.Label("txt23", {text:textos[23][0]}),
					         tablaArchivos,
					         ]
				});

		var oToolbar1 = new sap.ui.commons.Toolbar("toolBarCreaLic");
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		
		var oButton1 = new sap.ui.commons.Button("bEnviaPropuesta",{
			text : textos[1][0],
			press : function(event) {
            	var oModel = oController.getView().getModel();
				var moneda = oModel.getProperty("/moneda");
				var monedaSeleccionada = oComboBoxMoneda.getSelectedKey();
				if(moneda !== monedaSeleccionada) {
					sap.ui.commons.MessageBox.alert(textos[24][(lang+1) % 2], null, "Error");
					return;
				}
				var data = {
					numeroLicitacion: numeroLicitacion.getValue(), 
					importeEstimado: importeEstimado.getValue(),
					ID:  oModel.getProperty("/ID")
				};
				oController.onEnviar(data);
			}
		});
		oButton1.setIcon("sap-icon://complete");
		oToolbar1.addItem(oButton1);		
		
		var oButton2 = new sap.ui.commons.Button("bSwitchLang",{
			text : textos[0][0],
			press : function(event) {
            	var oModel = oController.getView().getModel();
				sap.ui.getCore().getControl("bSwitchLang").setText(textos[0][lang % 2]);
				sap.ui.getCore().getControl("bEnviaPropuesta").setText(textos[1][lang % 2]);
				sap.ui.getCore().getControl("txt2").setText(textos[2][lang % 2]);
				sap.ui.getCore().getControl("txt3").setText(textos[3][lang % 2]);
				sap.ui.getCore().getControl("txt4").setText(textos[4][lang % 2]);
				sap.ui.getCore().getControl("txt5").setText(textos[5][lang % 2]);
				sap.ui.getCore().getControl("txt6").setText(textos[6][lang % 2]);
				sap.ui.getCore().getControl("txt7").setText(textos[7][lang % 2]);
				sap.ui.getCore().getControl("txt8").setText(textos[8][lang % 2]);
				sap.ui.getCore().getControl("txt9").setText(textos[9][lang % 2]);
				sap.ui.getCore().getControl("txt10").setText(textos[10][lang % 2]);
				sap.ui.getCore().getControl("txt11").setText(textos[11][lang % 2]);
				sap.ui.getCore().getControl("txt12").setText(textos[12][lang % 2]);
				sap.ui.getCore().getControl("txt13").setText(textos[13][lang % 2]);
				sap.ui.getCore().getControl("txt14").setText(textos[14][lang % 2]);
				sap.ui.getCore().getControl("txt15").setText(textos[15][lang % 2]);
				sap.ui.getCore().getControl("txt16").setText(textos[16][lang % 2]);
				sap.ui.getCore().getControl("txt17").setText(textos[17][lang % 2] + oModel.getProperty("/moneda"));
				sap.ui.getCore().getControl("txt18").setText(textos[18][lang % 2]);
				sap.ui.getCore().getControl("txt20").setText(textos[20][lang % 2]);
				sap.ui.getCore().getControl("txt21").setText(textos[21][lang % 2]);
				sap.ui.getCore().getControl("txt22").setText(textos[22][lang % 2]);
				sap.ui.getCore().getControl("txt23").setText(textos[23][lang % 2]);
				sap.ui.getCore().getControl("bAbreForo").setText(textos[25][lang % 2]);
				sap.ui.getCore().getControl("bLogout").setText(textos[27][lang % 2]);
//				oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader(textos[19][lang % 2]);
//				page.setCustomHeader(oBar);  
				lang++;
			}
		});
		oButton2.setIcon("sap-icon://globe");
		oToolbar1.addItem(oButton2);		
		
		var oButtonForo = new sap.ui.commons.Button("bAbreForo",{
			text : textos[25][0],
			press : function(event) {
            	var oModel = oController.getView().getModel();
            	oController.getView().createDialogForo(oController, (lang+1) % 2);
			}
		});
		oButtonForo.setIcon("sap-icon://sys-help");
		oToolbar1.addItem(oButtonForo);		
		
		var oButtonLogout = new sap.ui.commons.Button("bLogout",{
			text : textos[27][0],
			press : function(event) {
            	oController.logout();
			}
		});
		oButtonLogout.setIcon("sap-icon://log");
		oToolbar1.addItem(oButtonLogout);		
		
		
		var page = new sap.m.Page();

		oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Enviar Propuesta");
		page.setCustomHeader(oBar);  
		page.setEnableScrolling(true);
		page.addContent(oForm);
		page.addContent(oToolbar1);
		return page;
	}

});