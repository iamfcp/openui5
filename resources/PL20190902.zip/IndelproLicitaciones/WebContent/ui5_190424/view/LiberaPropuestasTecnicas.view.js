sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.LiberaPropuestasTecnicas", {

	getControllerName: function() {
		return sap.ui.getCore().AppContext.version+".view.LiberaPropuestasTecnicas";
	},

    createDialog: function(oController, nl) {
        var oDialog = new sap.ui.commons.Dialog("dialogClaveLiberacion", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogClaveLiberacion').destroy();
            }
        });
        oDialog.setTitle("Ingrese clave de liberación");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "300px"
        });
        
        var tfClaveLib = new sap.m.Input({
            id: "lptClaveLib",
            type: sap.m.InputType.Password,
            placeholder: "Clave de liberación",
        });
        oLayout.createRow(tfClaveLib);
        
        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: "Aceptar", press:function(){
	        oController.liberaPT(tfClaveLib.getValue(), nl);
            oDialog.close();
        }}));
        oDialog.open();
    },

    creaPanelLicitacion: function(oController) {
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaProveedores = new sap.ui.table.TreeTable("tablaProveedoresLiberaPT", {
            visibleRowCount: sap.ui.table.VisibleRowCountMode.Auto,
            selectionMode: sap.ui.table.SelectionMode.None,
        	expandFirstLevel: true
        });
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "nombre"),
            width: "400px",
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Propuesta Técnica", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
                press: function () {
                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PT");
                	if(pdf)
	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
	                			pdf + 
	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PT"), 
	                			"indelproLicitacionesPDF", 
	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                	else
        				sap.ui.commons.MessageBox.show("No se ha cargado el documento",
        		                sap.ui.commons.MessageBox.Icon.WARNING,
        		                "Advertencia",
        		                [sap.ui.commons.MessageBox.Action.OK],
        		                '', sap.ui.commons.MessageBox.Action.OK);
                }
            }).bindProperty("visible", "NOT_LINEBREAK")
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Fecha Envío", textAlign: "Center"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "FECHA_ENVIO").bindProperty("visible", "NOT_LINEBREAK"),
            hAlign: "Center" 
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Autorizada para Liberar", textAlign: "Center"}),
            template: new sap.ui.commons.CheckBox({enabled: true
            			}).bindProperty("checked", "LIBERADA").bindProperty("visible", "NOT_LINEBREAK"),
            hAlign: "Center" 
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "NO Autorizada para Liberar", textAlign: "Center"}),
            template: new sap.ui.commons.CheckBox({enabled: true
            			}).bindProperty("checked", "NOLIBERADA").bindProperty("visible", "NOT_LINEBREAK"),
            hAlign: "Center" 
        }));
        tablaProveedores.bindRows("/listaProveedores");
        

        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 4,
            width: "90%"
        });
        
		var oToolbar1 = new sap.ui.commons.Toolbar();
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		var oButton1 = new sap.ui.commons.Button({
			text : "Regresar",
			press : function(event) {
				oController.veAListado();
			}
		});
		oButton1.setIcon("sap-icon://nav-back");
		oToolbar1.addItem(oButton1);		
        oLayout.createRow(oToolbar1);
        
        oLayout.createRow(new sap.ui.commons.Label({text:"Datos de la Licitación", design: "Bold"}));
        oLayout.createRow(new sap.ui.commons.Label({text:"Número"}), 
        		new sap.ui.commons.TextField("numeroLicitacionLiberaPT", {value:"{/numeroLicitacion}", editable: false, width: "200px"}));
        oLayout.createRow(new sap.ui.commons.Label({text:"Estatus"}),
        		new sap.ui.commons.Label("estatusLicitacionLiberaPT", {text: {
    	            path : "/estatus",
    	            formatter : function(oVal) {
    	                return sap.ui.getCore().byId("MainAppView").getController().descripcionEstatus(oVal);
    	            }
    	        }}));
        oLayout.createRow(
        		new sap.ui.commons.layout.MatrixLayoutCell(
                		{content: [new sap.ui.commons.Label({text:"Descripción"})] }),
	    		new sap.ui.commons.layout.MatrixLayoutCell(
	    	       		{content: [new sap.ui.commons.TextField("descripcionLicitacionLiberaPT", {value:"{/descripcion}", editable: false, width: "400px"})],
	    	       		 colSpan: 2 })
		        );
        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [tablaProveedores],
        		 colSpan: 4 }));


		var oToolbar1 = new sap.ui.commons.Toolbar("toolBarLiberaPTLic");
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		
		var oButton1 = new sap.ui.commons.Button("bLiberaPT",{
			text : "Liberar Propuestas Técnicas",
			tooltip : "Liberar Propuestas Técnicas",
			press : function(event) {
//				var data = {{textAlign: "Center"}
//					numeroLicitacion: numeroLicitacion.getValue(), 
//					importeEstimado: importeEstimado.getValue(),
//					descripcion: descripcion.getValue(),
//					fechaLimite: fechaLimite.getYyyymmdd(),
//					responsable: oComboBoxResponsable.getSelectedKey(),
//					tipo: oComboBoxTipoLic.getSelectedKey(),
//					elementoPEP: elementoPEP.getValue()
//				};
//				oController.onGuardar(data);
				if(oController.valida())
					oController.getView().createDialog(oController, 
							sap.ui.getCore().byId("numeroLicitacionLiberaPT").getValue()); 
			}
		});
		oButton1.setIcon("sap-icon://accept");
		oToolbar1.addItem(oButton1);		
        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [oToolbar1],
        		 colSpan: 4 }));    	
        
        return oLayout;
    },
    
    creaListadoSolicitudes: function(oController) {

        //Create an instance of the table control
        var oTable = new sap.ui.table.Table("tableListaLicLiberaPT", {
                title: "Licitaciones Disponibles para Liberación",
                visibleRowCount: 10,
                firstVisibleRow: 1,
                selectionMode: sap.ui.table.SelectionMode.None
        });


        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Número"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "numeroLicitacion"),
            width: "100px",
            sortProperty: "numeroLicitacion",
            filterProperty: "numeroLicitacion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Descripción"}),
                template: new sap.ui.commons.TextField().bindProperty("value", "descripcion"),
                width: "150px",
                sortProperty: "descripcion",
                filterProperty: "descripcion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Estatus"}),
            template: new sap.ui.commons.Label({text: {
	            path : "estatus",
	            formatter : function(oVal) {
	                return sap.ui.getCore().byId("MainAppView").getController().descripcionEstatus(oVal);
	            }
	        }}),
            width: "100px",
            sortProperty: "estatus",
            filterProperty: "estatus"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Liberar", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            width: "80px",
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("edit"),
                press: function () {
                	console.log(this.getBindingContext().getProperty("numeroLicitacion"));
                	oController.veALicitacion(this.getBindingContext().getProperty("numeroLicitacion"));
                }
            })
        }));
        
		oTable.bindRows("/licitaciones");

        // create a simple matrix layout
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
                layoutFixed : true
                });
        
        oLayout.createRow( oTable );

        return oLayout;
    },
    
    createContent: function(oController) {
		var page = new sap.m.Page();
		oController.pagina = page;
		oController.panelLicitacion = this.creaPanelLicitacion(oController);
		oController.panelLista = this.creaListadoSolicitudes(oController);
		var oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Liberar Propuestas Técnicas");
		page.setCustomHeader(oBar);  
		page.setEnableScrolling(true);
		page.addContent(oController.panelLista);
//		page.addContent(oController.panelLista);
		return page;
	},

});