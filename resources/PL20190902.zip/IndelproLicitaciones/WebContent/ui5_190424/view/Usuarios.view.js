sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.Usuarios", {

    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.Usuarios";
    },

    createDialog: function(oController, modo, usuarioAct) {
        var oDialog = new sap.ui.commons.Dialog("dialogCreaUsuario", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogCreaUsuario').destroy();
            }
        });
        oDialog.setTitle(modo === 'new'? "Nuevo Usuario": "Actualizar Usuario");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            width: "100%"
        });
        var oChkAct = new sap.ui.commons.CheckBox("cActivo", {
            tooltip: 'Activo',
            editable: true,
            visible: false,
            checked : modo !== 'new'? usuarioAct.activo : true
        });
        var oLabel = new sap.ui.commons.Label("lActivo", {
            text: '',//'Activo',
            labelFor: oChkAct
        });
        oLayout.createRow(oLabel, oChkAct);
        var oTF = new sap.ui.commons.TextField("tUsuario", {
            tooltip: 'Usuario',
            editable: modo === 'new',
            width: '150px',
            required: true,
            value: modo !== 'new'? usuarioAct.usuario : ''
        });
        oLabel = new sap.ui.commons.Label("lUsuario", {
            text: 'Usuario',
            labelFor: oTF
        });
        oLayout.createRow(oLabel, oTF);
        oTF = new sap.ui.commons.TextField("tNombre", {
            tooltip: 'Nombre',
            editable: true,
            width: '300px',
            required: true,
            value: modo !== 'new'? usuarioAct.nombre : ''
        });
        oLabel = new sap.ui.commons.Label("lNombre", {
            text: 'Nombre',
            labelFor: oTF
        });
        oLayout.createRow(oLabel, oTF);
        oTF = new sap.ui.commons.TextField("tCorreo", {
            tooltip: 'Correo',
            editable: true,
            width: '250px',
            required: true,
            value: modo !== 'new'? usuarioAct.correo : ''
        });
        oLabel = new sap.ui.commons.Label("lCorreo", {
            text: 'Correo',
            labelFor: oTF
        });
        oLayout.createRow(oLabel, oTF);
        oTF = new sap.ui.commons.TextField("tDepartamento", {
            tooltip: 'Departamento',
            editable: true,
            width: '300px',
            required: true,
            value: modo !== 'new'? usuarioAct.departamento : ''
        });
        oLabel = new sap.ui.commons.Label("ldepartamento", {
            text: 'Departamento',
            labelFor: oTF
        });
        oLayout.createRow(oLabel, oTF);
        oChkAct = new sap.ui.commons.CheckBox("cLiberaPT", {
            tooltip: 'Libera P T',
            editable: true,
            checked : modo !== 'new'? usuarioAct.liberaPT : false
        });
        oLabel = new sap.ui.commons.Label("lLiberaPT", {
            text: 'Libera P.T.',
            labelFor: oChkAct
        });
        oLayout.createRow(oLabel, oChkAct);
        oChkAct = new sap.ui.commons.CheckBox("cLiberaPE", {
            tooltip: 'Libera P E',
            editable: true,
            checked : modo !== 'new'? usuarioAct.liberaPE : false
        });
        oLabel = new sap.ui.commons.Label("lLiberaPE", {
            text: 'Libera P.E.',
            labelFor: oChkAct
        });
        oLayout.createRow(oLabel, oChkAct);
        oChkAct = new sap.ui.commons.CheckBox("cComite", {
            tooltip: 'Comité',
            editable: true,
            checked : modo !== 'new'? usuarioAct.comite : false
        });
        oLabel = new sap.ui.commons.Label("lComite", {
            text: 'Comité',
            labelFor: oChkAct
        });
        oLayout.createRow(oLabel, oChkAct);
        oChkAct = new sap.ui.commons.CheckBox("cAbastecimientos", {
            tooltip: 'Abastecimientos',
            editable: true,
            checked : modo !== 'new'? usuarioAct.abastecimientos : false
        });
        oLabel = new sap.ui.commons.Label("lAbastecimientos", {
            text: 'Abastecimientos',
            labelFor: oChkAct
        });
        oLayout.createRow(oLabel, oChkAct);
        oChkAct = new sap.ui.commons.CheckBox("cEvalTec", {
            tooltip: 'Eval. Técnico',
            editable: true,
            checked : modo !== 'new'? usuarioAct.evalTecnico : false
        });
        oLabel = new sap.ui.commons.Label("lEvalTec", {
            text: 'Eval. Técnico',
            labelFor: oChkAct
        });
        oLayout.createRow(oLabel, oChkAct);
        oChkAct = new sap.ui.commons.CheckBox("cDirectorGeneral", {
            tooltip: 'Gerente Abastecimientos',
            editable: true,
            checked : modo !== 'new'? usuarioAct.directorGeneral : false
        });
        oLabel = new sap.ui.commons.Label("lDirectorGeneral", {
            text: 'Gerente Abastecimientos',
            labelFor: oChkAct
        });
        oLayout.createRow(oLabel, oChkAct);
        
		var oModelListUsr = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaUsuarios.action");
		oModelListUsr.attachRequestCompleted(null, function() { 
			oModelListUsr.getProperty("/usuarios").push({'usuario':'','nombre':''})
			oModelListUsr.refresh();
		});
        var cBJefe = new sap.ui.commons.ComboBox("cbJefe", {
            tooltip: 'Jefe',
            editable: true,
            selectedKey : modo !== 'new'? usuarioAct.jefe : ''
        });
        cBJefe.setModel(oModelListUsr);
        var oItemTemplate1 = new sap.ui.core.ListItem();
        oItemTemplate1.bindProperty("text", "nombre");
        oItemTemplate1.bindProperty("key", "usuario");
        cBJefe.bindItems("/usuarios", oItemTemplate1);
        oLabel = new sap.ui.commons.Label("lJefe", {
            text: 'Jefe',
            labelFor: cBJefe
        });
        oLayout.createRow(oLabel, cBJefe);

        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: modo === 'new'? "Crear": "Guardar Cambios", 
        	press:function(){
	            var data = { 
	                "activo": sap.ui.getCore().getControl("cActivo").getChecked(),
	                "usuario": sap.ui.getCore().getControl("tUsuario").getValue().trim(),
	                "jefe": sap.ui.getCore().getControl("cbJefe").getSelectedKey().trim(),
	                "nombre": sap.ui.getCore().getControl("tNombre").getValue().trim(),
	                "correo": sap.ui.getCore().getControl("tCorreo").getValue().trim(),
	                "departamento": sap.ui.getCore().getControl("tDepartamento").getValue().trim(),
	                "liberaPE": sap.ui.getCore().getControl("cLiberaPE").getChecked(),
	                "liberaPT": sap.ui.getCore().getControl("cLiberaPT").getChecked(),
	                "abastecimientos": sap.ui.getCore().getControl("cAbastecimientos").getChecked(),
	                "comite": sap.ui.getCore().getControl("cComite").getChecked(),
	                "evalTecnico": sap.ui.getCore().getControl("cEvalTec").getChecked(),
	                "directorGeneral": sap.ui.getCore().getControl("cDirectorGeneral").getChecked()
	            };
	            oController.createUpdate(data, modo);
	            oDialog.close();
	        }
        }));
        oDialog.open();
    },

    createContent: function(oController) {

        var page = new sap.m.Page({
            title: "Administración de Usuarios"
        });

        var oTable = new sap.ui.table.Table("tableUsuarios", {
                title: "Usuarios",
                visibleRowCountMode: sap.ui.table.VisibleRowCountMode.Auto,
                selectionMode: sap.ui.table.SelectionMode.Single,
                toolbar: new sap.ui.commons.Toolbar({items: [
                        new sap.ui.commons.Button({text: "Nuevo Usuario", press: function() { oController.getView().createDialog(oController, 'new'); }}),
                        new sap.ui.commons.Button({text: "Actualizar", press: function() { 
                        	oController.getView().createDialog(oController, 'act', oTable.getContextByIndex(oTable.getSelectedIndex()).getObject());  }})
                ]})
        });


//        oTable.addColumn(new sap.ui.table.Column({
//                label: new sap.ui.commons.Label({text: "Activo"}),
//                template: new sap.ui.commons.CheckBox().bindProperty("checked", "activo").setEditable(false),
//    			flexible: true,
//    			resizable: true,
//    			autoResizable: true,
//                sortProperty: "activo",
//                filterProperty: "activo",
//                width: "75px",
//                hAlign: "Center"
//        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Usuario"}),
                template: new sap.ui.commons.TextField().bindProperty("value", "usuario").setEditable(false),
    			flexible: true,
    			resizable: true,
    			autoResizable: true,
                sortProperty: "usuario",
                filterProperty: "usuario"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Correo"}),
                template: new sap.ui.commons.TextField().bindProperty("value", "correo").setEditable(false),
    			flexible: true,
    			resizable: true,
    			autoResizable: true,
                sortProperty: "correo",
                filterProperty: "correo"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Nombre"}),
                template: new sap.ui.commons.TextField().bindProperty("value", "nombre").setEditable(false),
    			flexible: true,
    			resizable: true,
    			autoResizable: true,
                sortProperty: "nombre",
                filterProperty: "nombre"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Departamento"}),
			flexible: true,
			resizable: true,
			autoResizable: true,
            template: new sap.ui.commons.TextField().bindProperty("value", "departamento").setEditable(false),
            sortProperty: "departamento",
            filterProperty: "departamento"
    }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Jefe"}),
			flexible: true,
			resizable: true,
			autoResizable: true,
            template: new sap.ui.commons.TextField().bindProperty("value", "jefe").setEditable(false),
            sortProperty: "jefe",
            filterProperty: "jefe"
    }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Comité"}),
            template: new sap.ui.commons.CheckBox().bindProperty("checked", "comite").setEditable(false),
			flexible: true,
			resizable: true,
			autoResizable: true,
           sortProperty: "comite",
            filterProperty: "comite",
            width: "85px",
            hAlign: "Center"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Abastecimientos"}),
            template: new sap.ui.commons.CheckBox().bindProperty("checked", "abastecimientos").setEditable(false),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "abastecimientos",
            filterProperty: "abastecimientos",
            width: "85px",
            hAlign: "Center"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Evaluador Técnico", wrapping: true}),
            template: new sap.ui.commons.CheckBox().bindProperty("checked", "evalTecnico").setEditable(false),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "evalTecnico",
            filterProperty: "evalTecnico",
            width: "85px",
            hAlign: "Center"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Libera Propuestas Técnicas", wrapping: true}),
            template: new sap.ui.commons.CheckBox().bindProperty("checked", "liberaPT").setEditable(false),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "liberaPT",
            filterProperty: "liberaPT",
            width: "85px",
            hAlign: "Center"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Libera Propuestas Económicas", wrapping: true}),
            template: new sap.ui.commons.CheckBox().bindProperty("checked", "liberaPE").setEditable(false),
			flexible: true,
			resizable: true,
			autoResizable: true,
			sortProperty: "liberaPE",
            filterProperty: "liberaPE",
            width: "85px",
            hAlign: "Center"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Gerente Abastecimientos", wrapping: true}),
            template: new sap.ui.commons.CheckBox().bindProperty("checked", "directorGeneral").setEditable(false),
			flexible: true,
			resizable: true,
			autoResizable: true,
			sortProperty: "directorGeneral",
            filterProperty: "directorGeneral",
            width: "85px",
            hAlign: "Center"
        }));
        
        // create a simple matrix layout
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
                id : "matrix1",
                layoutFixed : true,
                height: "100%"
                });


        oLayout.createRow( oTable );


        page.setEnableScrolling(true);
		oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Administración de Usuarios");
        page.setCustomHeader(oBar);
        page.addContent(oLayout);
        //Bring the table onto the UI


        return page;
    },
    
});        
        