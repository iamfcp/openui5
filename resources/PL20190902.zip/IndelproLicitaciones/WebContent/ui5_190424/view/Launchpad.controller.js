sap.ui.controller(sap.ui.getCore().AppContext.version+".view.Launchpad", {
	
    onInit: function() {
        this.bus = sap.ui.getCore().getEventBus();
    },

	doNavOnSelect : function (target) {
		if(!sap.ui.getCore().byId("MainAppView").getController().revisaSesion())
			return;
		if(sap.ui.getCore().byId(target).getController().inicializa)
        	sap.ui.getCore().byId(target).getController().inicializa();
		this.bus.publish("nav", "to", {
			id : target
		});
	}	

});