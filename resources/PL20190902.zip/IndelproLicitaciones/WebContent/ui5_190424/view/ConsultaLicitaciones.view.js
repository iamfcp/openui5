sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.ConsultaLicitaciones", {

    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.ConsultaLicitaciones";
    },

    createDialogForo : function(oController, lang) {
		var textos = [
		              ["Preguntas y Respuestas", "Questions and Answers"],
		              ["Cerrar", "Close"],
		              ];
		try {sap.ui.getCore().getElementById('dialogForoEnET').destroy();} catch(err) {}
		var oDialog = new sap.ui.commons.Dialog("dialogForoEnET",
				{
					width: "95%",
					height: "95%",
					modal : true,
					closed : function(oControlEvent) {
						sap.ui.getCore().getElementById('dialogForoEnET')
								.destroy();
					}
				});
		oDialog.setTitle(textos[0][lang]);
		oController.lang = lang;
		
        var foro = sap.ui.jsfragment(sap.ui.getCore().AppContext.version+".view.Foro", oController);
        
        oDialog.addContent(foro);
		oDialog.addButton(new sap.ui.commons.Button({
			text : textos[1][lang],
			press : function() {
				oDialog.close();
			}
		}));
		oDialog.open();
	},

    createDialogProveedoresAdic: function(oController, nl) {
        var oDialog = new sap.ui.commons.Dialog("dialogProveedoresAdic", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogProveedoresAdic').destroy();
            }
        });
        oDialog.setTitle("Seleccione Proveedores Adicionales");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "700px"
        });
        var oTableP = new sap.ui.table.Table({
            visibleRowCount: 5,
            firstVisibleRow: 1,
            selectionMode: sap.ui.table.SelectionMode.Multiple
        });
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Núm. SAP"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
            width: "100px",
            sortProperty: "numeroSAP",
            filterProperty: "numeroSAP"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Correo"}),
            template: new sap.ui.commons.TextField({editable: false,
//            	change: function(oControlEvent){
//    				var data = {
//						"numeroSAP": this.getBindingContext().getProperty("numeroSAP"), 
//						"rfc": this.getBindingContext().getProperty("rfc"), 
//						"correo": oControlEvent.getParameters().newValue, 
//						"nombre": this.getBindingContext().getProperty("nombre"), 
//						"notas": this.getBindingContext().getProperty("notas")
//					};
//					oController.actualizaProveedor(data);
//            	},
            	value: {
                    path: "correo",
                    type: new sap.ui.model.type.String()
                }
            }),
            sortProperty: "correo",
            filterProperty: "correo"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Notas"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "notas"),
            sortProperty: "notas",
            filterProperty: "notas"
        }));
		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaProveedores.action");
		oTableP.setModel(oModel);
		oTableP.bindRows("/proveedores");
        oLayout.createRow(oTableP);
        
        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: "Usar Seleccionados", press:function(){
        	var selInd = oTableP.getSelectedIndices();
        	var ok = true;
			for (i=0; i<selInd.length; ++i) {
				oController.listaProveedoresAdicionales.push(oTableP.getContextByIndex(selInd[i]).getObject());
				if(!oTableP.getContextByIndex(selInd[i]).getObject().correo) 
					ok = false;
			}
			if(!ok)
				sap.ui.commons.MessageBox.alert("Algunos de los proveedores seleccionados no tienen correo registrado", null, "Advertencia");
			var data = {
				numeroLicitacion: nl,
				listaProveedoresAdicionales: oController.listaProveedoresAdicionales
			};
			oController.onInvitarAdicionales(data);
            oDialog.close();
        }}));
        oDialog.open();
    },
    
    createDialogBorraProveedores: function(oController, nl) {
        var oDialog = new sap.ui.commons.Dialog("dialogBorraProveedores", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogBorraProveedores').destroy();
            }
        });
        oDialog.setTitle("Seleccione Proveedores a Eliminar");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "700px"
        });
        var oTableP = new sap.ui.table.Table({
            visibleRowCount: 5,
            firstVisibleRow: 1,
            selectionMode: sap.ui.table.SelectionMode.Multiple
        });
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Núm. SAP"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
            width: "100px",
            sortProperty: "numeroSAP",
            filterProperty: "numeroSAP"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Correo"}),
            template: new sap.ui.commons.TextField({editable: false,
            	value: {
                    path: "correo",
                    type: new sap.ui.model.type.String()
                }
            }),
            sortProperty: "correo",
            filterProperty: "correo"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Notas"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "notas"),
            sortProperty: "notas",
            filterProperty: "notas"
        }));
		var oModel = oController.getView().getModel();
		oTableP.setModel(oModel);
		console.log(oModel);
		oTableP.bindRows("/listaProveedores");
        oLayout.createRow(oTableP);
        
        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: "Borrar Seleccionados", press:function(){
        	var selInd = oTableP.getSelectedIndices();
        	var ok = true;
        	var listaProveedoresBorrar = [];
			for (i=0; i<selInd.length; ++i) {
				listaProveedoresBorrar.push(oTableP.getContextByIndex(selInd[i]).getObject());
			}
			var data = {
				numeroLicitacion: nl,
				listaProveedoresBorrar: listaProveedoresBorrar
			};
			oController.onBorraProveedores(data);
            oDialog.close();
        }}));
        oDialog.open();
    },
    createDialogAmpliarPlazo: function(oController, nl) {
        var oDialog = new sap.ui.commons.Dialog("dialogAmpliarPlazoLiberacion", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogAmpliarPlazoLiberacion').destroy();
            }
        });
        oDialog.setTitle("Ingrese nueva fecha límite " + nl);
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "300px"
        });
        
        var nuevaFecha = new sap.ui.commons.DatePicker("nuevaFechaLimite", {yyyymmdd:"", width: "200px"});
        oLayout.createRow(nuevaFecha);
        
        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: "Aceptar", press:function(){
			var data = {
					numeroLicitacion: nl,	
					fechaLimite: nuevaFecha.getYyyymmdd(),
				};
	        oController.onAmpliarPlazo(data);
            oDialog.close();
        }}));
        oDialog.addButton(new sap.ui.commons.Button({text: "Cancelar", press:function(){
            oDialog.close();
        }}));
        oDialog.open();
    },

    createDialogReasignar: function(oController) {
        var oDialog = new sap.ui.commons.Dialog("dialogcreateDialogReasignar", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogcreateDialogReasignar').destroy();
            }
        });
        var model = oController.getView().getModel();
        var nl = model.getProperty("/numeroLicitacion");

        oDialog.setTitle("Confirme Reasignación licitación: " + nl);
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "550px"
        });
        
        var filtroPasaEvalNuevo = new  sap.ui.model.Filter('total', "GE", 70);  
        var filtroGanadorActual = new  sap.ui.model.Filter('ganador', "NE", true);  
        
		var oComboBoxProveedores = new sap.ui.commons.ComboBox({
			tooltip: "Seleccione otro ganador",
			width: "400px"
		});
		oComboBoxProveedores.setModel(model);
		var oItemListaProvReasig = new sap.ui.core.ListItem();
		oItemListaProvReasig.bindProperty("key", "numeroSAP");
		oItemListaProvReasig.bindProperty("text", "nombre");
		oItemListaProvReasig.bindProperty("enabled", "LIBERADA");
		oComboBoxProveedores.bindItems("/listaProveedores", oItemListaProvReasig);
		oComboBoxProveedores.getBinding("items").filter(filtroPasaEvalNuevo);
        oLayout.createRow(new sap.m.Label({text: "Seleccione otro ganador"}));
        oLayout.createRow(oComboBoxProveedores);

		var label = new sap.m.Label({text: "Comentario de Justificación"});
        oLayout.createRow(label);
        var tComentario = new sap.ui.commons.TextArea({value: "", width: "490px", rows: 10});
        oLayout.createRow(tComentario);
        
        oDialog.addContent(oLayout);
		oDialog.addButton(new sap.ui.commons.Button({
			text : "Finalizar",
			press : function() {
				var nuevoGanador = oComboBoxProveedores.getSelectedKey();
				if(!nuevoGanador) {
					sap.ui.commons.MessageBox.alert("No ha seleccionado un nuevo ganador", null, "Error");
					return;
				}
				oDialog.close();
				var data = {
					numeroLicitacion: nl,
					nuevoGanador: nuevoGanador,
					mensajeReasignacion: tComentario.getValue()
				};
				oController.onReasignar(data);
			}
		}));
		oDialog.addButton(new sap.ui.commons.Button({
			text : "Cancelar",
			press : function() {
				oDialog.close();
			}
		}));
		oDialog.open();
    },

    createListado: function(oController) {
	    var oTable = new sap.ui.table.Table("tableLicitaciones", {
            title: "Licitaciones",
            visibleRowCount: 10,
            firstVisibleRow: 1,
            selectionMode: sap.ui.table.SelectionMode.None//,
//            toolbar: new sap.ui.commons.Toolbar({items: [
//                    new sap.ui.commons.Button({text: "Nuevo Proveedor", press: function() { oController.getView().createDialog(oController); }})
//            ]})
	    });
	
	
	    oTable.addColumn(new sap.ui.table.Column({
	        label: new sap.ui.commons.Label({text: "Número"}),
	        template: new sap.ui.commons.TextField().bindProperty("value", "numeroLicitacion"),
	        width: "100px",
	        sortProperty: "numeroLicitacion",
	        filterProperty: "numeroLicitacion"
	    }));
	    oTable.addColumn(new sap.ui.table.Column({
	        label: new sap.ui.commons.Label({text: "Fecha Límite"}),
//	        template: new sap.ui.commons.TextField().bindProperty("value", "fechaLimite"),
	        template: new sap.m.Label({                       
	            text: {
	                path : "fechaLimite",
	                formatter : function(oVal) {
	                    return oController.formateaFecha(oVal);
	                }
	            }
	        }),
	        width: "100px",
	        sortProperty: "fechaLimite",
	        filterProperty: "fechaLimite"
	    }));
	    oTable.addColumn(new sap.ui.table.Column({
	            label: new sap.ui.commons.Label({text: "Descripción"}),
	            template: new sap.ui.commons.TextField().bindProperty("value", "descripcion"),
	            width: "150px",
	            sortProperty: "descripcion",
	            filterProperty: "descripcion"
	    }));
	    oTable.addColumn(new sap.ui.table.Column({
	        label: new sap.ui.commons.Label({text: "Estatus"}),
	        template: new sap.ui.commons.Label({text: {
	            path : "estatus",
	            formatter : function(oVal) {
	                return sap.ui.getCore().byId("MainAppView").getController().descripcionEstatus(oVal);
	            }
	        }}),
	        width: "300px",
	        sortProperty: "estatus",
	        filterProperty: "estatus"
	    }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Detalle", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            width: "80px",
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("detail-view"),
                press: function () {
                	oController.veALicitacion(this.getBindingContext().getProperty("numeroLicitacion"));
                }
            })
        }));
	
	
		//Create a model and bind the table rows to this model
		var oModel = new sap.ui.model.json.JSONModel();
		oTable.setModel(oModel);
		oTable.bindRows("/licitaciones");
	
	    //Initially sort the table
	    oTable.sort(oTable.getColumns()[1]);
	
		var oComboBoxEstatus = new sap.ui.commons.ComboBox("oComboBoxEstatus",{
			tooltip: "Estatus",
			width: "200px",
			items: [new sap.ui.core.ListItem({text: "", key: -1}),
			        new sap.ui.core.ListItem({text: "Nueva", key: 0}),
			        new sap.ui.core.ListItem({text: "Licitación enviada", key: 1}),
			        new sap.ui.core.ListItem({text: "Disponible para Liberación", key: 2}),
			        new sap.ui.core.ListItem({text: "Disponible para Evaluación Técnica", key: 3}),
			        new sap.ui.core.ListItem({text: "Pendiente de Junta de Comité", key: 4}),
			        new sap.ui.core.ListItem({text: "Propuesta Económica Liberada", key: 5}),
			        new sap.ui.core.ListItem({text: "Pendiente de Aprobación", key: 6}),
			        new sap.ui.core.ListItem({text: "Concluída", key: 7}),
			        new sap.ui.core.ListItem({text: "Cancelada", key: 8}),
			        new sap.ui.core.ListItem({text: "Reasignada", key: 9})],
		});
		var oModelListUsr = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaUsuarios.action");
		oModelListUsr.attachRequestCompleted(null, function() { 
			oModelListUsr.getProperty("/usuarios").push({'usuario':'','nombre':'','abastecimientos':true})
			oModelListUsr.refresh();
		});
		var oFilterComprador = new sap.ui.model.Filter("abastecimientos", sap.ui.model.FilterOperator.EQ, true);
        var cBComprador = new sap.ui.commons.ComboBox("cBComprador", {
            tooltip: 'Comprador',
            editable: true,
        });
        cBComprador.setModel(oModelListUsr);
        var oItemTemplate1 = new sap.ui.core.ListItem();
        oItemTemplate1.bindProperty("text", "nombre");
        oItemTemplate1.bindProperty("key", "usuario");
        cBComprador.bindItems("/usuarios", oItemTemplate1);
        cBComprador.getBinding("items").filter([oFilterComprador]);
		
		var oForm = new sap.ui.layout.form.SimpleForm(
				"sfBusqLic",
				{
					layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
					editable: false,
					content:[
					         new sap.ui.core.Title({text:"Fecha"}),
					         new sap.ui.commons.Label({text:"Desde"}),
					         new sap.ui.commons.DatePicker("busqDesde", {yyyymmdd:"", width: "200px"}),
					         new sap.ui.commons.Label({text:"Hasta"}),
					         new sap.ui.commons.DatePicker("busqHasta", {yyyymmdd:"", width: "200px"}),
					         
					         new sap.ui.core.Title({text:"Licitación"}),
					         new sap.ui.commons.Label({text:"Número"}),
					         new sap.ui.commons.TextField("busqNumLic", {value:"", width: "150px"}),
					         new sap.ui.commons.Label({text:"Estatus"}),
					         oComboBoxEstatus,
					         new sap.ui.commons.Label({text:"Comprador"}),
					         cBComprador,
					         
					         new sap.ui.core.Title({text:"Proyecto de Inversión"}),
					         new sap.ui.commons.Label({text:"Elemento PEP"}),
					         new sap.ui.commons.TextField("busqElemPEP", {value:"", width: "150px"})
					         
					         ]
				});
	    
	    
	    // create a simple matrix layout
	    var oLayout = new sap.ui.commons.layout.MatrixLayout({
	            id : "matrixLicitaciones",
	            layoutFixed : true
	            });
	
	    var oPanel = new sap.ui.commons.Panel({width: '95%'});
	    oPanel.setTitle(new sap.ui.core.Title({text: "Buscar proceso de Licitación por:", icon: "sap-icon://search"}));
	
		var oButton1 = new sap.ui.commons.Button("bBusLic",{
			text : "Buscar",
			press : function(event) {
				var data = {
					numeroLicitacion: sap.ui.getCore().byId("busqNumLic").getValue().trim(),	
					desde: sap.ui.getCore().byId("busqDesde").getYyyymmdd(),
					hasta: sap.ui.getCore().byId("busqHasta").getYyyymmdd(),
					elementoPEP: sap.ui.getCore().byId("busqElemPEP").getValue().trim(),
					estatus: sap.ui.getCore().byId("oComboBoxEstatus").getSelectedKey().trim(),
					comprador: sap.ui.getCore().byId("cBComprador").getSelectedKey().trim(),
				};
				oController.onBuscar(data);
			}
		});
		oButton1.setIcon("sap-icon://search");
		var oToolbar1 = new sap.ui.commons.Toolbar("toolBarBusqLic");
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
	    oToolbar1.addItem(oButton1);
	    
	    oPanel.addContent(oForm);
	    oPanel.addContent(oToolbar1);
	    
	    oLayout.createRow( oPanel );
	    oLayout.createRow( oTable );
	    
	    return oLayout;
	},
    
    createPanelLicitacion: function(oController) {
        var filtroPasaEval = new  sap.ui.model.Filter('total', "GE", 70);  
        var filtroLiberada = new  sap.ui.model.Filter('LIBERADA', "EQ", true);  

        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "100%"
        });
        
		var oToolbar1 = new sap.ui.commons.Toolbar();
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		var oButton1 = new sap.ui.commons.Button({
			text : "Regresar",
			press : function(event) {
				oController.veAListado();
			}
		});
		oButton1.setIcon("sap-icon://nav-back");
		var oButton2 = new sap.ui.commons.Button({
			text : "Editar",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				if(estatus === 0)
					sap.ui.getCore().byId("CreaLicitacion").getController().edita(numeroLicitacion.getValue());
				else
					sap.ui.commons.MessageBox.alert("Esta licitación ya no se puede editar", null, "Error");
			}
		});
		oButton2.setIcon("sap-icon://edit");
		var oButton3 = new sap.ui.commons.Button({
			text : "Enviar Invitaciones",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				var data = {
					numeroLicitacion: numeroLicitacion.getValue() 
				};
				if(estatus <= 1)
					sap.ui.getCore().byId("CreaLicitacion").getController().onEnviar(data);
				else
					sap.ui.commons.MessageBox.alert("No es posible enviar las invitaciones de esta licitación.", null, "Error");
			}
		});
		oButton3.setIcon("sap-icon://email");
		
		var oButton4 = new sap.ui.commons.Button({
			text : "Ampliar Plazo",
			visible: "{/beanUsuario/abastecimientos}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				var data = {
					numeroLicitacion: numeroLicitacion.getValue() 
				};
				if(estatus > 4)
					sap.ui.commons.MessageBox.alert("No es posible cambiar la fecha límite de esta licitación.", null, "Error");
				else
					oController.getView().createDialogAmpliarPlazo(oController, numeroLicitacion.getValue());
			}
		});
		oButton4.setIcon("sap-icon://calendar");

		var oButtonApruebaEval = new sap.ui.commons.Button({
			text : "Aprobar Evaluación Técnica",
			visible: "{/debeAprobarEvalTec}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				var data = {
					numeroLicitacion: numeroLicitacion.getValue(),
					aprueba: true
				};
				if(estatus !== 10)
					sap.ui.commons.MessageBox.alert("Estatus inconsistente", null, "Error");
				else
					sap.ui.commons.MessageBox.show("Confirme que ha revisado la tabla comparativa de evaluación técnica y aprueba pasar a la siguiente fase.",
							sap.ui.commons.MessageBox.Icon.WARNING,
							"Confirmar",
							[sap.ui.commons.MessageBox.Action.YES, sap.ui.commons.MessageBox.Action.NO],
							oController.apruebaEval(data),
							sap.ui.commons.MessageBox.Action.YES);
			}
		});
		oButtonApruebaEval.setIcon("sap-icon://accept");

		var oButtonRechazaEval = new sap.ui.commons.Button({
			text : "Rechazar Evaluación Técnica",
			visible: "{/debeAprobarEvalTec}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				var data = {
					numeroLicitacion: numeroLicitacion.getValue(),
					aprueba: false
				};
				if(estatus !== 10)
					sap.ui.commons.MessageBox.alert("Estatus inconsistente", null, "Error");
				else
					sap.ui.commons.MessageBox.show("Confirme que no aprueba la evaluación técnica.",
							sap.ui.commons.MessageBox.Icon.WARNING,
							"Rechazar",
							[sap.ui.commons.MessageBox.Action.YES, sap.ui.commons.MessageBox.Action.NO],
							oController.apruebaEval(data),
							sap.ui.commons.MessageBox.Action.YES);
			}
		});
		oButtonRechazaEval.setIcon("sap-icon://reset");

		var oButtonForo = new sap.ui.commons.Button("bAbreForoEnET",{
			text : "Foro de Preguntas y Respuestas",
			press : function(event) {
            	var oModel = oController.getView().getModel();
            	oController.getView().createDialogForo(oController, 0);
			}
		});
		oButtonForo.setIcon("sap-icon://sys-help");
		
		oToolbar1.addItem(oButton1);
		oToolbar1.addItem(oButtonApruebaEval);
		oToolbar1.addItem(oButtonRechazaEval);
		oToolbar1.addItem(oButton2);
		oToolbar1.addItem(oButton3);
		oToolbar1.addItem(oButton4);
		oToolbar1.addItem(oButtonForo);		
        oLayout.createRow(oToolbar1);

//		var devMode = jQuery.sap.getUriParameters().get("devMode");
//		if(devMode) {
		var oButton5 = new sap.ui.commons.Button({
			text : "Reasignar",
			visible: "{/beanUsuario/abastecimientos}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				if(estatus !== 7)
					sap.ui.commons.MessageBox.alert("No es posible reasignar esta licitación.", null, "Error");
				else
					oController.getView().createDialogReasignar(oController);
			}
		});
		oButton5.setIcon("sap-icon://repost");
		oToolbar1.addItem(oButton5);
//		}

		var oButton6 = new sap.ui.commons.Button({
			text : "Invitar Proveedores",
			visible: "{/beanUsuario/abastecimientos}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				if(estatus > 3)
					sap.ui.commons.MessageBox.alert("No es posible invitar mas proveedores.", null, "Error");
				else
					oController.getView().createDialogProveedoresAdic(oController, numeroLicitacion.getValue());
			}
		});
		oButton6.setIcon("sap-icon://add-contact");
		oToolbar1.addItem(oButton6);

		var oButtonDelProv = new sap.ui.commons.Button({
			text : "Borrar Proveedores",
			visible: "{/beanUsuario/abastecimientos}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				if(estatus > 3)
					sap.ui.commons.MessageBox.alert("No es posible eliminar mas proveedores.", null, "Error");
				else
					oController.getView().createDialogBorraProveedores(oController, numeroLicitacion.getValue());
			}
		});
		oButtonDelProv.setIcon("sap-icon://eraser");
		oToolbar1.addItem(oButtonDelProv);

		var oButtonCancelar = new sap.ui.commons.Button({
			text : "Cancelar",
			visible: "{/beanUsuario/abastecimientos}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				var data = {
					numeroLicitacion: numeroLicitacion.getValue() 
				};
				if(estatus > 4)
					sap.ui.commons.MessageBox.alert("No es posible Cancelar esta licitación.", null, "Error");
				else
					sap.ui.commons.MessageBox.confirm(
							"Confirme que desa Cancelar la licitación: " + numeroLicitacion.getValue(), 
							function(borrar) {
								if(borrar)
									oController.onCancelar(data);
							}, 
							"Confirmar");
			}
		});
		oButtonCancelar.setIcon("sap-icon://decline");
		oToolbar1.addItem(oButtonCancelar);
		
		var oButton7 = new sap.ui.commons.Button({
			text : "Borrar",
			visible: "{/beanUsuario/abastecimientos}",
			press : function(event) {
				var estatus = this.getModel().getProperty("/estatus");
				var data = {
					numeroLicitacion: numeroLicitacion.getValue() 
				};
				if(estatus > 4)
					sap.ui.commons.MessageBox.alert("No es posible borrar esta licitación.", null, "Error");
				else
					sap.ui.commons.MessageBox.confirm(
							"Confirme que desa borrar la licitación: " + numeroLicitacion.getValue(), 
							function(borrar) {
								if(borrar)
									oController.onBorrar(data);
							}, 
							"Confirmar");
			}
		});
		oButton7.setIcon("sap-icon://delete");
		oToolbar1.addItem(oButton7);

		////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaAprobaciones = new sap.ui.table.Table( {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None
        });
        tablaAprobaciones.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Responsable"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "responsable"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "responsable",
            filterProperty: "responsable"
        }));
        tablaAprobaciones.addColumn(new sap.ui.table.Column({
	        label: new sap.ui.commons.Label({text: "Estatus"}),
	        template: new sap.ui.commons.Label({text: {
	            path : "enviada",
	            formatter : function(oVal) {
	                return oVal? "Enviada":"No enviada";
	            }
	        }}),
	        sortProperty: "enviada",
	        filterProperty: "enviada"
	    }));
        tablaAprobaciones.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Aprueba", textAlign: "Center"}),
            template: new sap.ui.commons.CheckBox({enabled: false
            }).bindProperty("checked", "aprueba"),
            hAlign: "Center" 
        }));
        tablaAprobaciones.addColumn(new sap.ui.table.Column({
	        label: new sap.ui.commons.Label({text: "Fecha"}),
	        template: new sap.ui.commons.Label({text: {
	            path : "fecha",
	            formatter : function(oVal) {
	        		return oController.formateaFecha(oVal);
    	        }
	        }})
	    }));
        tablaAprobaciones.addColumn(new sap.ui.table.Column({
	        label: new sap.ui.commons.Label({text: "Mensaje"}),
	        width: '60%',
	        template: new sap.ui.commons.Label({text: {
	            path : "mensaje"
	        }})
	    }));
        tablaAprobaciones.bindRows("/lAprobaciones");

        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaLog = new sap.ui.table.Table( {
            visibleRowCount: 5,
            width: "750px",
            selectionMode: sap.ui.table.SelectionMode.None
        });
        tablaLog.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Responsable"}),
            width: "100px",
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "responsable"),
			flexible: true,
			resizable: true,
			autoResizable: true,
        }));
        tablaLog.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Fecha"}),
            width: "120px",
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "fecha"),
			flexible: true,
			resizable: true,
			autoResizable: true,
        }));
        tablaLog.addColumn(new sap.ui.table.Column({
	        label: new sap.ui.commons.Label({text: "Estatus"}),
	        template: new sap.ui.commons.Label({text: {
	            path : "estatus",
	            formatter : function(oVal) {
	                return sap.ui.getCore().byId("MainAppView").getController().descripcionEstatus(oVal);
	            }
	        }}),
	        width: "150px",
	    }));
        tablaLog.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Acción"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "accion"),
			flexible: true,
			resizable: true,
			autoResizable: true,
        }));
        tablaLog.bindRows("/lMovimientos");
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaPropuestas = new sap.ui.table.Table( {
            visibleRowCount: 5,
            width: "750px",
            selectionMode: sap.ui.table.SelectionMode.None
        });
        tablaPropuestas.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Núm. SAP"}),
            width: "100px",
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "numeroSAP",
            filterProperty: "numeroSAP"
        }));
        tablaPropuestas.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social", wrapping: true}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaPropuestas.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Envió Propuesta", wrapping: true}),
            width: "120px",
            template: new sap.ui.commons.Label({text: {
	            path : "IMPORTE",
	            formatter : function(oVal) {
	            	if(oVal > 0)
	            		return "Enviada";
	            	else
	            		return "No Enviada";
	            }
	        }}),
			flexible: true,
			resizable: true,
			autoResizable: true
        }));
        tablaPropuestas.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Liberada", textAlign: "Center"}),
//            template: new sap.ui.commons.CheckBox({enabled: false
//            }).bindProperty("checked", "LIBERADA"),
	        template: new sap.ui.commons.Label({text: {
	            path : "LIBERADA",
	            formatter : function(oVal) {
	                return oVal ? "SI": "NO";
	            }
	        }, textAlign: "Center"}),
            width: "100px",
			flexible: true,
			resizable: true,
			autoResizable: true,
            hAlign: "Center"
        }));
        tablaPropuestas.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Activo", textAlign: "Center"}),
	        template: new sap.ui.commons.Label({text: {
	            path : "ACTIVO",
	            formatter : function(oVal) {
	                return oVal ? "SI": "NO";
	            }
	        }, textAlign: "Center"}),
            width: "100px",
			flexible: true,
			resizable: true,
			autoResizable: true,
            hAlign: "Center"
        }));
        tablaPropuestas.bindRows("/listaProveedores");
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaProveedores = new sap.ui.table.TreeTable( {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None,
            expandFirstLevel: false
        });
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Núm. SAP"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
            width: "100px",
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "numeroSAP",
            filterProperty: "numeroSAP"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social", wrapping: true}),
            template: new sap.ui.commons.Label({wrapping: true}).bindProperty("text", "nombre"),
//            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Propuesta Técnica", textAlign: "Center", wrapping: true}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
                press: function () {
                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PT");
                	if(pdf)
	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
	                			pdf + 
	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PT"), 
	                			"indelproLicitacionesPDF", 
	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                	else
        				sap.ui.commons.MessageBox.show("No se ha cargado el documento",
        		                sap.ui.commons.MessageBox.Icon.WARNING,
        		                "Advertencia",
        		                [sap.ui.commons.MessageBox.Action.OK],
        		                '', sap.ui.commons.MessageBox.Action.OK);
                }
            }).bindProperty("visible", "LIBERADA")
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Fecha Envío", textAlign: "Center"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "FECHA_ENVIO"),
            hAlign: "Center" 
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ponderación Conceptos Generales", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase1",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"}).bindProperty("visible", "LINEBREAK"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "totalFase1",
            filterProperty: "totalFase1"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ponderación Conceptos Técnicos", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase2",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"}).bindProperty("visible", "LINEBREAK"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "totalFase2",
            filterProperty: "totalFase2"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Total Evaluación Técnica", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "total",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"}).bindProperty("visible", "LINEBREAK"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "total",
            filterProperty: "total"
        }));
        tablaProveedores.bindRows({path: "/listaProveedores"});
//        tablaProveedores.bindRows({path: "/listaProveedores",filters: [filtroLiberada]});
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaPropuestasEcon = new sap.ui.table.Table("consulta_tablaPropuestasEcon", {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None
        });
        tablaPropuestasEcon.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Núm. SAP"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
            width: "100px",
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "numeroSAP",
            filterProperty: "numeroSAP"
        }));
        tablaPropuestasEcon.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social", wrapping: true}),
            template: new sap.ui.commons.Label({wrapping: true}).bindProperty("text", "nombre"),
//            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaPropuestasEcon.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Propuesta Económica", textAlign: "Center", wrapping: true}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
                press: function () {
                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PE");
                	if(pdf)
	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
	                			pdf + 
	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PE"), 
	                			"indelproLicitacionesPDF", 
	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                	else
        				sap.ui.commons.MessageBox.show("No se puede mostrar el documento",
        		                sap.ui.commons.MessageBox.Icon.WARNING,
        		                "Advertencia",
        		                [sap.ui.commons.MessageBox.Action.OK],
        		                '', sap.ui.commons.MessageBox.Action.OK);
                }
            })
        }));
        tablaPropuestasEcon.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Monto", textAlign: "Center", editable: false}),
	        template: new sap.ui.commons.Label({text: {
	            path : "IMPORTE",
	            formatter : function(oVal) {
	        		var formatter = new Intl.NumberFormat('en-US', {  
	    		          style: "currency",  
	    		          currency: "USD"  
	    		        });
	                return formatter.format(oVal);
	            }
	        }, textAlign: "Center"})
        }));
        tablaPropuestasEcon.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ganador", textAlign: "Center"}),
            template: new sap.ui.commons.CheckBox({enabled: false
            }).bindProperty("checked", "ganador"),
            width: "100px",
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "ganador",
            filterProperty: "ganador",
            hAlign: "Center"
        }));
//        tablaPropuestasEcon.bindRows("/listaProveedores");
        tablaPropuestasEcon.bindRows({path: "/listaProveedores",filters: [filtroLiberada, filtroPasaEval]});

        ////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 1
        ////////////////////////////////////////////////////////////////////////////////////////////
        var lTotE1 = new sap.ui.commons.Label({text: {
            path : "/totalFase1",
            formatter : function(oVal) {
                return oVal + " %";
            }
        }});
        var oLayoutF1 = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Total"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE1]})
	                ]
            	})
            ]
        });
        var tablaFase1 = new sap.ui.table.Table({
            visibleRowCount: 5,
            width: "250px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF1
        });
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Conceptos Generales"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "concepto"),
            width: "160px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Porcentaje"}),
            template: new sap.ui.commons.TextField({
            	value: {
                    path: "porcentaje",
                    type: new sap.ui.model.type.Integer()
                }
            }),
            sortProperty: "porcentaje",
            filterProperty: "porcentaje"
        }));
        var f1 = new  sap.ui.model.Filter('fase', "EQ", 1);  
        tablaFase1.bindRows({path: "/lConceptosEvaluacion",filters: [f1]});
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 2
        ////////////////////////////////////////////////////////////////////////////////////////////
        var lTotE2 = new sap.ui.commons.Label({text: {
            path : "/totalFase2",
            formatter : function(oVal) {
                return oVal + " %";
            }
        }});
        var oLayoutF2 = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Total"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE2]})
	                ]
            	})
            ]
        });
        var tablaFase2 = new sap.ui.table.Table({
            visibleRowCount: 5,
            width: "250px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF2
        });
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Conceptos Técnicos"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "concepto"),
            width: "160px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Porcentaje"}),
            template: new sap.ui.commons.TextField({
            	value: {
                    path: "porcentaje",
                    type: new sap.ui.model.type.Integer()
                }
            }),
            sortProperty: "porcentaje",
            filterProperty: "porcentaje"
        }));
        var f2 = new  sap.ui.model.Filter('fase', "EQ", 2);  
        tablaFase2.bindRows({path: "/lConceptosEvaluacion",filters: [f2]});


        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////		
		var numeroLicitacion = new sap.ui.commons.TextField({value:"{/numeroLicitacion}", editable: false, width: "200px"});
		var descripcion = new sap.ui.commons.TextField({value:"{/descripcion}", editable: false});
		var fechaLimite = new sap.ui.commons.TextField({
        	value: {
    	        path:"/fechaLimite",
    	        formatter: function(oVal) {
	        		 return oController.formateaFecha(oVal);
    	        }
    	    }, editable: false, width: "200px"});
		var importeEstimado = new sap.ui.commons.TextField({
			value:"{/importeEstimado}", 
			editable: false,
			width: "150px"
		});
		var elementoPEP = new sap.ui.commons.TextField({value:"{/elementoPEP}", editable: false, width: "200px"});
		
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaArchivos = new sap.ui.table.Table("tablaArchivosConsulta", {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None,
            width: "350px"
        });
        tablaArchivos.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Nombre"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            width: "200px"
        }));
        tablaArchivos.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Descargar"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("download"),
                press: function () {
                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
                			this.getBindingContext().getProperty("id") + 
                			"&fileName=" + this.getBindingContext().getProperty("nombre"), 
                			"_archivo" + this.getBindingContext().getProperty("id"),
                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                }
            })
        }));
        tablaArchivos.bindRows("/listaArchivosAdicionales");

        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
		var oForm = new sap.ui.layout.form.SimpleForm(
				{
					layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveLayout,
					editable: false,
					width: "100%",
					maxContainerCols: 1,
					content:[
					         new sap.ui.core.Title({text:"Datos de la Licitación"}),
					         new sap.ui.commons.Label({text:"Número"}),
					         numeroLicitacion,
					         new sap.ui.commons.Label({text:"Elemento PEP"}),
					         elementoPEP,
					         new sap.ui.commons.Label({text:"Tipo"}),
//					         oComboBoxTipoLic,
					         new sap.ui.commons.Label({text:"Descripción"}),
					         descripcion,
					         new sap.ui.commons.Label({text:"Responsable"}),
					         new sap.ui.commons.TextField({value:"{/nombreResponsable}", editable: false}),
					         new sap.ui.commons.Label({text:"Fecha Límite"}),
					         fechaLimite,
					         new sap.ui.commons.Label({text:"Fecha de Visita de Obra"}),
					         new sap.ui.commons.TextField({
					        	value: {
				        	        path:"/fechaVisitaObra",
				        	        formatter: function(oVal) {
						        		 return oController.formateaFecha(oVal);
				        	        }
				        	    },
					        	editable: false}),
					         
					         new sap.ui.core.Title({text:"Archivos"}),
					         new sap.ui.commons.Label({text:"Bases"}),
					         new sap.m.Link({
			                        text: "{/nombreArchivoBases}",
			                        href: "#",
			                        press: function(oControlEvent) {
			                        	var model = sap.ui.getCore().byId("ConsultaLicitaciones").getModel();
			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
			                        			model.getProperty("/idArchivoBases") + 
			                        			"&fileName=" + model.getProperty("/nombreArchivoBases"), 
			                        			"indelproLicitacionesPDF", 
			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
			                        }
			                    }),
					         new sap.ui.commons.Label({text:"Alcance"}),
					         new sap.m.Link({
			                        text: "{/nombreArchivoEvaluacion}",
			                        href: "#",
			                        press: function(oControlEvent) {
			                        	var model = sap.ui.getCore().byId("ConsultaLicitaciones").getModel();
			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
			                        			model.getProperty("/idArchivoEvaluacion") + 
			                        			"&fileName=" + model.getProperty("/nombreArchivoEvaluacion"), 
			                        			"indelproLicitacionesPDF", 
			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
			                        }
		                    }),
		                     new sap.ui.commons.Label({text:"Detalle Presupuesto"}),
					         new sap.m.Link({
			                        text: "{/nombreArchivoPresupuesto}",
			                        href: "#",
			                        press: function(oControlEvent) {
			                        	var model = sap.ui.getCore().byId("ConsultaLicitaciones").getModel();
			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
			                        			model.getProperty("/idArchivoPresupuesto") + 
			                        			"&fileName=" + model.getProperty("/nombreArchivoPresupuesto"), 
			                        			"_archivoPresupuesto", 
			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
			                        }
			                    }),
		                     new sap.ui.commons.Label({text:"Resultados de Evaluación"}),
					         new sap.m.Link({
			                        text: "{/nombreArchivoResultados}",
			                        href: "{/urlArchivoResultados}",
			                        target: "_blank"
//			                        ,press: function(oControlEvent) {
//			                        	var model = sap.ui.getCore().byId("ConsultaLicitaciones").getModel();
//			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
//			                        			model.getProperty("/idArchivoResultados") + 
//			                        			"&fileName=" + model.getProperty("/nombreArchivoResultados"), 
//			                        			"indelproLicitacionesPDF", 
//			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
//			                        }
			                    }),
		                     new sap.ui.commons.Label({text:"Soporte Asignacion"}),
					         new sap.m.Link({
			                        text: "{/nombreArchivoSoporteAsignacion}",
			                        href: "#",
			                        press: function(oControlEvent) {
			                        	var model = sap.ui.getCore().byId("ConsultaLicitaciones").getModel();
			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
			                        			model.getProperty("/idArchivoSoporteAsignacion") + 
			                        			"&fileName=" + model.getProperty("/nombreArchivoSoporteAsignacion"), 
			                        			"_archivoSoporteAsignacion", 
			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
			                        }
			                    }),
					         new sap.ui.commons.Label({text:"Acta de Resultados"}),
					         new sap.m.Link({
			                        text: "{/idArchivoActaResultados}",
			                        href: "#",
			                        press: function(oControlEvent) {
			                        	var model = sap.ui.getCore().byId("ConsultaLicitaciones").getModel();
			                        	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
			                        			model.getProperty("/idArchivoActaResultados") + 
			                        			"&fileName=" + model.getProperty("/idArchivoActaResultados"), 
			                        			"indelproLicitacionesPDF", 
			                        			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
			                        }
		                    }),
					         new sap.ui.commons.Label({text:"Documentos Adicionales"}),
		                     tablaArchivos,

					         new sap.ui.core.Title({text:"Ponderación de Conceptos de Evaluación"}),
					         new sap.m.FlexBox({
					             alignItems: sap.m.FlexAlignItems.Stretch,
					             justifyContent: sap.m.FlexJustifyContent.SpaceAround,
					             items: [tablaFase1, tablaFase2],
					             direction: "Row"
					         }),
					         
					         new sap.ui.core.Title({text:"Determinación de Presupuesto"}),
					         new sap.ui.commons.Label({text:"Importe Estimado"}),
					         importeEstimado,
					         new sap.ui.commons.Label({text:"Moneda"}),
					         new sap.ui.commons.TextField({value:"{/moneda}", editable: false}),

					         new sap.ui.core.Title({text:"Revisión de Contraloría"}),
					         tablaPropuestas,

					         new sap.ui.core.Title({text:"Evaluación de Propuestas Técnicas"}),
					         tablaProveedores,

					         new sap.ui.core.Title({text:"Evaluación de Propuestas Económicas"}),
					         tablaPropuestasEcon,
					         new sap.ui.commons.Label({text:"Ganador"}),
					         new sap.ui.commons.TextView({
				        			text : "{/textoProveedorGanador}",
				        			semanticColor: sap.ui.commons.TextViewColor.Positive,
					         }),
					         new sap.ui.commons.Label({text:"Comentario de Aprobación"}),
					         new sap.ui.commons.TextView({
				        			text : "{/mensajeAdjudicacion}",
				        			semanticColor: sap.ui.commons.TextViewColor.Positive,
					         }),
					         new sap.ui.commons.Label({text:"Comentario de Reasignación"}),
					         new sap.ui.commons.TextView({
				        			text : "{/mensajeReasignacion}",
				        			semanticColor: sap.ui.commons.TextViewColor.Positive,
					         }),

					         new sap.ui.core.Title({text:"Aprobaciones"}),
					         tablaAprobaciones,

					         new sap.ui.core.Title({text:"Historial de Movimientos"}),
					         tablaLog
					         ]
				});
		
        oLayout.createRow(oForm);
		return oLayout;
    },
    
    
    createContent: function(oController) {
        var page = new sap.m.Page();
		oController.pagina = page;
		oController.panelLicitacion = this.createPanelLicitacion(oController);
		oController.panelLista = this.createListado(oController);
        page.setEnableScrolling(true);
		var oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Consulta de Licitaciones");
        page.setCustomHeader(oBar);
        page.addContent(oController.panelLista);

        return page;
    },
    
    onBeforeRendering: function(oController) {
//    	var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaLicitaciones.action");
//		sap.ui.getCore().byId("tableLicitaciones").setModel(oModel);
    }
    
});        
        