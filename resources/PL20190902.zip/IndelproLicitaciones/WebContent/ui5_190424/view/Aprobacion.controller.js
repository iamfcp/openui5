sap.ui.controller(sap.ui.getCore().AppContext.version+".view.Aprobacion", {
	pagina: null,
	panelLista: null,
	panelLicitacion: null,
	
    onInit: function() {
    	jQuery.sap.require("sap.ui.commons.MessageBox");
    },
    
    inicializa: function() {
    	this.veAListado();
    },
    
    veAListado: function() {
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLista);
        sap.ui.core.BusyIndicator.show(0);

		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaLicitaciones.action?estatus=6");
		var oTable = sap.ui.getCore().byId("tableListaLicAprobacion");
		oTable.setModel(oModel);
        var f1 = new  sap.ui.model.Filter('debeAprobar', "EQ", true);  
		oTable.bindRows({path: "/licitaciones",filters: [f1]});

		oModel.attachRequestCompleted(null, function() { 
            sap.ui.core.BusyIndicator.hide();
		});
    },
 
    veALicitacion: function(numeroLicitacion) {
        sap.ui.core.BusyIndicator.show(0);
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLicitacion);
		var data = {};
		data.numeroLicitacion = numeroLicitacion;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/obtenLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var c = sap.ui.getCore().byId("Aprobacion").getController();
            	var oModel = c.getView().getModel();
            	if(!oModel) {
            		oModel = new sap.ui.model.json.JSONModel();
            		c.getView().setModel(oModel);
            	}
//        		var listaProveedores =  c.calculaCalificaciones(dataRet.data.listaProveedores, dataRet.data.lResultadosEvaluacion);
//        		dataRet.data.listaProveedores = listaProveedores;
        		oModel.setData(dataRet.data);
        		var urlArchivoResultados =  
        			sap.ui.getCore().AppContext.path + "/descargaArchivo.action?contentDisposition=attachment&uuid=" + oModel.getProperty("/idArchivoResultados") + 
        			"&fileName=" + oModel.getProperty("/nombreArchivoResultados");
        		oModel.setProperty("/urlArchivoResultados", urlArchivoResultados);
//        		console.log(oModel.getData());
        		oModel.refresh();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },
    
    aprueba: function(numeroLicitacion, autoriza, mensaje) {
        sap.ui.core.BusyIndicator.show(0);
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLicitacion);
		var data = {};
		data.numeroLicitacion = numeroLicitacion;
		data.autoriza = autoriza;
		data.mensaje = mensaje;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/apruebaLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se ha guardado su autorización",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                function(){sap.ui.getCore().byId("MainAppView").getController().doNavBackLaunchpad();}, sap.ui.commons.MessageBox.Action.OK);
				veAListado();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },
 
//	getTotal: function(lResultadosEvaluacion, proveedor, fase) {
//		var total = 0;
//		for(var i = 0; i < lResultadosEvaluacion.length; i++) 
//			if(lResultadosEvaluacion[i].numeroSAP === proveedor) 
//				if(fase === 0 || fase === lResultadosEvaluacion[i].fase)
//					total += (lResultadosEvaluacion[i].porcentaje / 5) * lResultadosEvaluacion[i].calificacion;
//		return total;
//	},
//
//	calculaCalificaciones: function(listaProveedores, lResultadosEvaluacion) {
//		for(var j = 0; j < listaProveedores.length; j++) {
//			listaProveedores[j].totalFase1 = this.getTotal(lResultadosEvaluacion, listaProveedores[j].numeroSAP, 1);
//			listaProveedores[j].totalFase2 = this.getTotal(lResultadosEvaluacion, listaProveedores[j].numeroSAP, 2);
//			listaProveedores[j].total = listaProveedores[j].totalFase1 + listaProveedores[j].totalFase2;
//		}
//		return listaProveedores;
//	},
	
});