sap.ui.controller(sap.ui.getCore().AppContext.version+".view.Info", {

    onInit: function() {
        this.bus = sap.ui.getCore().getEventBus();
    },

    doNavBackLaunchpad: function(event) {
        this.bus.publish("nav", "backToPage", {id : "Launchpad"});
    },

    doNavBack: function(event) {
        this.bus.publish("nav", "back");
    } 
});