
sap.ui.controller(sap.ui.getCore().AppContext.version+".view.Usuarios", {

    onInit: function() {
    },
    
    inicializa: function() {
    	this.obtieneDatos();
    },
    
    obtieneDatos: function() {
		var oTable = sap.ui.getCore().getControl("tableUsuarios");
		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaUsuarios.action");
		oTable.setModel(oModel);
		oTable.bindRows("/usuarios");
	    oTable.sort(oTable.getColumns()[1]);
    },
    
    createUpdate: function(data, modo) {
        var view = this.getView();

		if(data.usuario === '') {
			sap.ui.commons.MessageBox.show("Ingrese el usuario",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}
		if(data.nombre === '') {
			sap.ui.commons.MessageBox.show("Ingrese el nombre",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}
		if(data.correo === '') {
			sap.ui.commons.MessageBox.show("Ingrese el correo",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}
		if(data.departamento === '') {
			sap.ui.commons.MessageBox.show("Ingrese el departamento",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return;
		}

        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: modo === 'new'? sap.ui.getCore().AppContext.path + "/creaUsuario.action": sap.ui.getCore().AppContext.path + "/actualizaUsuario.action",
            type: "POST",
            data: data,
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var oTable = sap.ui.getCore().getControl("tableUsuarios");
                var oModelTmp = oTable.getModel();
				var modelDataTmp = oModelTmp.getData(), len = modelDataTmp.usuarios.length;
				if(modo === 'new') {
					modelDataTmp.usuarios.push(dataRet);
				} else {
					for (i=0; i<len; ++i) {
						item = modelDataTmp.usuarios[i];
						if(item.usuario === dataRet.usuario) {
							item.jefe            = dataRet.jefe             ;
							item.activo          = dataRet.activo           ;
							item.nombre          = dataRet.nombre           ;
							item.correo          = dataRet.correo           ;
							item.departamento    = dataRet.departamento     ;
							item.liberaPE        = dataRet.liberaPE         ;
							item.liberaPT        = dataRet.liberaPT         ;
							item.abastecimientos = dataRet.abastecimientos  ;
							item.comite          = dataRet.comite           ;
							item.evalTecnico     = dataRet.evalTecnico      ;
							item.directorGeneral = dataRet.directorGeneral  ;
						}
					}
				}
				oModelTmp.setData(modelDataTmp);
				oModelTmp.refresh();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
            }
        });

    },
    
    

});