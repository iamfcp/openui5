sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.AprobacionEvaluacion", {

	getControllerName: function() {
		return sap.ui.getCore().AppContext.version+".view.AprobacionEvaluacion";
	},

    createDialog: function(oController, licitacion, si) {
        var oDialog = new sap.ui.commons.Dialog("dialogApruebaEvaluacionLic", {
            modal: true,
            width: "50%",
            height: "40%",
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogApruebaEvaluacionLic').destroy();
            }
        });
        oDialog.setTitle("Aprobación de Evaluación de Licitación");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "100%"
        });
        
        var label = new sap.m.Label({text: si? "Comentario de aprobación": "Comentario de rechazo"});
        oLayout.createRow(label);
        var tComentario = new sap.ui.commons.TextArea({value: "", width: "100%", rows: 5});
        oLayout.createRow(tComentario);
		var tfClaveLib = new sap.m.Input({
			// id: "lptClaveLib",
			type : sap.m.InputType.Password,
			placeholder : "Contraseña",
		});
		oLayout.createRow(tfClaveLib);
        
        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: "Enviar", press:function(){
        	oController.aprueba(licitacion, si, tComentario.getValue(), tfClaveLib.getValue());
            oDialog.close();
        }}));
        oDialog.open();
    },

    creaPanelLicitacion: function(oController) {
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaProveedores = new sap.ui.table.Table({
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None
        });
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social", wrapping: true}),
            template: new sap.ui.commons.TextField().bindProperty("value", "nombre"),
            width: "400px",
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Propuesta Técnica", textAlign: "Center", wrapping: true}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
                press: function () {
                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PT");
                	if(pdf)
	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
	                			pdf + 
	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PT"), 
	                			"indelproLicitacionesPDF", 
	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                	else
        				sap.ui.commons.MessageBox.show("No se ha cargado el documento",
        		                sap.ui.commons.MessageBox.Icon.WARNING,
        		                "Advertencia",
        		                [sap.ui.commons.MessageBox.Action.OK],
        		                '', sap.ui.commons.MessageBox.Action.OK);
                }
            })
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ponderación Conceptos Generales", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase1",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"}),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "totalFase1",
            filterProperty: "totalFase1"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Ponderación Conceptos Técnicos", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase2",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"}),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "totalFase2",
            filterProperty: "totalFase2"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Total Evaluación Técnica", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "total",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"}),
			flexible: true,
			resizable: true,
			autoResizable: true,
            sortProperty: "total",
            filterProperty: "total"
        }));
//        tablaProveedores.addColumn(new sap.ui.table.Column({
//            label: new sap.ui.commons.Label({text: "Propuesta Económica", textAlign: "Center", wrapping: true}),
//            hAlign: sap.ui.core.HorizontalAlign.Center,
//            template: new sap.ui.core.Icon({
//                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
//                press: function () {
//                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PE");
//                	if(pdf)
//	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
//	                			pdf + 
//	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PE"), 
//	                			"indelproLicitacionesPDF", 
//	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
//                	else
//        				sap.ui.commons.MessageBox.show("No se ha cargado el documento",
//        		                sap.ui.commons.MessageBox.Icon.WARNING,
//        		                "Advertencia",
//        		                [sap.ui.commons.MessageBox.Action.OK],
//        		                '', sap.ui.commons.MessageBox.Action.OK);
//                }
//            })
//        }));
//        tablaProveedores.addColumn(new sap.ui.table.Column({
//            label: new sap.ui.commons.Label({text: "Monto", textAlign: "Center", editable: false}),
//	        template: new sap.ui.commons.Label({text: {
//	            path : "IMPORTE",
//	            formatter : function(oVal) {
//	        		var formatter = new Intl.NumberFormat('en-US', {  
//	    		          style: "currency",  
//	    		          currency: "USD"  
//	    		        });
//	                return formatter.format(oVal);
//	            }
//	        }, textAlign: "Center"})
//        }));
//        tablaProveedores.addColumn(new sap.ui.table.Column({
//            label: new sap.ui.commons.Label({text: "Ganador", textAlign: "Center"}),
//            template: new sap.ui.commons.CheckBox({enabled: false
//            }).bindProperty("checked", "ganador"),
//            width: "100px",
//			flexible: true,
//			resizable: true,
//			autoResizable: true,
//            sortProperty: "ganador",
//            filterProperty: "ganador",
//            hAlign: "Center"
//        }));
        
        var f1 = new  sap.ui.model.Filter('total', "GE", 70);  
        tablaProveedores.bindRows({path: "/listaProveedores",filters: [f1]});
        
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 4,
            width: "90%"
        });
        
		var oToolbar1 = new sap.ui.commons.Toolbar();
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		var oButton1 = new sap.ui.commons.Button({
			text : "Regresar",
			press : function(event) {
				oController.veAListado();
			}
		});
		oButton1.setIcon("sap-icon://nav-back");
		oToolbar1.addItem(oButton1);		
		oButton1 = new sap.ui.commons.Button({
			text : "Aprobar Evaluación",
			press : function(event) {
				oController.getView().createDialog(oController, tfLicitacion.getValue(), true);
			}
		});
		oButton1.setIcon("sap-icon://accept");
		oToolbar1.addItem(oButton1);				
		oButton1 = new sap.ui.commons.Button({
			text : "Rechazar Evaluación",
			press : function(event) {
				oController.getView().createDialog(oController, tfLicitacion.getValue(), false);
			}
		});
		oButton1.setIcon("sap-icon://sys-cancel");
		oToolbar1.addItem(oButton1);		

		oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell({content: [oToolbar1], colSpan: 2 }));
        
        oLayout.createRow(new sap.ui.commons.Label({text:"Datos de la Licitación", design: "Bold"}));
        var tfLicitacion = new sap.ui.commons.TextField({value:"{/numeroLicitacion}", editable: false, width: "200px"}); 
        oLayout.createRow(new sap.ui.commons.Label({text:"Número"}), 
        		tfLicitacion);
        oLayout.createRow(
        		new sap.ui.commons.layout.MatrixLayoutCell(
                		{content: [new sap.ui.commons.Label({text:"Descripción"})] }),
	    		new sap.ui.commons.layout.MatrixLayoutCell(
	    	       		{content: [new sap.ui.commons.TextField({value:"{/descripcion}", editable: false, width: "400px"})],
	    	       		 colSpan: 2 }) );
        oLayout.createRow(
                new sap.ui.commons.Label({text:"Resultados de Evaluación"}),
		        new sap.m.Link({
                      text: "{/nombreArchivoResultados}",
                      href: "{/urlArchivoResultados}"
		        }) );

        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [tablaProveedores],
        		 colSpan: 4 }));
//        oLayout.createRow(
//        		new sap.ui.commons.layout.MatrixLayoutCell(
//                		{content: [new sap.ui.commons.Label({text:"Comentario de Aprobación"})] }),
//	    		new sap.ui.commons.layout.MatrixLayoutCell(
//	    	       		{content: [new sap.ui.commons.TextView({
//				        			text : "{/mensajeAdjudicacion}",
//				        			semanticColor: sap.ui.commons.TextViewColor.Positive,
//	        			 })],
//	    	       		 colSpan: 2 }) );
//        oLayout.createRow(
//        		new sap.ui.commons.layout.MatrixLayoutCell(
//                		{content: [new sap.ui.commons.Label({text:"Comentario de Reasignación"})] }),
//	    		new sap.ui.commons.layout.MatrixLayoutCell(
//	    	       		{content: [new sap.ui.commons.TextView({
//				        			text : "{/mensajeReasignacion}",
//				        			semanticColor: sap.ui.commons.TextViewColor.Positive,
//	        			 })],
//	    	       		 colSpan: 2 }) );


        return oLayout;
    },
    
    creaListadoSolicitudes: function(oController) {

        //Create an instance of the table control
        var oTable = new sap.ui.table.Table("tableListaLicAprobacionEvaluacion", {
                title: "Licitaciones por Aprobar",
                visibleRowCount: 10,
                firstVisibleRow: 1,
                selectionMode: sap.ui.table.SelectionMode.None
        });


        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Número"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "numeroLicitacion"),
            width: "100px",
            sortProperty: "numeroLicitacion",
            filterProperty: "numeroLicitacion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Descripción"}),
                template: new sap.ui.commons.TextField().bindProperty("value", "descripcion"),
                width: "150px",
                sortProperty: "descripcion",
                filterProperty: "descripcion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Estatus"}),
            template: new sap.ui.commons.Label({text: {
	            path : "estatus",
	            formatter : function(oVal) {
	                return sap.ui.getCore().byId("MainAppView").getController().descripcionEstatus(oVal);
	            }
	        }}),
            width: "100px",
            sortProperty: "estatus",
            filterProperty: "estatus"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Aprobar", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            width: "80px",
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("edit"),
                press: function () {
                	oController.veALicitacion(this.getBindingContext().getProperty("numeroLicitacion"));
                }
            })
        }));

        // create a simple matrix layout
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
                layoutFixed : true
                });
        
        oLayout.createRow( oTable );

        return oLayout;
    },
    
    createContent: function(oController) {
		var page = new sap.m.Page();
		oController.pagina = page;
		oController.panelLicitacion = this.creaPanelLicitacion(oController);
		oController.panelLista = this.creaListadoSolicitudes(oController);
		var oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Aprobación de Evaluación de Licitación");
		page.setCustomHeader(oBar);  
		page.setEnableScrolling(true);
		page.addContent(oController.panelLista);
//		page.addContent(oController.panelLista);
		return page;
	},

});