sap.ui.controller(sap.ui.getCore().AppContext.version+".view.CreaLicitacion", {
	listaProveedores: [],
	modelProveedores: null,
	lEvalFase1BASE: [
		{fase: 1, concepto: "Tiempo de entrega", valor: 0},
		{fase: 1, concepto: "Garantías", valor: 0},
		{fase: 1, concepto: "Contraloría", valor: 0},
		{fase: 1, concepto: "Recursos Humanos", valor: 0},
		{fase: 1, concepto: "Calidad", valor: 0},
//   	{fase: 1, concepto: "Infraestructura", valor: 0},
//		{fase: 1, concepto: "Experiencia", valor: 0},
//		{fase: 1, concepto: "Opinión Contraloría EEFF", valor: 0},
//		{fase: 1, concepto: "Recursos Humanos", valor: 0},
//		{fase: 1, concepto: "Seguridad", valor: 0},
	],
	lEvalFase1: [
 		{fase: 1, concepto: "Tiempo de entrega", valor: 0},
		{fase: 1, concepto: "Garantías", valor: 0},
		{fase: 1, concepto: "Contraloría", valor: 0},
		{fase: 1, concepto: "Recursos Humanos", valor: 0},
		{fase: 1, concepto: "Calidad", valor: 0},
	],
	lEvalFase2: [
 		{fase: 2, concepto: "Seguridad", valor: 0},
		{fase: 2, concepto: "Soporte técnico", valor: 0},
		{fase: 2, concepto: "Infraestructura y Tecnología", valor: 0},
		{fase: 2, concepto: "Experiencia del servicio", valor: 0},
		{fase: 2, concepto: "Experiencia específica", valor: 0},
    ],
	lEvalFase2BASE: [
		{fase: 2, concepto: "Seguridad", valor: 0},
		{fase: 2, concepto: "Soporte técnico", valor: 0},
		{fase: 2, concepto: "Infraestructura y Tecnología", valor: 0},
		{fase: 2, concepto: "Experiencia del servicio", valor: 0},
		{fase: 2, concepto: "Experiencia específica", valor: 0},
//		{fase: 2, concepto: "Calidad", valor: 0},
//		{fase: 2, concepto: "Tiempo de Entrega", valor: 0},
//		{fase: 2, concepto: "Marcas", valor: 0},
//		{fase: 2, concepto: "Experiencia con Indelpro", valor: 0},
//		{fase: 2, concepto: "Tecnología", valor: 0},
	],
	totalEvalF1: 0,
	totalEvalF2: 0,
	nombreArchivoBases: '',
	idArchivoBases: '',
	idArchivoEvaluacion: '',
	nombreArchivoEvaluacion: '',
	idArchivoPresupuesto: '',
	nombreArchivoPresupuesto: '',
	esNueva: false,
		
    onInit: function() {
    	jQuery.sap.require("sap.ui.commons.MessageBox");
    },

    inicializa: function() {
    	this.esNueva = true;
    	this.listaProveedores.length = 0;
    	sap.ui.getCore().byId("tablaProveedores").getModel().refresh();

    	this.lEvalFase1.length = 0;
    	this.lEvalFase2.length = 0;
    	this.lEvalFase1 = $.extend(true, [], this.lEvalFase1BASE);
    	this.lEvalFase2 = $.extend(true, [], this.lEvalFase2BASE);
    	var tablaFase1 = sap.ui.getCore().byId("crear_tablaFase1");
        var oModelF1 = new sap.ui.model.json.JSONModel();
        oModelF1.setData({modelData: this.lEvalFase1});
        tablaFase1.setModel(oModelF1);
        tablaFase1.bindRows("/modelData");
        var tablaFase2 = sap.ui.getCore().byId("crear_tablaFase2");
        var oModelF2 = new sap.ui.model.json.JSONModel();
        oModelF2.setData({modelData: this.lEvalFase2});
        tablaFase2.setModel(oModelF2);
        tablaFase2.bindRows("/modelData");
        this.totalEvalF1 = 0;
        this.totalEvalF2 = 0;
		sap.ui.getCore().byId("lTotE1").setText(this.totalEvalF1 + " %");
		sap.ui.getCore().byId("lTotE2").setText(this.totalEvalF2 + " %");
		sap.ui.getCore().byId("comboBoxResponsable").setSelectedKey("");
		sap.ui.getCore().byId("oComboBoxTipoLic").setSelectedKey("");
		sap.ui.getCore().byId("oInputConceptoAdic1").setValue("");
		sap.ui.getCore().byId("oInputConceptoAdic2").setValue("");
    	
    	sap.ui.getCore().byId("crear_tablaFase2").getModel().refresh();
    	var oModel = this.getView().getModel();
    	if(oModel) {
    		oModel.setData({});
    		oModel.refresh();
    	} else {
    		oModel = new sap.ui.model.json.JSONModel();
    		this.getView().setModel(oModel);
    	}
    },

    edita: function(numeroLicitacion) {
    	this.esNueva = false;
        sap.ui.core.BusyIndicator.show(0);
		var data = {};
		data.numeroLicitacion = numeroLicitacion;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/obtenLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var c = sap.ui.getCore().byId("CreaLicitacion").getController();
            	var oModel = c.getView().getModel();
            	if(!oModel) {
            		oModel = new sap.ui.model.json.JSONModel();
            		c.getView().setModel(oModel);
            	}
        		oModel.setData(dataRet.data);
        		c.idArchivoBases          = dataRet.data.idArchivoBases         ;
        		c.nombreArchivoBases      = dataRet.data.nombreArchivoBases     ;
        		c.nombreArchivoEvaluacion = dataRet.data.nombreArchivoEvaluacion;
        		c.idArchivoEvaluacion     = dataRet.data.idArchivoEvaluacion    ;
        		c.idArchivoPresupuesto      = dataRet.data.idArchivoPresupuesto         ;
        		c.nombreArchivoPresupuesto	= dataRet.data.nombreArchivoPresupuesto     ;
        		sap.ui.getCore().byId("comboBoxResponsable").setSelectedKey(dataRet.data.responsable);
        		sap.ui.getCore().byId("oComboBoxTipoLic").setSelectedKey(dataRet.data.tipo);
        		c.lEvalFase1.length = 0; c.lEvalFase2.length = 0;
        		c.totalEvalF1 = 0; c.totalEvalF2 = 0;
        		for(var i = 0; i < dataRet.data.lConceptosEvaluacion.length; i++) {
        			dataRet.data.lConceptosEvaluacion[i].valor = dataRet.data.lConceptosEvaluacion[i].porcentaje;
        			if(dataRet.data.lConceptosEvaluacion[i].fase === 1) {
    					c.lEvalFase1.push(dataRet.data.lConceptosEvaluacion[i]);
    					c.totalEvalF1 += dataRet.data.lConceptosEvaluacion[i].valor;
        			} else {
    					c.lEvalFase2.push(dataRet.data.lConceptosEvaluacion[i]);        				
    					c.totalEvalF2 += dataRet.data.lConceptosEvaluacion[i].valor;
        			}
        		}
        		sap.ui.getCore().byId("crear_tablaFase1").getModel().refresh();
        		sap.ui.getCore().byId("crear_tablaFase2").getModel().refresh();
        		sap.ui.getCore().byId("lTotE1").setText(c.totalEvalF1 + " %");
        		sap.ui.getCore().byId("lTotE2").setText(c.totalEvalF2 + " %");
        		c.listaProveedores.length = 0;
        		for(var i = 0; i < dataRet.data.listaProveedores.length; i++) {
        			c.listaProveedores.push(dataRet.data.listaProveedores[i]);
        		}
        		sap.ui.getCore().byId("tablaProveedores").getModel().refresh();
        		oModel.refresh();
        		sap.ui.getCore().byId("MainAppView").getController().navTo("CreaLicitacion", null, true);
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },
    
    getYYYYMMDD: function(date, off) {
    	date.setDate(date.getDate() + off);
    	var year = date.getFullYear();
    	var month = (1 + date.getMonth()).toString();
    	month = month.length > 1 ? month : '0' + month;
    	var day = date.getDate().toString();
    	day = day.length > 1 ? day : '0' + day;
    	return year + month + day;
    },
    
    getFormattedDate: function(date) {
    	if(!(date instanceof Date)) {
            var oDateFormat = sap.ui.core.format.DateFormat.getInstance({pattern: "yyyyMMdd"});
            date = oDateFormat.parse(date);
    	}
        var oDateFormat = sap.ui.core.format.DateFormat.getInstance({pattern: "dd / MM / yyyy"});
        return oDateFormat.format(date);
    },
    
    onEnviar: function(data) {
        sap.ui.core.BusyIndicator.show(0);
        var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/enviaInvitaciones.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                console.log(dataRet);
                if(dataRet.codigo && dataRet.codigo == 200) {
    				sap.ui.commons.MessageBox.show("Las invitaciones se han enviado",
    		                sap.ui.commons.MessageBox.Icon.SUCCESS,
    		                "Éxito",
    		                [sap.ui.commons.MessageBox.Action.OK],
    		                '', sap.ui.commons.MessageBox.Action.OK);
    				sap.ui.getCore().byId("MainAppView").getController().doNavBackLaunchpad();
                } else {
					sap.ui.commons.MessageBox.show(dataRet.mensaje,
			                sap.ui.commons.MessageBox.Icon.ERROR,
			                "Error",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);      
                }
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },
    
    actualizaProveedor: function(dataEnv) {
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/actualizaProveedor.action",
            type: "POST",
            data: dataEnv,
            success: function(data) {
                sap.ui.core.BusyIndicator.hide();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
            }
        });
   	},

   	onGuardar: function(data) {
    	data.esNueva = this.esNueva;
    	data.listaProveedores = this.listaProveedores;
    	data.listaArchivosAdicionales = this.getView().getModel().getProperty("/listaArchivosAdicionales");
		data.lConceptosEvaluacion = this.lEvalFase1.concat(this.lEvalFase2);
    	data.nombreArchivoBases = this.nombreArchivoBases;
    	data.nombreArchivoEvaluacion = this.nombreArchivoEvaluacion;
    	data.idArchivoBases = this.idArchivoBases;
    	data.idArchivoEvaluacion = this.idArchivoEvaluacion;
    	data.idArchivoPresupuesto     = this.idArchivoPresupuesto         ;
    	data.nombreArchivoPresupuesto = this.nombreArchivoPresupuesto     ;
    	console.log(data);
		if(data.numeroLicitacion === '') {
			sap.ui.commons.MessageBox.show("Ingrese el número de licitación",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
//		if(data.elementoPEP === '') {
//			sap.ui.commons.MessageBox.show("Ingrese el Elemento PEP",
//                    sap.ui.commons.MessageBox.Icon.ERROR,
//                    "Datos Incompletos",
//                    [sap.ui.commons.MessageBox.Action.OK],
//                    '', sap.ui.commons.MessageBox.Action.OK);      
//			return false;
//		}
		if(data.descripcion === '') {
			sap.ui.commons.MessageBox.show("Ingrese la descripcion de la licitación",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
		if(data.fechaLimite < this.getYYYYMMDD(new Date(), 1)) { // TODO 7
			sap.ui.commons.MessageBox.show("Fecha debe ser mayor a " + this.getFormattedDate(this.getYYYYMMDD(new Date(), 1)),
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incorrectos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
		var re = /\$|,/g;
		var floatValue = parseFloat(data.importeEstimado.replace(re,''));
		data.importeEstimado = floatValue;
		if(data.importeEstimado === '' || isNaN(data.importeEstimado)) {
			sap.ui.commons.MessageBox.show("Ingrese un importe estimado correcto en USD",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incorrectos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
		if((this.totalEvalF1 + this.totalEvalF2) !== 100) {
			sap.ui.commons.MessageBox.show("El porcentaje total en las fases de evaluación no es 100: " + (this.totalEvalF1 + this.totalEvalF2),
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incorrectos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
    	if(this.listaProveedores.length < 1) {
			sap.ui.commons.MessageBox.show("Seleccione proveedores para la licitación",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
		if(data.idArchivoBases === '') {
			sap.ui.commons.MessageBox.show("No ha cargado el archivo de bases",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
		if(data.idArchivoEvaluacion === '') {
			sap.ui.commons.MessageBox.show("No ha cargado el archivo de bases de evaluación",
                    sap.ui.commons.MessageBox.Icon.ERROR,
                    "Datos Incompletos",
                    [sap.ui.commons.MessageBox.Action.OK],
                    '', sap.ui.commons.MessageBox.Action.OK);      
			return false;
		}
    	
        sap.ui.core.BusyIndicator.show(0);
        var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/guardaLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                console.log(dataRet);
                if(dataRet.codigo && dataRet.codigo == 200) {
					sap.ui.commons.MessageBox.show("Se ha guardado la licitación " + data.numeroLicitacion,
			                sap.ui.commons.MessageBox.Icon.SUCCESS,
			                "Éxito",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);
                } else {
					sap.ui.commons.MessageBox.show(dataRet.mensaje,
			                sap.ui.commons.MessageBox.Icon.ERROR,
			                "Error",
			                [sap.ui.commons.MessageBox.Action.OK],
			                '', sap.ui.commons.MessageBox.Action.OK);
					return false
                }
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);
				return false
            }
        });
        return true;

    },
    
});