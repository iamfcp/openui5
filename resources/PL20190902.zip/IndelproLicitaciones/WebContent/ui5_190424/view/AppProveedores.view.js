sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.AppProveedores", {

    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.AppProveedores";
    },
    
    createContent: function(oController) {

        // set device model
        var oDeviceModel = new sap.ui.model.json.JSONModel({
            isTouch: sap.ui.Device.support.touch,
            isNoTouch: !sap.ui.Device.support.touch,
            isPhone: sap.ui.Device.system.phone,
            isNoPhone: !sap.ui.Device.system.phone,
            listMode: (sap.ui.Device.system.phone) ? "None" : "SingleSelectMaster",
            listItemType: (sap.ui.Device.system.phone) ? "Active" : "Inactive",
            launchpadMode: true
        });
        oDeviceModel.setDefaultBindingMode("OneWay");
        sap.ui.getCore().setModel(oDeviceModel, "device");
        this.setModel(oDeviceModel, "device");

        // to avoid scrollbars on desktop the root view must be set to block display
        this.setDisplayBlock(true);

        this.app = new sap.m.SplitApp({
            afterDetailNavigate: function() {
                this.hideMaster();
            },
            homeIcon: {
                'phone': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'phone@2': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'tablet': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'tablet@2': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'favicon': sap.ui.core.IconPool.getIconURI("sap-icon://nav-back"),
                'precomposed': false
            }
        });
        this.app.setMode(sap.m.SplitAppMode.HideMode);


        this.app.addMasterPage(sap.ui.jsview("Menu", sap.ui.getCore().AppContext.version+".view.Menu"));

        this.app.addDetailPage(sap.ui.jsview("Launchpad", sap.ui.getCore().AppContext.version+".view.Launchpad"));

        this.app.addDetailPage(sap.ui.xmlview("Info", sap.ui.getCore().AppContext.version+".view.Info"));
        this.app.addDetailPage(sap.ui.jsview("EnvioPropuesta", sap.ui.getCore().AppContext.version+".view.EnvioPropuesta"));
        

//        this.app.toDetail("Launchpad");
        this.app.toDetail("EnvioPropuesta");

        return this.app;
    }
    
});        
        