sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.EvaluaPropuestasTecnicas", {

	getControllerName: function() {
		return sap.ui.getCore().AppContext.version+".view.EvaluaPropuestasTecnicas";
	},

	createDialog: function(proveedor, oController, model) {
        var oDialog = new sap.ui.commons.Dialog("dialogEvaluaPT", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogEvaluaPT').destroy();
            }
        });
        oDialog.setTitle("Evaluar Propuestas Técnicas");
        oDialog.setModel(model);
        function actualizaTotales() {
        	var t1 = oController.getSubTotal(proveedor, 1), t2 = oController.getSubTotal(proveedor, 2);
        	lTotE1.setText(t1 + " %");
        	lTotE2.setText(t2 + " %, ");
            lTotal.setText(t1 + t2 + " %");        	
        }
        ////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 1
        ////////////////////////////////////////////////////////////////////////////////////////////
        var lTotE1 = new sap.ui.commons.Label({text: oController.getTotal(proveedor, 1) + " %"});
        var oLayoutF1 = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Sub Total Fase 1:"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE1]})
	                ]
            	})
            ]
        });
        var tablaFase1 = new sap.ui.table.Table({
            visibleRowCount: 5,
            width: "600px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF1
        });
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Concepto"}),
            template: new sap.ui.commons.Label().bindProperty("text", "concepto"),
            width: "180px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Porcentaje"}),
            width: "90px",
            template: new sap.ui.commons.Label().bindProperty("text", "porcentaje"),
            sortProperty: "porcentaje",
            filterProperty: "porcentaje"
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "0"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal0}',
            	select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "1"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal1}',
            	select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "2"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal2}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "3"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal3}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "4"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal4}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "5"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal5}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "Total", wrapping: true}),
        	template: new sap.ui.commons.TextField().bindProperty("value", "subtotal")
        }));
//        tablaFase1.addColumn(new sap.ui.table.Column({
//            label: new sap.ui.commons.Label({text: "Calificación"}),
//            template: new sap.ui.commons.Slider({
//        		width: '190px',
//        		min: 0,
//        		max: 10,
//        		value: "{calificacion}",
//        		totalUnits: 10,
//        		smallStepWidth: .5,
//        		stepLabels : true,
//        		change: function(oEvent){ lTotE1.setText(oController.getTotal(proveedor, 1) + " %"); } 
//        		})
//        }));
        var f1 = new  sap.ui.model.Filter('fase', "EQ", 1);  
        var fp = new  sap.ui.model.Filter('numeroSAP', "EQ", proveedor);  
        tablaFase1.bindRows({path: "/lResultadosEvaluacion",filters: [f1, fp]});
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 2
        ////////////////////////////////////////////////////////////////////////////////////////////
        var lTotE2 = new sap.ui.commons.Label({text: oController.getTotal(proveedor, 2) + " %"});
        var lTotal = new sap.ui.commons.Label({text: oController.getTotal(proveedor, 1) + oController.getTotal(proveedor, 2) + " %"});
        var oLayoutF2 = new sap.ui.commons.layout.MatrixLayout({
            columns: 5,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Sub Total Fase 2:"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE2]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "                 "})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Total:"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotal]})
	                ]
            	})
            ]
        });
        var tablaFase2 = new sap.ui.table.Table({
            visibleRowCount: 5,
            width: "600px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF2
        });
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Concepto"}),
            template: new sap.ui.commons.Label().bindProperty("text", "concepto"),
            width: "180px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Porcentaje"}),
            width: "90px",
            template: new sap.ui.commons.Label().bindProperty("text", "porcentaje"),
            sortProperty: "porcentaje",
            filterProperty: "porcentaje"
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "0"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal0}',
       			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "1"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal1}',
       			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "2"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal2}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "3"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal3}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "4"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal4}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "5"}),
            template: new sap.ui.commons.RadioButton({groupName : '{grupo}', selected : '{cal5}',
    			select : function(oControlEvent) {actualizaTotales();}})
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({label: new sap.ui.commons.Label({text: "Total", wrapping: true}),
        	template: new sap.ui.commons.TextField().bindProperty("value", "subtotal")
        }));
//        tablaFase2.addColumn(new sap.ui.table.Column({
//            label: new sap.ui.commons.Label({text: "Calificación"}),
//            template: new sap.ui.commons.Slider({
//        		width: '190px',
//        		min: 0,
//        		max: 10,
//        		value: "{calificacion}",
//        		totalUnits: 10,
//        		smallStepWidth: .5,
//        		stepLabels : true,
//        		change: function(oEvent){ lTotE2.setText(oController.getTotal(proveedor, 2) + " %"); } 
//        		})
//        }));
        var f2 = new  sap.ui.model.Filter('fase', "EQ", 2);  
        tablaFase2.bindRows({path: "/lResultadosEvaluacion",filters: [f2, fp]});
        
        var box = new sap.m.FlexBox({
            alignItems: sap.m.FlexAlignItems.Stretch,
            justifyContent: sap.m.FlexJustifyContent.SpaceAround,
            items: [ new sap.ui.commons.Label({text: "Fase 1: Ponderación de Conceptos Generales"}),
			         tablaFase1, 
			         new sap.ui.commons.Label({text: "Fase 2: Ponderación de Conceptos Técnicos"}),
			         tablaFase2],
            direction: "Column"
        });

        oDialog.addContent(box);
        oDialog.addButton(new sap.ui.commons.Button({text: "Aceptar", press:function(){
        	oController.calculaCalificaciones();
        	oController.getView().getModel().refresh();
            oDialog.close();
        }}));
        oDialog.open();
    },

    creaPanelLicitacion: function(oController) {
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaProveedores = new sap.ui.table.Table("tablaProveedoresEvaluaPT", {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None
        });
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "nombre"),
            width: "400px",
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Propuesta Técnica", textAlign: "Center", wrapping: true}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("pdf-attachment"),
                press: function () {
                	var pdf = this.getBindingContext().getProperty("ID_ARCHIVO_PT");
                	if(pdf)
	                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
	                			pdf + 
	                			"&fileName=" + this.getBindingContext().getProperty("ARCHIVO_PT"), 
	                			"indelproLicitacionesPDF", 
	                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                	else
        				sap.ui.commons.MessageBox.show("No se ha cargado el documento",
        		                sap.ui.commons.MessageBox.Icon.WARNING,
        		                "Advertencia",
        		                [sap.ui.commons.MessageBox.Action.OK],
        		                '', sap.ui.commons.MessageBox.Action.OK);
                }
            })
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Conceptos Generales", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase1",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"})
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Conceptos Técnicos", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "totalFase2",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"})
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Total Evaluación Técnica", textAlign: "Center", wrapping: true}),
	        template: new sap.ui.commons.Label({text: {
	            path : "total",
	            formatter : function(oVal) {
	                return oVal + " %";
	            }
	        }, textAlign: "Center"})
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Evaluar", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("edit"),
                press: function () {
                	if(this.getBindingContext().getProperty("IMPORTE") <= 0) {
            			sap.ui.commons.MessageBox.show("No se ha recibido la propuesta",
                                sap.ui.commons.MessageBox.Icon.ERROR,
                                "Error",
                                [sap.ui.commons.MessageBox.Action.OK],
                                '', sap.ui.commons.MessageBox.Action.OK);      
            			return;
                	}
    				oController.getView().createDialog(this.getBindingContext().getProperty("numeroSAP"), oController, this.getBindingContext().getModel());
                }
            })
        }));
        var f1 = new  sap.ui.model.Filter('IMPORTE', "GT", 0);  
        var f2 = new  sap.ui.model.Filter('ID_ARCHIVO_PT', "NE", '');  
        var f3 = new  sap.ui.model.Filter('LIBERADA', "EQ", true);  
        tablaProveedores.bindRows({path: "/listaProveedores",filters: [f1,f2,f3]});

        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 4,
            width: "90%"
        });
        
		var oToolbar1 = new sap.ui.commons.Toolbar();
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		var oButton1 = new sap.ui.commons.Button({
			text : "Regresar",
			press : function(event) {
				oController.veAListado();
			}
		});
		oButton1.setIcon("sap-icon://nav-back");
		oToolbar1.addItem(oButton1);

        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell({content: [oToolbar1], colSpan: 4 }));
        
        oLayout.createRow(new sap.ui.commons.Label({text:"Datos de la Licitación", design: "Bold"}));
        oLayout.createRow(new sap.ui.commons.Label({text:"Número"}), 
        		new sap.ui.commons.TextField("numeroLicitacionEvaluaPT", {value:"{/numeroLicitacion}", editable: false, width: "200px"}));
        oLayout.createRow(
        		new sap.ui.commons.layout.MatrixLayoutCell(
                		{content: [new sap.ui.commons.Label({text:"Descripción"})] }),
	    		new sap.ui.commons.layout.MatrixLayoutCell(
	    	       		{content: [new sap.ui.commons.TextField("descripcionLicitacionEvaluaPT", {value:"{/descripcion}", editable: false, width: "400px"})],
	    	       		 colSpan: 2 })
		        );
        oLayout.createRow(
        		new sap.ui.commons.layout.MatrixLayoutCell(
                		{content: [new sap.ui.commons.Label({text:"Responsable"})] }),
	    		new sap.ui.commons.layout.MatrixLayoutCell(
	    	       		{content: [new sap.ui.commons.TextField("evaluadorLicitacionEvaluaPT", {value:"{/nombreResponsable}", editable: false, width: "400px"})],
	    	       		 colSpan: 2 })
		        );
        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [tablaProveedores],
        		 colSpan: 4 }));
        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [new sap.ui.commons.TextView({
	        			text: 'Nota: En caso de que alguna propuesta no cumpla favor de especificar los motivos en el archivo de resultados. El mínimo para aprobar es 70%',
	        			design: sap.ui.commons.TextViewDesign.Bold,
	        			semanticColor: sap.ui.commons.TextViewColor.Default,
	        		}),],
        		 colSpan: 4 }));
        var archivoEval = 
		     new sap.ui.unified.FileUploader({
	        	 name: "archivoUno",
	        	 uploadOnChange: true,
	        	 value: "{/nombreArchivoResultados}",
	        	 fileType: ["pdf", "xls", "xlsx"],
	        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
	        	 uploadComplete: function(oControlEvent) {
	        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
	        		 console.log(oControlEvent.getSource().getValue());
	        		 console.log(oControlEvent.getParameters().response.trim());
	        		 var res = oControlEvent.getParameters().response.trim().split('|');
	        		 oController.idArchivoResultados = res[1];
	        		 oController.nombreArchivoResultados = res[2].replace(/[^a-zA-Z.0-9]+/g,'');;
	        	 }

	         }).attachTypeMissmatch(null,
	        		 function() {
        	 		sap.ui.commons.MessageBox.alert("Solo se permiten archivos de tipo PDF", null, "Error"); 
        		 }, null);
        archivoEval.setIcon("");
        oLayout.createRow(
        		new sap.ui.commons.layout.MatrixLayoutCell(
                		{content: [new sap.ui.commons.Label({text:"Archivo de Resultados"})] }),
	    		new sap.ui.commons.layout.MatrixLayoutCell(
	    	       		{content: [archivoEval],
	    	       		 colSpan: 2 })
		        );


		var oToolbar1 = new sap.ui.commons.Toolbar("toolBarEvaluaPTLic");
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		
		var oButton1 = new sap.ui.commons.Button("bEvaluaPT",{
			text : "Guardar Resultados",
			tooltip : "Guardar Resultados",
			press : function(event) {
				oController.guardaResultadosEvaluacion();
				oButtonTerminar.setEnabled(true);
			}
		});
		oButton1.setIcon("sap-icon://save");
		oToolbar1.addItem(oButton1);		
		
		var oButtonTerminar = new sap.ui.commons.Button("bTerminaEvaluacionPT",{
			text : "Terminar Evaluación",
			enabled: false,
			tooltip : "Terminar Evaluación",
			press : function(event) {
				sap.ui.commons.MessageBox.confirm(
						"Confirme que desa terminar la evaluación ", 
						function(terminar) {
							if(terminar)
								oController.terminaEvaluacion();
						}, 
						"Confirmar");
			}
		});
		oButtonTerminar.setIcon("sap-icon://accept");
		oToolbar1.addItem(oButtonTerminar);		
        oLayout.createRow(new sap.ui.commons.layout.MatrixLayoutCell(
        		{content: [oToolbar1],
        		 colSpan: 4 }));    	
        
        return oLayout;
    },
    
    creaListadoSolicitudes: function(oController) {

        //Create an instance of the table control
        var oTable = new sap.ui.table.Table("tableListaLicEvalTec", {
                title: "Licitaciones Disponibles para Evaluación",
                visibleRowCount: 10,
                firstVisibleRow: 1,
                selectionMode: sap.ui.table.SelectionMode.None
        });


        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Número"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "numeroLicitacion"),
            width: "100px",
            sortProperty: "numeroLicitacion",
            filterProperty: "numeroLicitacion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
                label: new sap.ui.commons.Label({text: "Descripción"}),
                template: new sap.ui.commons.TextField().bindProperty("value", "descripcion"),
                width: "150px",
                sortProperty: "descripcion",
                filterProperty: "descripcion"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Estatus"}),
            template: new sap.ui.commons.Label({text: {
	            path : "estatus",
	            formatter : function(oVal) {
	                return sap.ui.getCore().byId("MainAppView").getController().descripcionEstatus(oVal);
	            }
	        }}),
            width: "100px",
            sortProperty: "estatus",
            filterProperty: "estatus"
        }));
        oTable.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Evaluar", textAlign: "Center"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            width: "80px",
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("edit"),
                press: function () {
                	console.log(this.getBindingContext().getProperty("numeroLicitacion"));
                	oController.veALicitacion(this.getBindingContext().getProperty("numeroLicitacion"));
                }
            })
        }));
        
        // create a simple matrix layout
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
                layoutFixed : true
                });
        
        oLayout.createRow( oTable );

        return oLayout;
    },
    
    createContent: function(oController) {
		var page = new sap.m.Page();
		oController.pagina = page;
		oController.panelLicitacion = this.creaPanelLicitacion(oController);
		oController.panelLista = this.creaListadoSolicitudes(oController);
		var oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Evaluar Propuestas Técnicas");
		page.setCustomHeader(oBar);  
		page.setEnableScrolling(true);
		page.addContent(oController.panelLista);
//		page.addContent(oController.panelLista);
		return page;
	},

});