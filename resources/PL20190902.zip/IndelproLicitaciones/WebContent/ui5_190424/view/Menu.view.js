sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.Menu", {

    getControllerName: function() {
        return sap.ui.getCore().AppContext.version+".view.Menu";
    },

    createContent: function(oController) {

        var oListTemplate = new sap.m.StandardListItem({
            title: "{title}",
            icon: "{icon}",
            description: "{description}",
            type: sap.m.ListType.Navigation,
            customData: new sap.ui.core.CustomData({
                key: "targetPage",
                value: "{targetPage}"
            })
        });

        var oList = new sap.m.List({
            selectionChange: [oController.doNavOnSelect, oController],
            mode: sap.m.ListMode.SingleSelectMaster
        });
        oList.bindAggregation("items", "/menu", oListTemplate);


        return new sap.m.Page({
            content: [oList]
        });
    }

});