sap.ui.controller(sap.ui.getCore().AppContext.version+".view.ConsultaLicitaciones", {
	pagina: null,
	panelLista: null,
	panelLicitacion: null,
	datosLicitacion: null,
	listaProveedoresAdicionales: [],

    onInit: function() {
    },
    
    inicializa: function() {
    	this.veAListado();
    },
    
    veAListado: function() {
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLista);
    },
 
    onBuscar: function(data) {
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/buscaLicitaciones.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
            	oModel = sap.ui.getCore().byId("tableLicitaciones").getModel();
        		oModel.setData(dataRet);
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },	
    
    onBorrar: function(data) {
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/borraLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                sap.ui.getCore().byId("ConsultaLicitaciones").getController().veAListado();
            	oModel = sap.ui.getCore().byId("tableLicitaciones").getModel();
        		oModel.setData({});
        		sap.ui.commons.MessageBox.alert("Se ha borrado la licitación.");
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },	
    
    onBorraProveedores: function(data) {
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/eliminaProveedores.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
        		sap.ui.commons.MessageBox.alert("Se han eliminado los proveedores de la licitación.");
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },	
    
    onInvitarAdicionales: function(data) {
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/agregaProveedores.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
        		sap.ui.commons.MessageBox.alert("Se han enviado las invitaciones.");
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },	
    
    onAmpliarPlazo: function(data) {
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/ampliaPlazoLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var oModel = sap.ui.getCore().byId("ConsultaLicitaciones").getModel();
                oModel.setProperty("/fechaLimite", data.fechaLimite);
                oModel.refresh();
				sap.ui.commons.MessageBox.show("Se ha guardado el cambio",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },
    
    onCancelar: function(data) {
        sap.ui.core.BusyIndicator.show(0);
		data.estatus = 8;
		var dataJ = {data: data};
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/cambiaEstatus.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se ha cancelado la licitación",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                function(){sap.ui.getCore().byId("MainAppView").getController().doNavBackLaunchpad();},
		                sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },
    
    apruebaEval: function(data) {
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/apruebaEvalTec.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se ha guardado el cambio",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },	

    onReasignar: function(data) {
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/reasignaLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Se ha guardado el cambio",
		                sap.ui.commons.MessageBox.Icon.SUCCESS,
		                "Éxito",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });
    },	

    veALicitacion: function(numeroLicitacion) {
    	this.listaProveedoresAdicionales.length = 0;
		this.pagina.removeAllContent();
		this.pagina.addContent(this.panelLicitacion);
		var data = {};
		data.numeroLicitacion = numeroLicitacion;
		var dataJ = {data: data};
        sap.ui.core.BusyIndicator.show(0);
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/obtenLicitacion.action",
            type: "POST",
            data: JSON.stringify(dataJ),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8',
            success: function(dataRet) {
                sap.ui.core.BusyIndicator.hide();
                var c = sap.ui.getCore().byId("ConsultaLicitaciones").getController();
                c.datosLicitacion = dataRet.data;
                dataRet.data.totalFase1 = 0;
                dataRet.data.totalFase2 = 0;
        		for(i=0; i<dataRet.data.lConceptosEvaluacion.length; i++)
        			if(dataRet.data.lConceptosEvaluacion[i].fase === 1)
        				dataRet.data.totalFase1 += dataRet.data.lConceptosEvaluacion[i].porcentaje;
        			else
        				dataRet.data.totalFase2 += dataRet.data.lConceptosEvaluacion[i].porcentaje;
        		var oModel = new sap.ui.model.json.JSONModel();
        		sap.ui.getCore().byId("consulta_tablaPropuestasEcon").
        			setProperty("visible", 
        					dataRet.data.estatus == 6 ||
        					dataRet.data.estatus == 7 ||
        					dataRet.data.estatus == 9);
        		oModel.setData(dataRet.data);
        		for(var j = 0; j < dataRet.data.listaProveedores.length; j++) 
        			if(dataRet.data.listaProveedores[j].ganador) {
        				oModel.setProperty("/textoProveedorGanador", dataRet.data.listaProveedores[j].numeroSAP + " " + dataRet.data.listaProveedores[j].nombre);
        				break;
        			}        		
        		sap.ui.getCore().byId("ConsultaLicitaciones").setModel(oModel);
//                console.log(oModel);
        		var formatter = new Intl.NumberFormat('en-US', {  
    		          style: "currency",  
    		          currency: "USD"  
    		        });
        		var tmp = formatter.format(parseFloat(oModel.getProperty("/importeEstimado")));
        		oModel.setProperty("/importeEstimado", tmp);
        		var urlArchivoResultados =  sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
        			oModel.getProperty("/idArchivoResultados") + 
	    			"&fileName=" + oModel.getProperty("/nombreArchivoResultados");
        		oModel.setProperty("/urlArchivoResultados", urlArchivoResultados);
        		oModel.setProperty("/beanUsuario", dataRet.beanUsuario);
        		oModel.setProperty("/debeAprobarEvalTec", dataRet.beanUsuario.usuario === dataRet.data.responsable);
        		oModel.refresh();
            },
            error: function(data) {
                sap.ui.core.BusyIndicator.hide();
				sap.ui.commons.MessageBox.show("Ocurrió un error de comunicación",
		                sap.ui.commons.MessageBox.Icon.ERROR,
		                "Error",
		                [sap.ui.commons.MessageBox.Action.OK],
		                '', sap.ui.commons.MessageBox.Action.OK);      
            }
        });

    },
    
    formateaFecha: function(fecha) {
        var oDateFormat = sap.ui.core.format.DateFormat.getInstance({pattern: "yyyyMMdd"});
        var oDateFormatOut = sap.ui.core.format.DateFormat.getInstance({pattern: "dd / MM / yyyy"});
        var fLim = oDateFormat.parse(fecha);
        return oDateFormatOut.format(fLim);
    }
	
});