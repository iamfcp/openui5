jQuery.sap.require("sap.ui.model.json.JSONModel");

sap.ui.controller(sap.ui.getCore().AppContext.version+".view.Menu", {

    onInit: function() {
    	var model = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/Menu.action");
        model.attachRequestCompleted(null, function() {
            data = model.getData();
            if (data && data.menu) {
            	data.menu.push({icon: "sap-icon://log", title: "Salir", targetPage: "Salir"});
            }
            model.refresh();
        });
        this.getView().setModel(model);
        this.bus = sap.ui.getCore().getEventBus();
    },

    logout: function() {
        var data = {
            "modo": "logout"
        };
        $.ajax({
            url: sap.ui.getCore().AppContext.path + "/logout.action",
            type: "POST",
            data: data,
            beforeSend: function(xhr) {
            },
            success: function() {
                var newLocation = location.protocol + "//" + location.hostname + 
                        (location.port && ":" + location.port) + sap.ui.getCore().AppContext.path;
                location.replace(newLocation);
            }
        });
    },
    
    doNavOnSelect: function(event) {
        if (sap.ui.Device.system.phone) {
            event.getParameter("listItem").setSelected(false);
        }
        if(event.getParameter('listItem').getCustomData()[0].getValue() === 'Salir') {
        	this.logout();
        	return;
        }
		if(!sap.ui.getCore().byId("MainAppView").getController().revisaSesion())
			return;
		if(sap.ui.getCore().byId(event.getParameter('listItem').getCustomData()[0].getValue()).getController().inicializa)
        	sap.ui.getCore().byId(event.getParameter('listItem').getCustomData()[0].getValue()).getController().inicializa();
        this.bus.publish("nav", "to", {
            id: event.getParameter('listItem').getCustomData()[0].getValue()
        });
    }
});