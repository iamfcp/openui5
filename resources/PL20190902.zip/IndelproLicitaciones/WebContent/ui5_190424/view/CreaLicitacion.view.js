sap.ui.jsview(sap.ui.getCore().AppContext.version+".view.CreaLicitacion", {

	getControllerName: function() {
		return sap.ui.getCore().AppContext.version+".view.CreaLicitacion";
	},

    createDialog: function(oController) {
        var oDialog = new sap.ui.commons.Dialog("dialogSeleccionaProveedor", {
            modal: true,
            closed: function(oControlEvent) {
                sap.ui.getCore().getElementById('dialogSeleccionaProveedor').destroy();
            }
        });
        oDialog.setTitle("Seleccione Proveedores");
        var oLayout = new sap.ui.commons.layout.MatrixLayout({
            columns: 1,
            width: "700px"
        });
        var oTableP = new sap.ui.table.Table({
            visibleRowCount: 5,
            firstVisibleRow: 1,
            selectionMode: sap.ui.table.SelectionMode.Multiple
        });
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Núm. SAP"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
            width: "100px",
            sortProperty: "numeroSAP",
            filterProperty: "numeroSAP"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Correo"}),
//            template: new sap.ui.commons.TextField().bindProperty("value", "correo"),
            template: new sap.ui.commons.TextField({
            	change: function(oControlEvent){
//            		console.log(oControlEvent.getParameters().newValue);
//            		console.log(this.getBindingContext());
//            		console.log(this.getBindingContext().getProperty("numeroSAP"));
    				var data = {
						"numeroSAP": this.getBindingContext().getProperty("numeroSAP"), 
						"rfc": this.getBindingContext().getProperty("rfc"), 
						"correo": oControlEvent.getParameters().newValue, 
						"nombre": this.getBindingContext().getProperty("nombre"), 
						"notas": this.getBindingContext().getProperty("notas")
					};
					oController.actualizaProveedor(data);
            	},
            	value: {
                    path: "correo",
                    type: new sap.ui.model.type.String()
                }
            }),
            sortProperty: "correo",
            filterProperty: "correo"
        }));
        oTableP.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Notas"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "notas"),
            sortProperty: "notas",
            filterProperty: "notas"
        }));
		var oModel = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaProveedores.action");
		oTableP.setModel(oModel);
		oTableP.bindRows("/proveedores");
        oLayout.createRow(oTableP);
        
        oDialog.addContent(oLayout);
        oDialog.addButton(new sap.ui.commons.Button({text: "Usar Seleccionados", press:function(){
        	var selInd = oTableP.getSelectedIndices();
        	var ok = true;
			for (i=0; i<selInd.length; ++i) {
				oController.listaProveedores.push(oTableP.getContextByIndex(selInd[i]).getObject());
				console.log(oTableP.getContextByIndex(selInd[i]).getObject());
				if(!oTableP.getContextByIndex(selInd[i]).getObject().correo) 
					ok = false;
			}
			if(!ok)
				sap.ui.commons.MessageBox.alert("Algunos de los proveedores seleccionados no tienen correo registrado", null, "Advertencia"); 
	        oController.modelProveedores.setData({modelData: oController.listaProveedores});
            oDialog.close();
        }}));
        oDialog.open();
    },

    createContent: function(oController) {
        var formatter = new Intl.NumberFormat('en-US', {  
	          style: "currency",  
	          currency: "USD"  
	        });

        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
		var oComboBoxTipoLic = new sap.ui.commons.ComboBox("oComboBoxTipoLic",{
			tooltip: "Tipo",
			width: "200px",
			items: [new sap.ui.core.ListItem({text: "Proyecto", key: "1"}),
			        new sap.ui.core.ListItem({text: "Equipos", key: "2"}),
			        new sap.ui.core.ListItem({text: "Servicios de Mantenimiento", key: "3"}),
			        new sap.ui.core.ListItem({text: "Ingeniería", key: "4"}),
			        new sap.ui.core.ListItem({text: "Materiales", key: "5"}),
			        new sap.ui.core.ListItem({text: "Contrato Anual", key: "6"})],
			change: function(oEvent){
//				sap.ui.getCore().byId("TextFieldKey").setValue(oEvent.oSource.getSelectedKey());
//				sap.ui.getCore().byId("TextFieldId").setValue(oEvent.oSource.getSelectedItemId());
			}
		});
		
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaArchivos = new sap.ui.table.Table("tablaArchivos", {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.None,
            width: "450px"
        });
        tablaArchivos.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Nombre"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            width: "250px"
        }));
        tablaArchivos.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Borrar"}),
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("delete"),
                press: function () {
	        		var laa = this.getModel().getProperty("/listaArchivosAdicionales");
	        		if(laa)
	        			for(var i=0; i < laa.length; i++)
	        				if(laa[i].id === this.getBindingContext().getProperty("id"))
	        					laa.splice(i, 1);
	        		this.getModel().refresh();
                }
            }),
            width: "70px"
        }));
        tablaArchivos.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Descargar"}),
            hAlign: sap.ui.core.HorizontalAlign.Center,
            template: new sap.ui.core.Icon({
                src: sap.ui.core.IconPool.getIconURI("download"),
                press: function () {
                	window.open(sap.ui.getCore().AppContext.path + "/descargaArchivo.action?uuid=" + 
                			this.getBindingContext().getProperty("id") + 
                			"&fileName=" + this.getBindingContext().getProperty("nombre"), 
                			"_archivo" + this.getBindingContext().getProperty("id"),
                			"menubar=0,location=1,status=0,scrollbars=1,width=700,height=500");
                }
            }),
            width: "120px"
        }));
        tablaArchivos.bindRows("/listaArchivosAdicionales");

        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        var tablaProveedores = new sap.ui.table.Table("tablaProveedores", {
            visibleRowCount: 5,
            selectionMode: sap.ui.table.SelectionMode.Single,
            toolbar: new sap.ui.commons.Toolbar({items: [
                    new sap.ui.commons.Button({text: "Agregar Proveedor", press: function() { oController.getView().createDialog(oController); }}),
                    new sap.ui.commons.Button({text: "Quitar", press: function(evt) {
                    	oController.listaProveedores.splice(tablaProveedores.getSelectedIndex(), 1);
            	        oController.modelProveedores.setData({modelData: oController.listaProveedores});
                    }})
            ]})
        });
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Núm. SAP"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "numeroSAP"),
            width: "120px",
            sortProperty: "numeroSAP",
            filterProperty: "numeroSAP"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Razón Social"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "nombre"),
            sortProperty: "nombre",
            filterProperty: "nombre"
        }));
        tablaProveedores.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Correo"}),
            template: new sap.ui.commons.TextField({editable: false}).bindProperty("value", "correo"),
            sortProperty: "correo",
            filterProperty: "correo"
        }));
        var oModelDP = new sap.ui.model.json.JSONModel();
        oModelDP.setData({modelData: oController.listaProveedores});
        oController.modelProveedores = oModelDP;
        tablaProveedores.setModel(oModelDP);
        tablaProveedores.bindRows("/modelData");
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 1
        ////////////////////////////////////////////////////////////////////////////////////////////
        var oInputConceptoAdic1 = new sap.ui.commons.TextField("oInputConceptoAdic1", {
            placeholder: "Nuevo Concepto"
        });
        var oButtonConceptoAdic1  = new sap.ui.commons.Button({
            text: "Agregar",
            press: function () {
            	nc1 = {fase: 1, concepto: oInputConceptoAdic1.getValue(), valor: 0};
            	oController.lEvalFase1.push(nc1);
            	oModelF1 = tablaFase1.getModel();
            	oModelF1.setData({modelData: oController.lEvalFase1});
            }
        });
        var lTotE1 = new sap.ui.commons.Label("lTotE1", {text: "0 %"});
        var oLayoutF1 = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
   	                cells: [
   	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [oInputConceptoAdic1]}),
   	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [oButtonConceptoAdic1]})
   	                ]
               	}),
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Total"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE1]})
	                ]
            	}),
            ]
        });
        var tablaFase1 = new sap.ui.table.Table("crear_tablaFase1", {
            visibleRowCount: 5,
            width: "250px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF1
        });
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Concepto"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "concepto"),
            width: "190px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase1.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Valor"}),
            template: new sap.ui.commons.TextField({
            	change: function(oControlEvent){
					if(isNaN(oControlEvent.getParameters().newValue))
						sap.ui.commons.MessageBox.alert("Utilice solo números", null, "Error"); 
            		var t = 0;
					for (i=0; i<oController.lEvalFase1.length; ++i) {
						t += oController.lEvalFase1[i].valor;						
					}
					lTotE1.setText(t + ' %');
					oController.totalEvalF1 = t;
            	},
            	value: {
                    path: "valor",
                    type: new sap.ui.model.type.Integer()
                }
            }),
            sortProperty: "valor",
            filterProperty: "valor"
        }));
        var oModelF1 = new sap.ui.model.json.JSONModel();
        oModelF1.setData({modelData: oController.lEvalFase1});
        tablaFase1.setModel(oModelF1);
        tablaFase1.bindRows("/modelData");
        
        ////////////////////////////////////////////////////////////////////////////////////////////
        // Fase 2
        ////////////////////////////////////////////////////////////////////////////////////////////
        var oInputConceptoAdic2 = new sap.ui.commons.TextField("oInputConceptoAdic2", {
            placeholder: "Nuevo Concepto"
        });
        var oButtonConceptoAdic2  = new sap.ui.commons.Button({
            text: "Agregar",
            press: function () {
            	nc2 = {fase: 2, concepto: oInputConceptoAdic2.getValue(), valor: 0};
            	oController.lEvalFase2.push(nc2);
            	oModelF2 = tablaFase2.getModel();
            	oModelF2.setData({modelData: oController.lEvalFase2});
            }
        });
        var lTotE2 = new sap.ui.commons.Label("lTotE2", {text: "0 %"});
        var oLayoutF2 = new sap.ui.commons.layout.MatrixLayout({
            columns: 2,
            layoutFixed: false,
            rows: [
                new sap.ui.commons.layout.MatrixLayoutRow({
   	                cells: [
   	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [oInputConceptoAdic2]}),
   	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [oButtonConceptoAdic2]})
   	                ]
               	}),
                new sap.ui.commons.layout.MatrixLayoutRow({
	                cells: [
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [new sap.ui.commons.Label({text: "Total"})]}),
	                    new sap.ui.commons.layout.MatrixLayoutCell({content: [lTotE2]})
	                ]
            	}),
            ]
        });
        var tablaFase2 = new sap.ui.table.Table("crear_tablaFase2", {
            visibleRowCount: 5,
            width: "250px",
            selectionMode: sap.ui.table.SelectionMode.None,
            footer: oLayoutF2
        });
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Concepto"}),
            template: new sap.ui.commons.TextField().bindProperty("value", "concepto"),
            width: "190px",
            sortProperty: "concepto",
            filterProperty: "concepto"
        }));
        tablaFase2.addColumn(new sap.ui.table.Column({
            label: new sap.ui.commons.Label({text: "Valor"}),
//            template: new sap.ui.commons.InPlaceEdit({
//                content: new sap.ui.commons.TextField({
//                    value: {
//                        path: "valor",
//                        type: new sap.ui.model.type.Integer()
//                    }
//                }),
//                undoEnabled: false,
//                change: function (oControlEvent) {
//					if(isNaN(oControlEvent.getParameters().newValue))
//						sap.ui.commons.MessageBox.alert("Utilice solo números", null, "Error"); 
//            		var t = 0;
//					for (i=0; i<oController.lEvalFase2.length; ++i) {
//						t += oController.lEvalFase2[i].valor;						
//					}
//					lTotE2.setText(t + ' %');
//					oController.totalEvalF2 = t;
//            	}
//            }),
            template: new sap.ui.commons.TextField({
            	change: function(oControlEvent){
					if(isNaN(oControlEvent.getParameters().newValue))
						sap.ui.commons.MessageBox.alert("Utilice solo números", null, "Error"); 
            		var t = 0;
					for (i=0; i<oController.lEvalFase2.length; ++i) {
						t += oController.lEvalFase2[i].valor;						
					}
					lTotE2.setText(t + ' %');
					oController.totalEvalF2 = t;
            	},
            	value: {
                    path: "valor",
                    type: new sap.ui.model.type.Integer()
                }
            }),
            sortProperty: "valor",
            filterProperty: "valor"
        }));
        var oModelF2 = new sap.ui.model.json.JSONModel();
        oModelF2.setData({modelData: oController.lEvalFase2});
        tablaFase2.setModel(oModelF2);
        tablaFase2.bindRows("/modelData");


        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
		var oComboBoxResponsable = new sap.ui.commons.ComboBox("comboBoxResponsable",{
			tooltip: "Responsable",
			width: "200px"
		});
		var oModelResp = new sap.ui.model.json.JSONModel(sap.ui.getCore().AppContext.path + "/listaEvalTec.action");
		oComboBoxResponsable.setModel(oModelResp);
		var oItemTemplateResp = new sap.ui.core.ListItem();
		oItemTemplateResp.bindProperty("key", "usuario");
		oItemTemplateResp.bindProperty("text", "nombre");
		oItemTemplateResp.bindProperty("enabled", "enabled");
		oComboBoxResponsable.bindItems("/usuarios", oItemTemplateResp);

		var oComboBoxMoneda = new sap.ui.commons.ComboBox("comboBoxMoneda",{
			tooltip: "Moneda",
			width: "200px",
			selectedKey: "{/moneda}",
			displaySecondaryValues: true,
			items : [
				new sap.ui.core.ListItem({key:"USD", text:"USD", additionalText:"Dólar Americano"}),
				new sap.ui.core.ListItem({key:"MXN", text:"MXN", additionalText:"Peso Mexicano"}),
				new sap.ui.core.ListItem({key:"EUR", text:"EUR", additionalText:"Euro"})]
		});
		
		var numeroLicitacion = new sap.ui.commons.TextField("numeroLicitacion", {value:"{/numeroLicitacion}", width: "200px"});
		var descripcion = new sap.ui.commons.TextField("descripcion", {value:"{/descripcion}"});
		var fechaLimite = new sap.ui.commons.DatePicker("fechaLimite", {yyyymmdd:"{/fechaLimite}", width: "200px"});
		var fechaVisitaObra = new sap.ui.commons.DatePicker("fechaVisitaObra", {yyyymmdd:"{/fechaVisitaObra}", width: "200px"});
		var importeEstimado = new sap.ui.commons.TextField("ponderacion3_1", {
			value:"{/importeEstimado}", 
			width: "150px"
			,change : function(oEvent) {  
		        var value = oEvent.getSource().getValue();  
		        var floatValue = parseFloat(value);
		        this.setValue(formatter.format(floatValue));  
			}
		});
		importeEstimado.attachBrowserEvent("focus", function() {
			if(this.getValue().trim()) {
				var re = /\$|,/g;
				var floatValue = parseFloat(this.getValue().replace(re,''));
				this.setValue(floatValue);
			}
		});
		var elementoPEP = new sap.ui.commons.TextField("elementoPEP", {value:"{/elementoPEP}", width: "150px"});
		
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////
		var oForm = new sap.ui.layout.form.SimpleForm(
				"sf1",
				{
					layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
					editable: false,
					content:[
					         new sap.ui.core.Title({text:"Datos de la Licitación"}),
					         new sap.ui.commons.Label({text:"Número"}),
					         numeroLicitacion,
					         new sap.ui.commons.Label({text:"Elemento PEP"}),
					         elementoPEP,
					         new sap.ui.commons.Label({text:"Tipo"}),
					         oComboBoxTipoLic,
					         new sap.ui.commons.Label({text:"Descripción"}),
					         descripcion,
					         new sap.ui.commons.Label({text:"Responsable"}),
					         oComboBoxResponsable,
					         new sap.ui.commons.Label({text:"Fecha Límite"}),
					         fechaLimite,
					         new sap.ui.commons.Label({text:"Fecha de Visita de Obra"}),
					         fechaVisitaObra,
					         new sap.ui.commons.Label({text:"Bases"}),
					         new sap.ui.unified.FileUploader({
					        	 name: "archivoUno",
					        	 uploadOnChange: true,
					        	 value: "{/nombreArchivoBases}",
					        	 fileType: ["pdf"],
					        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
					        	 uploadComplete: function(oControlEvent) {
					        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
					        		 var res = oControlEvent.getParameters().response.trim().split('|');
					        		 oController.idArchivoBases = res[1];
					        		 oController.nombreArchivoBases = res[2].replace(/[^a-zA-Z.0-9]+/g,'');
					        	 }
					         }).attachTypeMissmatch(null,
					        		 function() {
				        	 		sap.ui.commons.MessageBox.alert("Solo se permiten archivos de tipo PDF", null, "Error"); 
				        		 }, null),

					         new sap.ui.commons.Label({text:"Alcance"}),
					         new sap.ui.unified.FileUploader({
					        	 name: "archivoDos",
					        	 uploadOnChange: true,
					        	 value: "{/nombreArchivoEvaluacion}",
					        	 fileType: ["pdf"],
					        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
					        	 uploadComplete: function(oControlEvent) {
					        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
					        		 var res = oControlEvent.getParameters().response.trim().split('|');
					        		 oController.idArchivoEvaluacion = res[1];
					        		 oController.nombreArchivoEvaluacion = res[2].replace(/[^a-zA-Z.0-9]+/g,'');
					        	 }
					         }).attachTypeMissmatch(null,
					        		 function() {
					        	 		sap.ui.commons.MessageBox.alert("Solo se permiten archivos de tipo PDF", null, "Error"); 
					        		 }, null),
					        		 
					         new sap.ui.commons.Label({text:""}),
				        	 new sap.ui.commons.TextView({
				        			text : 'Solo se permiten archivos de tipo PDF.\nSe recomienda que el tamaño no exceda los 5MB ya que los archivos serán enviados por correo al proveedor.',
				        			semanticColor: sap.ui.commons.TextViewColor.Positive,
		        			 }),

					         new sap.ui.core.Title({text:"Documentos Adicionales para la Invitación"}),
					         new sap.m.FlexBox({
					             alignItems: sap.m.FlexAlignItems.Stretch,
					             justifyContent: sap.m.FlexJustifyContent.SpaceAround,
					             items: [ 	tablaArchivos,
									        new sap.ui.unified.FileUploader({
									        	 name: "archivoN",
									        	 uploadOnChange: true,
									        	 value: "",
									        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
									        	 uploadComplete: function(oControlEvent) {
								        		    oControlEvent.getSource().setValue("");
									        		var res = oControlEvent.getParameters().response.trim().split('|');
									        		var idaa = res[1];
									        		var nombreaa = res[2].replace(/[^a-zA-Z.0-9]+/g,'');
									        		var laa = this.getModel().getProperty("/listaArchivosAdicionales");
									        		if(!laa) {
									        			this.getModel().setProperty("/listaArchivosAdicionales", []);
									        			laa  = this.getModel().getProperty("/listaArchivosAdicionales");
									        		}
									        		laa.push({id:idaa, nombre:nombreaa});
									        		this.getModel().refresh();
									        	 } })
					                      ],
					             direction: "Column"
					         }),

					         new sap.ui.core.Title({text:"Fase 1: Ponderación de Conceptos Generales"}),
					         tablaFase1,

					         new sap.ui.core.Title({text:"Fase 2: Ponderación de Conceptos Técnicos"}),
					         tablaFase2,

			        		 new sap.ui.core.Title({text:"Proveedores"}),
					         tablaProveedores,

					         new sap.ui.core.Title({text:"Determinación de Presupuesto"}),
					         new sap.ui.commons.Label({text:"Importe Estimado"}),
					         importeEstimado,
					         new sap.ui.commons.Label({text:"Moneda"}),
					         oComboBoxMoneda,
					         new sap.ui.commons.Label({text:"Detalle"}),
					         new sap.ui.unified.FileUploader({
					        	 name: "archivoTres",
					        	 uploadOnChange: true,
					        	 value: "{/nombreArchivoPresupuesto}",
					        	 uploadUrl: sap.ui.getCore().AppContext.path + '/cargaArchivo.action',
					        	 uploadComplete: function(oControlEvent) {
					        		 oControlEvent.getSource().setIcon("sap-icon://message-success");
					        		 console.log(oControlEvent.getSource().getValue());
					        		 console.log(oControlEvent.getParameters().response.trim());
					        		 var res = oControlEvent.getParameters().response.trim().split('|');
					        		 oController.idArchivoPresupuesto = res[1];
					        		 oController.nombreArchivoPresupuesto = res[2].replace(/[^a-zA-Z.0-9]+/g,'');
					        	 }
					         })

				         ]
				});

		var oToolbar1 = new sap.ui.commons.Toolbar("toolBarCreaLic");
		oToolbar1.setDesign(sap.ui.commons.ToolbarDesign.Standard);
		
		var oButton1 = new sap.ui.commons.Button("bCrearLic",{
			text : "Guardar",
			tooltip : "Guardar",
			press : function(event) {
				var data = {
					numeroLicitacion: numeroLicitacion.getValue().trim(), 
					importeEstimado: importeEstimado.getValue(),
					descripcion: descripcion.getValue(),
					fechaLimite: fechaLimite.getYyyymmdd(),
					fechaVisitaObra: fechaVisitaObra.getYyyymmdd(),
					moneda: oComboBoxMoneda.getSelectedKey(),
					responsable: oComboBoxResponsable.getSelectedKey(),
					tipo: oComboBoxTipoLic.getSelectedKey(),
					elementoPEP: elementoPEP.getValue()
				};
				if(oController.onGuardar(data))
					oButtonMail.setEnabled(true);
			}
		});
		oButton1.setIcon("sap-icon://save");
		oToolbar1.addItem(oButton1);		
		
		var oButtonMail = new sap.ui.commons.Button("bEnviarLic",{
			text : "Enviar Invitaciones",
			tooltip : "Enviar Invitaciones",
			enabled: false,
			press : function(event) {
				var data = {
					numeroLicitacion: numeroLicitacion.getValue() 
				};
				oController.onEnviar(data);
			}
		});
		oButtonMail.setIcon("sap-icon://email");
		oToolbar1.addItem(oButtonMail);		
		
		var page = new sap.m.Page();

		oBar = sap.ui.getCore().byId("MainAppView").getController().getPageHeader("Crear Licitación");
		page.setCustomHeader(oBar);  
		page.setEnableScrolling(true);
		page.addContent(oForm);
		page.addContent(oToolbar1);
		return page;
	}

});