package com.indelpro.util;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.commons.collections.BeanMap;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.indelpro.model.BeanLicitacion;
import com.indelpro.model.BeanUsuario;
import com.indelpro.model.dao.DAOUsuario;
import com.indelpro.sched.MailerJob;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class Email {
	private static final SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
	private static final SimpleDateFormat dfTradicional = new SimpleDateFormat("dd / MM / yyyy");
	private static String leyendaNavegador = "<br>Para una mejor experiencia utilice el navegador Chrome, Firefox o Internet Explorer 11 o superior.";
	
//	private static SchedulerFactory factory;
//	private static Scheduler scheduler;
//	static {
//		try {
//			factory = new StdSchedulerFactory();
//			scheduler = factory.getScheduler();
//			scheduler.start();
//		} catch (SchedulerException e) {
//			e.printStackTrace();
//		}
//	}
	
	public static void mensajeAlComite(String contextPath, String subject, String mensaje, BeanLicitacion l) {
		DAOUsuario daou = new DAOUsuario();
		ArrayList<BeanUsuario> usuarios = daou.obtenUsuarios();
		
		for (BeanUsuario beanUsuario : usuarios)
			if(beanUsuario.comite) 
				enviarCorreo(contextPath, beanUsuario.correo, subject, mensaje, null, null);
			else if(beanUsuario.usuario.equals(l.creador))
				enviarCorreo(contextPath, beanUsuario.correo, subject, mensaje, null, null);
			else if(beanUsuario.usuario.equals(l.responsable))
				enviarCorreo(contextPath, beanUsuario.correo, subject, mensaje, null, null);
	}
	
	public static void enviarCorreo(String contextPath, String to, String subject, String mensaje, String ruta, 
			HashMap<String, String> archivos) {
		try {
			if(ruta == null)
				ruta = "F:\\indelpro\\licitaciones\\";

			InitialContext ctx = new InitialContext();
			Session mailSession = (Session) ctx.lookup("java:comp/env/mail/Session");

//			MimeMessage message = new MimeMessage(mailSession);
//			message.setSubject(subject);
//			message.setFrom(new InternetAddress("hdindelpro@indelpro.com", "Portal Licitaciones Indelpro"));
//			message.setContent(mensaje, "text/html; charset=ISO-8859-1");
//			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
//			message.addRecipient(Message.RecipientType.BCC, new InternetAddress("cervantesfrancisco@gmail.com"));
//			Transport.send(message);
			
			Message msg = new MimeMessage(mailSession);
			 
	        msg.setFrom(new InternetAddress("hdindelpro@indelpro.com", "Portal Licitaciones Indelpro"));
	        if(to == null)
	        	return;
	        if(to.contains(";")) {
	        	String[] tos = to.split(";");
	        	for(String ti: tos)
	        		if(ti != null && ti.trim().length() > 0)
	        			msg.addRecipient(Message.RecipientType.BCC, new InternetAddress(ti.trim()));
	        } else
	        	msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	        msg.addRecipient(Message.RecipientType.BCC, new InternetAddress("cervantesfrancisco@gmail.com"));
	        msg.addRecipient(Message.RecipientType.BCC, new InternetAddress("hdindelpro@indelpro.com"));
	        msg.addRecipient(Message.RecipientType.BCC, new InternetAddress("iblanco@indelpro.com"));
	        msg.setSubject(contextPath != null && contextPath.contains("dev")? "------PRUEBA------- "+subject:subject);
	 
	        Multipart multipart = new MimeMultipart("related");

	        MimeBodyPart messageBodyPart = new MimeBodyPart();
	        messageBodyPart.setContent(mensaje, "text/html; charset=ISO-8859-1");
	        multipart.addBodyPart(messageBodyPart);

	        if(archivos != null)
		        try {
		        	for (Iterator iterator = archivos.keySet().iterator(); iterator.hasNext();) {
						String archivo = (String) iterator.next();
				        MimeBodyPart attachPart = new MimeBodyPart();
		                attachPart.attachFile(ruta + archivo);
		                attachPart.setFileName(archivos.get(archivo));
		                System.out.println("anexa "+archivos.get(archivo));
		                multipart.addBodyPart(attachPart);	        
					}
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        if(mensaje.indexOf("cid:logo_indelpro.jpg") > 0)
		        try {
			        MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<logo_indelpro.jpg>");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
			        imagePart.attachFile(ruta + "logo_indelpro.jpg");
	                multipart.addBodyPart(imagePart);	        
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }

            msg.setContent(multipart);
            
            Scheduler scheduler = new StdSchedulerFactory().getScheduler();
            if(scheduler != null && scheduler.isStarted()) {
            	JobDetail jobDetail = JobBuilder.newJob(MailerJob.class)
                        .withIdentity(UUID.randomUUID().toString(), "INDELPRO_MAILER")
                        .build();
            	jobDetail.getJobDataMap().put("MESSAGE", msg);
         
                Trigger trigger = TriggerBuilder.newTrigger()
                        .withIdentity(UUID.randomUUID().toString(), "INDELPRO_MAILER")
                        .startNow()
                        .build();
         
                scheduler.scheduleJob(jobDetail, trigger);
            } else
            	Transport.send(msg);
		} catch (Exception e) {
			System.err.println("Error al enviar correo: " + e.getMessage());
//			e.printStackTrace();
		} catch (Error r) {
			r.printStackTrace();
		}
	}

	public static String mensajeEnvio(BeanLicitacion l, String usuario, String contra, String contextPath) throws ParseException {
		return 
				"<html> " +
				"<body> " +
				"<table class='MsoNormalTable' border='1' cellspacing='0' cellpadding='0' width='447' style='width:447.0pt;mso-cellspacing:0cm;background:white;border:solid #CCCCCC 1.0pt; " +
				" mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'> " +
				" <tbody><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:5.25pt'> " +
				"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:5.25pt'> " +
				"  <p class='MsoNormal' style='mso-line-height-alt:5.25pt'><span style='font-size:11.0pt; " +
				"  font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222; " +
				"  mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				" </tr> " +
				" <tr style='mso-yfti-irow:1;height:18.75pt'> " +
				"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:18.75pt'> </td> " +
				"  <td style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:18.75pt'> " +
				"  <p class='MsoNormal'><img src='cid:logo_indelpro.jpg'/></span></p> " +
				"  </td> " +
				"  <td width='150' style='width:150.0pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:18.75pt'> " +
				"  <p class='MsoNormal' align='right' style='text-align:right'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#1F497D;mso-ansi-language:EN-US'>" + dfTradicional.format(new Date()) + "</span " +
				"  </td> " +
				"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:18.75pt'> " +
				"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				" </tr> " +
				" <tr style='mso-yfti-irow:2;height:11.25pt'> " +
				"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:11.25pt'> " +
				"  <div class='MsoNormal' align='center' style='text-align:center'><span style='font-size:9.0pt;font-family:Arial;mso-fareast-font-family:&quot;Times New Roman&quot;; " +
				"  mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222;mso-ansi-language:EN-US'> " +
				"  <hr size='1' width='100%' align='center'> " +
				"  </span></div> " +
				"  </td> " +
				" </tr> " +
				" <tr style='mso-yfti-irow:3;height:15.0pt'> " +
				"  <td width='8' valign='bottom' style='width:7.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:15.0pt'> " +
				"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				"  <td colspan='2' style='border:none;padding:0cm 0cm 0cm 0cm;height:15.0pt'> " +
				"  <p class='MsoNormal' style='mso-margin-top-alt:auto;margin-bottom:1.5pt; " +
				"  mso-outline-level:1'><span class='SpellE'><b><span style='font-size:10.5pt; " +
				"  font-family:Verdana;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family: " +
				"  &quot;Times New Roman&quot;;color:#0066CC;mso-font-kerning:18.0pt;mso-ansi-language: " +
				"  EN-US'>Indelpro S.A. de C.V.<o:p></o:p></span></b></p> " +
				"  <p class='MsoNormal'><span class='SpellE'><i><span style='font-size:9.0pt; " +
				"  font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#333333; " +
				"  mso-ansi-language:EN-US'>Departamento de Abastecimientos</span></span></i><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span class='SpellE'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family: " +
				"  &quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language:EN-US'>"
				+ "Por medio del presente ha sido cordialmente invitado a participar en el concurso:"
				+ "<br><br>You are hereby invited to participate in the following bid:"
				+ "</span></span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  <div align='center'> " +
				"  <table class='MsoNormalTable' border='0' cellspacing='0' cellpadding='0' width='434' style='width:434.15pt;mso-cellspacing:0cm;background:white;mso-yfti-tbllook: " +
				"   1184;mso-padding-alt:0cm 0cm 0cm 0cm'> " +
				"   <tbody><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:15.0pt'> " +
				"    <td width='17%' style='width:17.0%;border:solid #CCCCCC 1.0pt;background: " +
				"    #EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt;height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "Licitaci�n / Bid </span></b></span><span style='font-size:11.0pt; " +
				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td width='82%' style='width:82.0%;border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
				"    EN-US'>" + l.numeroLicitacion + "</span><span style='font-size:11.0pt;font-family:Calibri; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
				"   <tr style='mso-yfti-irow:1;height:15.0pt'> " +
				"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "T�tulo / Title</span></b></span><span style='font-size:11.0pt;font-family: " +
				"    Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D; " +
				"    mso-ansi-language:EN-US'>" + l.descripcion + "</span><span style='font-size:11.0pt; " +
				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
				"   <tr style='mso-yfti-irow:2;height:15.0pt'> " +
				"    <td width='17%' style='width:17.0%;border:solid #CCCCCC 1.0pt;background: " +
				"    #EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt;height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "Usuario / Username</span></b></span><span style='font-size:11.0pt;font-family: " +
				"    Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td width='82%' style='width:82.0%;border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
				"    EN-US'>" + usuario + "</span><span style='font-size:11.0pt;font-family: " +
				"    Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
				"   <tr style='mso-yfti-irow:3;height:15.0pt'> " +
				"    <td width='17%' style='width:17.0%;border:solid #CCCCCC 1.0pt;background: " +
				"    #EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt;height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "Contrase�a / Password</span></b></span><span style='font-size:11.0pt; " +
				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td width='82%' style='width:82.0%;border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
				"    EN-US'>" + contra + "</span><span style='font-size:11.0pt;font-family:Calibri; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
				"   <tr style='mso-yfti-irow:4;height:15.0pt'> " +
				"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "Liga de Acceso / Access Link</span></b></span><b><span style='font-size:8.0pt;font-family: " +
				"    Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'></span></b><span style='font-size:11.0pt; " +
				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><a href='http://www.licitaciones.indelpro.com"
				+ contextPath //"/prt"
				+ "/loginProveedor.jsp'><span style='color:#1155CC'>www.licitaciones.indelpro.com</span></a><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
				"   <tr style='mso-yfti-irow:5;height:15.0pt'> " +
				"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "Requisitos / Requirements</span></b></span><span style='font-size:11.0pt; " +
				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
				"    EN-US'>Favor de apegarse estrictamente a las Bases y Alcances de licitaci�n anexas." + 
				"			<br>Las propuestas t�cnicas y econ�micas deber�n ser ingresadas al portal en archivos independientes con formato PDF." + 
				"			<br><br>Please adhere to the attached Bidding Terms and Conditions. All technical and economic proposals should be entered in the Portal in independent PDF files." + 
				"	</span></span><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"    mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
				(l.fechaVisitaObra == null? "":
					"   <tr style='mso-yfti-irow:6;height:15.0pt'> " +
					"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
					"    height:15.0pt'> " +
					"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
					"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
					"    EN-US'>"
					+ "Fecha de visita de Obra / Site Visit</span></span></b><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
					"    mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
					"    </td> " +
					"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
					"    height:15.0pt'> " +
					"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
					"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
					"    EN-US'>" +
					dfTradicional.format(df.parse(l.fechaVisitaObra)) + 
					"</span><span style='font-size:11.0pt;font-family:Calibri; " +
					"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
					"    </td> " +
					"   </tr> ") +
//				"   <tr style='mso-yfti-irow:7;height:15.0pt'> " +
//				"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
//				"    height:15.0pt'> " +
//				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
//				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
//				"    EN-US'>Requisitos de Visita de Obra</span></span></b><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
//				"    mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
//				"    </td> " +
//				"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
//				"    height:15.0pt'> " +
//				"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
//				"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
//				"    EN-US'>Requisitos de Visita de Obra det</span>.</span><span style='font-size:11.0pt; " +
//				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
//				"    EN-US'><o:p></o:p></span></p> " +
//				"    </td> " +
//				"   </tr> " +
				"   <tr style='mso-yfti-irow:8;mso-yfti-lastrow:yes;height:15.0pt'> " +
				"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "Fecha L�mite de Recepci�n de Propuestas / Deadline</span></span></b><span style='font-size:11.0pt; " +
				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
				"    EN-US'>" + dfTradicional.format(df.parse(l.fechaLimite)) + " a las 12:00 p.m.</span><span style='font-size:11.0pt;font-family:Calibri; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
				"  </tbody></table> " +
				"  </div> " +
				"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'>"
				+ "<b>Aviso Importante: Toda licitaci�n recibida por medio de este Portal deber� de ser ingresada a trav�s del mismo. Quedan prohibidas las propuestas t�cnicas y econ�micas recibidas por cualquier otro medio, est�s ser�n consideradas una violaci�n a los lineamientos de la licitaci�n y quedar�n autom�ticamente descalificados. "
				+ " <br><br>Important Notice: We encourage you to please take into consideration that all requests for quotation or proposals received through this Portal must be replied in the same manner. Any technical and/or economic proposals received by other means will be consider grounds for violation of requirements and will be automatically disqualified from the bid in question."
				+ "</b>"
				+ " </span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				"  <td width='8' valign='bottom' style='width:7.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:15.0pt'> " +
				"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				" </tr> " +
				" <tr style='mso-yfti-irow:4;height:11.25pt'> " +
				"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:11.25pt'> " +
				"  <div class='MsoNormal' align='center' style='text-align:center'><span style='font-size:9.0pt;font-family:Arial;mso-fareast-font-family:&quot;Times New Roman&quot;; " +
				"  mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222;mso-ansi-language:EN-US'> " +
				"  <hr size='1' width='100%' align='center'> " +
				"  </span></div> " +
				"  </td> " +
				" </tr> " +
				" <tr style='mso-yfti-irow:5;height:18.75pt'> " +
				"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:18.75pt'> " +
				"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				"  <td width='426' colspan='2' style='width:426.0pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:18.75pt'> " +
				"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span style='font-size:7.5pt;font-family:Verdana;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#1F497D;mso-ansi-language:EN-US'>"
				+ "Para cualquier duda o aclaraci�n favor de consultar al comprador. " + leyendaNavegador + ""
				+ "<br><br>Please consult the buyer for any doubt or clarification.<br>Please use Chrome, Firefox or Internet Explorer 11 or superior for a better experience."
				+ "</span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
				"  height:18.75pt'> " +
				"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				" </tr> " +
				" <tr style='mso-yfti-irow:6;mso-yfti-lastrow:yes'> " +
				"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm'> " +
				"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"  </td> " +
				" </tr> " +
				"</tbody></table> " +
				"<p class='MsoNormal'><span lang='ES-TRAD'><o:p>&nbsp;</o:p></span></p> " +
				"</body></html> ";
		}
	
	public static String mensajeBaseProveedor(BeanLicitacion l, String arriba, String abajo, String contextPath) throws ParseException {
		String fecha = "";
		try {
			fecha = dfTradicional.format(df.parse(l.fechaLimite));
		} catch (ParseException e) {}
		return 
			"<html> " +
			"<body> " +
			"<table class='MsoNormalTable' border='1' cellspacing='0' cellpadding='0' width='447' style='width:447.0pt;mso-cellspacing:0cm;background:white;border:solid #CCCCCC 1.0pt; " +
			" mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'> " +
			" <tbody><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:5.25pt'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:5.25pt'> " +
			"  <p class='MsoNormal' style='mso-line-height-alt:5.25pt'><span style='font-size:11.0pt; " +
			"  font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222; " +
			"  mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:1;height:18.75pt'> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> </td> " +
			"  <td style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><img src='cid:logo_indelpro.jpg'/></span></p> " +
			"  </td> " +
			"  <td width='150' style='width:150.0pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal' align='right' style='text-align:right'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#1F497D;mso-ansi-language:EN-US'>" + dfTradicional.format(new Date()) + "</span " +
			"  </td> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:2;height:11.25pt'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:11.25pt'> " +
			"  <div class='MsoNormal' align='center' style='text-align:center'><span style='font-size:9.0pt;font-family:Arial;mso-fareast-font-family:&quot;Times New Roman&quot;; " +
			"  mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222;mso-ansi-language:EN-US'> " +
			"  <hr size='1' width='100%' align='center'> " +
			"  </span></div> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:3;height:15.0pt'> " +
			"  <td width='8' valign='bottom' style='width:7.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:15.0pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td colspan='2' style='border:none;padding:0cm 0cm 0cm 0cm;height:15.0pt'> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;margin-bottom:1.5pt; " +
			"  mso-outline-level:1'><span class='SpellE'><b><span style='font-size:10.5pt; " +
			"  font-family:Verdana;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family: " +
			"  &quot;Times New Roman&quot;;color:#0066CC;mso-font-kerning:18.0pt;mso-ansi-language: " +
			"  EN-US'>Indelpro S.A. de C.V.<o:p></o:p></span></b></p> " +
			"  <p class='MsoNormal'><span class='SpellE'><i><span style='font-size:9.0pt; " +
			"  font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#333333; " +
			"  mso-ansi-language:EN-US'>Departamento de Abastecimientos</span></span></i><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span class='SpellE'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family: " +
			"  &quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language:EN-US'>"
			+ arriba
			+ "</span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  <div align='center'> " +
			"  <table class='MsoNormalTable' border='0' cellspacing='0' cellpadding='0' width='434' style='width:434.15pt;mso-cellspacing:0cm;background:white;mso-yfti-tbllook: " +
			"   1184;mso-padding-alt:0cm 0cm 0cm 0cm'> " +
			"   <tbody><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:15.0pt'> " +
			"    <td width='17%' style='width:17.0%;border:solid #CCCCCC 1.0pt;background: " +
			"    #EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt;height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'>Licitaci�n / BID</span></b></span><span style='font-size:11.0pt; " +
			"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td width='82%' style='width:82.0%;border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
			"    EN-US'>" + l.numeroLicitacion + "</span><span style='font-size:11.0pt;font-family:Calibri; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +
			
			"   <tr style='mso-yfti-irow:1;height:15.0pt'> " +
			"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'>T�tulo / Title</span></b></span><span style='font-size:11.0pt;font-family: " +
			"    Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D; " +
			"    mso-ansi-language:EN-US'>" + l.descripcion + "</span><span style='font-size:11.0pt; " +
			"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +
			
			"   <tr style='mso-yfti-irow:8;mso-yfti-lastrow:yes;height:15.0pt'> " +
			"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'>Fecha L�mite de Recepci�n de Propuestas</span></span></b><span style='font-size:11.0pt; " +
			"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
			"    EN-US'>" + fecha + "</span><span style='font-size:11.0pt;font-family:Calibri; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +
			(l.fechaVisitaObra == null? "":
				"   <tr style='mso-yfti-irow:6;height:15.0pt'> " +
				"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>Fecha de visita de Obra</span></span></b><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
				"    mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
				"    EN-US'>" +
				dfTradicional.format(df.parse(l.fechaVisitaObra)) + 
				"</span><span style='font-size:11.0pt;font-family:Calibri; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> ") +
			

				"   <tr style='mso-yfti-irow:4;height:15.0pt'> " +
				"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
				"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'>"
				+ "Liga de Acceso / Access Link</span></b></span><b><span style='font-size:8.0pt;font-family: " +
				"    Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'></span></b><span style='font-size:11.0pt; " +
				"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
				"    EN-US'><o:p></o:p></span></p> " +
				"    </td> " +
				"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
				"    height:15.0pt'> " +
				"    <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri; " +
				"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><a href='http://www.licitaciones.indelpro.com"
				+ contextPath //"/prt"
				+ "'><span style='color:#1155CC'>www.licitaciones.indelpro.com</span></a><o:p></o:p></span></p> " +
				"    </td> " +
				"   </tr> " +
	
				
			"  </tbody></table> " +
			"  </div> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'>"
			+ abajo
			+ "</span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td width='8' valign='bottom' style='width:7.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:15.0pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:4;height:11.25pt'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:11.25pt'> " +
			"  <div class='MsoNormal' align='center' style='text-align:center'><span style='font-size:9.0pt;font-family:Arial;mso-fareast-font-family:&quot;Times New Roman&quot;; " +
			"  mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222;mso-ansi-language:EN-US'> " +
			"  <hr size='1' width='100%' align='center'> " +
			"  </span></div> " +
			"  </td> " +
			" </tr> " +
			
			" <tr style='mso-yfti-irow:5;height:18.75pt'> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td width='426' colspan='2' style='width:426.0pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span style='font-size:7.5pt;font-family:Verdana;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#1F497D;mso-ansi-language:EN-US'>"
			+ "<b>Aviso Importante: Toda licitaci�n recibida por medio de este Portal deber� de ser ingresada a trav�s del mismo. Quedan prohibidas las propuestas t�cnicas y econ�micas recibidas por cualquier otro medio, est�s ser�n consideradas una violaci�n a los lineamientos de la licitaci�n y quedar�n autom�ticamente descalificados. "
			+ " <br><br>Important Notice: We encourage you to please take into consideration that all requests for quotation or proposals received through this Portal must be replied in the same manner. Any technical and/or economic proposals received by other means will be consider grounds for violation of requirements and will be automatically disqualified from the bid in question."
			+ "</b>"
			+ "</span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:6;mso-yfti-lastrow:yes'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			"</tbody></table> " +
			"<p class='MsoNormal'><span lang='ES-TRAD'><o:p>&nbsp;</o:p></span></p> " +
			"</body></html> ";
	}
	
	public static String mensajeBase(BeanLicitacion l, String mensaje, String mensajeAbajo, boolean incluyeProveedores, String contextPath) {
//		DAOUsuario daou = new DAOUsuario();
		System.err.println("mensajeBase "+ new Date() + " " + l.numeroLicitacion + " " + l.descripcion + " " + l.creador + " " + l.responsable);
//		BeanUsuario usuarioCreador = daou.obtenUsuario(l.creador);
//		if(usuarioCreador == null)
//			usuarioCreador = new BeanUsuario();
//		BeanUsuario usuarioResponsable = daou.obtenUsuario(l.responsable);
		String proveedores = "<UL>";
		if(l.listaProveedores != null)
			for(HashMap p: l.listaProveedores) {
				proveedores += "\n<li>"+p.get("numeroSAP") + " - " + p.get("nombre");
			}
		proveedores += "</UL>";
		String fecha = "";
		try {
			fecha = dfTradicional.format(df.parse(l.fechaLimite));
		} catch (ParseException e) {}
		return 
			"<html> " +
			"<body> " +
			"<table class='MsoNormalTable' border='1' cellspacing='0' cellpadding='0' width='447' style='width:447.0pt;mso-cellspacing:0cm;background:white;border:solid #CCCCCC 1.0pt; " +
			" mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'> " +
			" <tbody><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:5.25pt'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:5.25pt'> " +
			"  <p class='MsoNormal' style='mso-line-height-alt:5.25pt'><span style='font-size:11.0pt; " +
			"  font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222; " +
			"  mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:1;height:18.75pt'> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> </td> " +
			"  <td style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><img src='cid:logo_indelpro.jpg'/></span></p> " +
			"  </td> " +
			"  <td width='150' style='width:150.0pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal' align='right' style='text-align:right'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#1F497D;mso-ansi-language:EN-US'>" + dfTradicional.format(new Date()) + "</span " +
			"  </td> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:2;height:11.25pt'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:11.25pt'> " +
			"  <div class='MsoNormal' align='center' style='text-align:center'><span style='font-size:9.0pt;font-family:Arial;mso-fareast-font-family:&quot;Times New Roman&quot;; " +
			"  mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222;mso-ansi-language:EN-US'> " +
			"  <hr size='1' width='100%' align='center'> " +
			"  </span></div> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:3;height:15.0pt'> " +
			"  <td width='8' valign='bottom' style='width:7.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:15.0pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td colspan='2' style='border:none;padding:0cm 0cm 0cm 0cm;height:15.0pt'> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;margin-bottom:1.5pt; " +
			"  mso-outline-level:1'><span class='SpellE'><b><span style='font-size:10.5pt; " +
			"  font-family:Verdana;mso-fareast-font-family:&quot;Times New Roman&quot;;mso-bidi-font-family: " +
			"  &quot;Times New Roman&quot;;color:#0066CC;mso-font-kerning:18.0pt;mso-ansi-language: " +
			"  EN-US'>Indelpro S.A. de C.V.<o:p></o:p></span></b></p> " +
			"  <p class='MsoNormal'><span class='SpellE'><i><span style='font-size:9.0pt; " +
			"  font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#333333; " +
			"  mso-ansi-language:EN-US'>Departamento de Abastecimientos</span></span></i><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span class='SpellE'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family: " +
			"  &quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language:EN-US'>"
			+ mensaje
			+ "</span></span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  <div align='center'> " +
			"  <table class='MsoNormalTable' border='0' cellspacing='0' cellpadding='0' width='434' style='width:434.15pt;mso-cellspacing:0cm;background:white;mso-yfti-tbllook: " +
			"   1184;mso-padding-alt:0cm 0cm 0cm 0cm'> " +
			"   <tbody><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:15.0pt'> " +
			"    <td width='17%' style='width:17.0%;border:solid #CCCCCC 1.0pt;background: " +
			"    #EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt;height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'>Licitaci�n</span></b></span><span style='font-size:11.0pt; " +
			"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td width='82%' style='width:82.0%;border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
			"    EN-US'>" + l.numeroLicitacion + "</span><span style='font-size:11.0pt;font-family:Calibri; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +
			"   <tr style='mso-yfti-irow:1;height:15.0pt'> " +
			"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'>T�tulo</span></b></span><span style='font-size:11.0pt;font-family: " +
			"    Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D; " +
			"    mso-ansi-language:EN-US'>" + l.descripcion + "</span><span style='font-size:11.0pt; " +
			"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +

			"   <tr style='mso-yfti-irow:1;height:15.0pt'> " +
			"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; height:15.0pt'>  <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt;  font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: EN-US'>"
			+ "Usuario Responsable" + 	
			"	 </span></b></span><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; height:15.0pt'> <p class='MsoNormal'><span class='SpellE'><span style='font-size:8.0pt; font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D; mso-ansi-language:EN-US'>" 
			+ l.nombreResponsable + //usuarioResponsable == null ? l.responsable: usuarioResponsable.nombre + 
			"	 </span><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +

			"   <tr style='mso-yfti-irow:8;mso-yfti-lastrow:yes;height:15.0pt'> " +
			"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'>Fecha L�mite de Recepci�n de Propuestas</span></span></b><span style='font-size:11.0pt; " +
			"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span style='font-size:8.0pt;font-family:Arial; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D;mso-ansi-language: " +
			"    EN-US'>" + fecha + "</span><span style='font-size:11.0pt;font-family:Calibri; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +
			
			(incluyeProveedores ?
					"   <tr style='mso-yfti-irow:1;height:15.0pt'> " +
					"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; height:15.0pt'>  <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt;  font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: EN-US'>"
					+ "Proveedores Invitados:" + 	
					"	 </span></b></span><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
					"    </td> " +
					"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; height:15.0pt'> <p class='MsoNormal'><span class='SpellE'><span style='font-size:8.0pt; font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D; mso-ansi-language:EN-US'>" 
					+ proveedores + 
					"	 </span><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: EN-US'><o:p></o:p></span></p> " +
					"    </td> " +
					"   </tr> "
					:
					"") +
			
			"   <tr style='mso-yfti-irow:1;height:15.0pt'> " +
			"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; height:15.0pt'>  <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt;  font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: EN-US'>"
			+ "Comprador Responsable" + 	
			"	 </span></b></span><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; height:15.0pt'> <p class='MsoNormal'><span class='SpellE'><span style='font-size:8.0pt; font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;color:#1F497D; mso-ansi-language:EN-US'>" 
			+ l.nombreCreador + //usuarioCreador.nombre + 
			"	 </span><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +

			"   <tr style='mso-yfti-irow:4;height:15.0pt'> " +
			"    <td style='border:solid #CCCCCC 1.0pt;background:#EEEEEE;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span class='SpellE'><b><span style='font-size:8.0pt; " +
			"    font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'>"
			+ "Liga de Acceso / Access Link</span></b></span><b><span style='font-size:8.0pt;font-family: " +
			"    Arial;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'></span></b><span style='font-size:11.0pt; " +
			"    font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language: " +
			"    EN-US'><o:p></o:p></span></p> " +
			"    </td> " +
			"    <td style='border:solid #CCCCCC 1.0pt;padding:3.0pt 3.0pt 3.0pt 3.0pt; " +
			"    height:15.0pt'> " +
			"    <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri; " +
			"    mso-bidi-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN-US'><a href='http://www.licitaciones.indelpro.com"
			+ contextPath //"/prt"
			+ "'><span style='color:#1155CC'>www.licitaciones.indelpro.com</span></a><o:p></o:p></span></p> " +
			"    </td> " +
			"   </tr> " +

			
			"  </tbody></table> " +
			"  </div> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span style='font-size:9.0pt;font-family:Arial;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'>"
			+ mensajeAbajo +
			"  </span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td width='8' valign='bottom' style='width:7.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:15.0pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:4;height:11.25pt'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm;height:11.25pt'> " +
			"  <div class='MsoNormal' align='center' style='text-align:center'><span style='font-size:9.0pt;font-family:Arial;mso-fareast-font-family:&quot;Times New Roman&quot;; " +
			"  mso-bidi-font-family:&quot;Times New Roman&quot;;color:#222222;mso-ansi-language:EN-US'> " +
			"  <hr size='1' width='100%' align='center'> " +
			"  </span></div> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:5;height:18.75pt'> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td width='426' colspan='2' style='width:426.0pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal' style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto'><span style='font-size:7.5pt;font-family:Verdana;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#1F497D;mso-ansi-language:EN-US'></span><span style='font-family:&quot;Times New Roman&quot;;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			"  <td width='11' style='width:10.5pt;border:none;padding:0cm 0cm 0cm 0cm; " +
			"  height:18.75pt'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			" <tr style='mso-yfti-irow:6;mso-yfti-lastrow:yes'> " +
			"  <td colspan='4' style='border:none;padding:0cm 0cm 0cm 0cm'> " +
			"  <p class='MsoNormal'><span style='font-size:11.0pt;font-family:Calibri;mso-bidi-font-family:&quot;Times New Roman&quot;; " +
			"  color:#222222;mso-ansi-language:EN-US'><o:p></o:p></span></p> " +
			"  </td> " +
			" </tr> " +
			"</tbody></table> " +
			"<p class='MsoNormal'><span lang='ES-TRAD'><o:p>&nbsp;</o:p></span></p> " +
			"</body></html> ";
	}
}
