package com.indelpro.util;

import java.awt.Color;
import java.io.IOException;
import java.lang.reflect.Array;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDSimpleFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.encoding.Encoding;
import org.apache.pdfbox.pdmodel.font.encoding.WinAnsiEncoding;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import com.indelpro.model.BeanLicitacion;
import com.indelpro.model.BeanProveedor;
import com.indelpro.model.dao.DAOLicitacion;
import com.indelpro.model.dao.DAOProveedor;

public class PDFUtil {
	private static final SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
	private static final SimpleDateFormat dfTradicional = new SimpleDateFormat("dd / MM / yyyy");
	private static final NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
	static float margin = 50;
	private static PDFont fontPlain = PDType1Font.HELVETICA;
	private static PDFont fontBold = PDType1Font.HELVETICA_BOLD;
	private static PDFont fontItalic = PDType1Font.HELVETICA_OBLIQUE;
	private static PDFont fontMonoBold = PDType1Font.COURIER_BOLD;
	private static PDFont fontMonoItalic = PDType1Font.COURIER_OBLIQUE;
	private static PDFont fontMono = PDType1Font.COURIER;
	
	private static float getWidth(PDFont font, String texto, int fs) throws IOException {
		return (font.getStringWidth(texto) / 1000.0f) * fs;
	}
	
	private static void agregaParrafo(PDPageContentStream contentStream, PDFont pdfFont, List<String> lines,
			int fontSize, float width, float leading) throws IOException {
		int i = lines.size();
		for (String line : lines) {
			float charSpacing = 0;
			if (line.length() > 1) {
				float size = fontSize * pdfFont.getStringWidth(line) / 1000;
				float free = width - size;
				if (free > 0) {
					charSpacing = free / (line.length() - 1);
				}
			}
			if(--i == 0)
				contentStream.appendRawCommands(String.format("%f Tc\n", 0f).replace(',', '.'));
			else
				contentStream.appendRawCommands(String.format("%f Tc\n", charSpacing).replace(',', '.'));

//			contentStream.drawString(line);
			contentStream.showText(line);
//			contentStream.moveTextPositionByAmount(0, -leading);
			contentStream.newLineAtOffset(0, -leading);
		}
	}
	
	private static String limpiaCadena(PDFont font, String input) {
		String output = input.replaceAll("\\p{Cc}", " ").replace('\n', ' ');
		
		if (font instanceof PDSimpleFont) {
			StringBuilder value = new StringBuilder();
			Encoding encoding = ((PDSimpleFont) font).getEncoding();
			for (int i = 0; i < output.length(); i++) {
				char c = output.charAt(i);
				if (".notdef".equals(encoding.getName(c)))
					value.append(' ');
				else
					value.append(c);
			}
			return value.toString();
		} else
			return output;
	}
	
	private static List<String> parteTexto(PDFont pdfFont, String text, int fontSize, float width) throws IOException {
		List<String> lines = new ArrayList<String>();
		int lastSpace = -1;
		while (text.length() > 0) {
			int spaceIndex = text.indexOf(' ', lastSpace + 1);
			if (spaceIndex < 0)
				spaceIndex = text.length();
			String subString = limpiaCadena(pdfFont, text.substring(0, spaceIndex));
			float size = fontSize * pdfFont.getStringWidth(subString) / 1000;
			if (size > width) {
				if (lastSpace < 0)
					lastSpace = spaceIndex;
				subString = text.substring(0, lastSpace);
				lines.add(subString);
				text = text.substring(lastSpace).trim();
				lastSpace = -1;
			} else if (spaceIndex == text.length()) {
				lines.add(text);
				text = "";
			} else {
				lastSpace = spaceIndex;
			}
		}
		return lines;
	}

	public static void drawTable(PDPage page, PDPageContentStream contentStream, float x, float y, float margin,
			int fontSize, float rowHeight, String[][] content, int[] colWidths, boolean[] rowLines) throws IOException {
		int rows = content.length;
		int cols = content[0].length;
//		final float rowHeight = 20f;
//		final float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
		float tableHeight = rowHeight * rows;
//		final float colWidth = tableWidth / (float) cols;
		final float cellMargin = 5f;

		List<String[]> nuevasLineas = new ArrayList<String[]>();
		
		// Wrap
		List<Boolean> rls = new ArrayList<Boolean>();
		for (int i = 0; i < content.length; i++) {
			int max = 0;
			for (int j = 0; j < content[i].length; j++) {
				List<String> lineas = parteTexto(fontPlain, content[i][j] == null ? "": content[i][j], fontSize, colWidths[j]);
				max = Math.max(max, lineas.size());
			}
			if(max == 1) {
				nuevasLineas.add(content[i]);
				rls.add(true);
			} else {
				String[][] nuevas = new String[max][content[i].length];
				for (int j = 0; j < content[i].length; j++) {
					List<String> lineas = parteTexto(fontPlain, content[i][j] == null ? "": content[i][j], fontSize, colWidths[j]);
					for(int k = 0; k < lineas.size(); k++)
						nuevas[k][j] = lineas.get(k);
				}
				for(int k = 0; k < nuevas.length; k++) {
					nuevasLineas.add(nuevas[k]);
					rls.add(k == 0);
				}
			}
		}
		rls.add(true);
		if(rowLines == null) {
			rowLines = new boolean[rls.size()];
			for (int i = 0; i < rls.size(); i++) 
				rowLines[i] = rls.get(i);
		}
		content = new String[nuevasLineas.size()][colWidths.length];
		for (int i = 0; i < nuevasLineas.size(); i++) {
			String[] linea = nuevasLineas.get(i);
			for (int j = 0; j < linea.length; j++)
				content[i][j] = linea[j];
		}

		rows = content.length;
		tableHeight = rowHeight * rows;
		float tableWidth = 0; 
		for (int i = 0; i < colWidths.length; i++) 
			tableWidth += colWidths[i];
		
		// draw the rows
		float nexty = y;
		for (int i = 0; i <= rows; i++) {
			if(rowLines == null || i == 0 || rowLines[i])
				contentStream.drawLine(x, nexty, x + tableWidth, nexty);
			nexty -= rowHeight;
		}

		// draw the columns
		float nextx = x;
		for (int i = 0; i <= cols; i++) {
			contentStream.drawLine(nextx, y, nextx, y - tableHeight);
			nextx += colWidths[i];
		}

		// now add the text
		float textx = x + cellMargin;
		float texty = y - rowHeight + 1.5f;
		for (int i = 0; i < content.length; i++) {
			if(i == 0)
				contentStream.setFont(fontBold, fontSize);
			else if(rowLines == null || rowLines[i])
				contentStream.setFont(fontPlain, fontSize);
			for (int j = 0; j < content[i].length; j++) {
				String text = content[i][j] == null ? "": content[i][j];
				contentStream.beginText();
				contentStream.moveTextPositionByAmount(textx, texty);
				contentStream.drawString(limpiaCadena(i==0?fontBold:fontPlain, text));
				contentStream.endText();
				textx += colWidths[j];
			}
			texty -= rowHeight;
			textx = x + cellMargin;
		}
	}

	public static String generaActaResultados(BeanLicitacion l, String ruta) {
		String fileAR = "ActaResultadosLicitacion_" + l.numeroLicitacion.replaceAll("[^\\w\\s]","") + ".pdf";
	    DAOProveedor dp = new DAOProveedor();
	    BeanProveedor bp = dp.obtenProveedor(l.proveedorGanador);
		try {
			PDDocument document = new PDDocument();
			PDPage page1 = new PDPage(PDRectangle.LETTER);
			PDRectangle rect = page1.getMediaBox();
			document.addPage(page1);
			PDImageXObject pdImage = PDImageXObject.createFromFile(ruta+"indelpro.jpg", document);
			PDPageContentStream cos = new PDPageContentStream(document, page1);
//		System.out.println(rect.getHeight() + " " + rect.getWidth());	 792.0 612.0
			float scale = .7f;
            cos.drawImage(pdImage, 20, rect.getHeight()-80, pdImage.getWidth()*scale, pdImage.getHeight()*scale);
            
			int line = 0;
			int fontSize = 10;
			float width = rect.getWidth() - 2*margin;
			float leading = 1.25f * fontSize;
			float yPos = 0;
			
			cos.beginText();
			cos.setFont(fontPlain, fontSize);
			String texto = "Altamira, Tamaulipas";
			width = getWidth(fontPlain, texto, fontSize);
			cos.newLineAtOffset(rect.getWidth()-width-50, rect.getHeight() - 50);
			cos.showText(texto);
			cos.endText();
			
			cos.beginText();
			texto = dfTradicional.format(new Date());
			width = getWidth(fontPlain, texto, fontSize);
			cos.newLineAtOffset(rect.getWidth()-width-50, rect.getHeight() - 75);
			cos.showText(texto);
			cos.endText();

			cos.beginText();
			cos.setFont(fontBold, fontSize);
			texto = "Acta de Licitaci�n";
			width = getWidth(fontBold, texto, fontSize);
			cos.newLineAtOffset((rect.getWidth()-width)/2, rect.getHeight() - 120);
			cos.showText(texto);
			cos.endText();

//			cos.beginText();
//			texto = l.numeroLicitacion;
//			width = getWidth(fontBold, texto, fontSize);
//			cos.newLineAtOffset((rect.getWidth()-width)/2, rect.getHeight() - 135);
//			cos.showText(texto);
//			cos.endText();

			cos.beginText();
			cos.setFont(fontPlain, fontSize);
			width = rect.getWidth() - 2*margin;
			texto = "De conformidad a la Pol�tica de Abastecimientos de ALFA, se concluye la siguiente licitaci�n:";
			List<String> lines = parteTexto(fontPlain, texto, fontSize, width);
			cos.newLineAtOffset(50, rect.getHeight() - 140);
			agregaParrafo(cos, fontPlain, lines, fontSize, width, leading);

			texto = "Datos de la Licitaci�n";
			cos.setFont(fontBold, fontSize);
			cos.newLineAtOffset(0, -leading);
			cos.showText(texto);

			cos.setFont(fontPlain, fontSize);
			cos.newLineAtOffset(0, -leading);
			cos.showText("Fecha: " + dfTradicional.format(new Date()));
			cos.newLineAtOffset(0, -leading);
			cos.showText("N�mero de Licitaci�n" + l.numeroLicitacion);
			if(l.elementoPEP != null) {
				cos.newLineAtOffset(0, -leading);
				cos.showText("Elemento PEP: " + l.elementoPEP);
			}
			cos.newLineAtOffset(0, -leading);
			cos.showText("Descripci�n: " + l.descripcion);
			cos.newLineAtOffset(0, -leading);
			cos.showText("Evaluador: " + l.nombreResponsable);
			cos.newLineAtOffset(0, -leading);
			cos.showText("Departamento Solicitante: Desarrollo de Operaciones");
			cos.newLineAtOffset(0, -leading);
			cos.showText("Comprador: " + l.nombreCreador);

//			cos.setFont(fontBold, fontSize);
//			cos.newLineAtOffset(0, -2 * leading);
//			cos.showText("Determinaci�n de Presupuesto");
//			cos.setFont(fontPlain, fontSize);
//			cos.newLineAtOffset(0, -leading);
//			cos.showText(currencyFormatter.format(l.importeEstimado) + " USD");

			
			cos.setFont(fontBold, fontSize);
			cos.newLineAtOffset(0, -2 * leading); // 11
			cos.showText("Proveedores Invitados");
			cos.setFont(fontPlain, fontSize);
			String[][] tableData = new String[l.listaProveedores.size()+1][2];
			tableData[0][0] = "RFC";
			tableData[0][1] = "Raz�n Social";
			int contador = 0;
			float widest = 0;
			for (HashMap proveedor: l.listaProveedores) {
				tableData[++contador][0] = (String) proveedor.get("rfc");
				tableData[contador][1] = (String) proveedor.get("nombre");
				widest = Math.max(widest, getWidth(fontPlain, tableData[contador][1], fontSize));
			}
			int[] colWidths = {100, (int) widest + 10, 0};
			cos.endText();
			yPos = rect.getHeight() - 140 - (12*leading);
			drawTable(page1, cos, margin, yPos, margin, fontSize, leading, tableData, colWidths, null);
//			for (HashMap proveedor: l.listaProveedores) {
//				cos.newLineAtOffset(0, -leading);
//				cos.showText("\u2022 " + proveedor.get("numeroSAP") + " " + proveedor.get("nombre"));
//			}
			
			yPos -= leading * (l.listaProveedores.size()+3);
			
			cos.beginText();
			cos.setFont(fontBold, fontSize);
			cos.newLineAtOffset(margin, yPos);
			cos.showText("Criterios de Evaluaci�n");
			cos.setFont(fontPlain, fontSize);
			cos.newLineAtOffset(0, -leading);
			cos.setFont(fontMonoBold, fontSize);
			cos.showText("Conceptos Generales");
			cos.endText();
			yPos -= leading * 2;

//			cos.newLineAtOffset(0, -leading);
//			cos.setFont(fontMonoItalic, fontSize);
			
			int cf1 = 1, cf2 = 1;
			for (HashMap concepto: l.lConceptosEvaluacion)
				if(Integer.parseInt(concepto.get("fase").toString()) == 1)
					cf1 ++;
				else 
					cf2 ++;
			tableData = new String[cf1][2];
			String[][] tableData2 = new String[cf2][2];
			tableData[0][0] = "Concepto";
			tableData[0][1] = "Porcentaje";
			tableData2[0][0] = "Concepto";
			tableData2[0][1] = "Porcentaje";
			contador = 0;
			int contador2 = 0;
			for (HashMap concepto: l.lConceptosEvaluacion) {
				if(Integer.parseInt(concepto.get("fase").toString()) == 1) {
					tableData[++contador][0] = concepto.get("concepto").toString();
					tableData[contador][1] = concepto.get("porcentaje") + " %";
				}
				if(Integer.parseInt(concepto.get("fase").toString()) == 2) {
					tableData2[++contador2][0] = concepto.get("concepto").toString();
					tableData2[contador2][1] = concepto.get("porcentaje") + " %";
				}
			}
			colWidths = new int[] {170, 60, 0};
			drawTable(page1, cos, margin, yPos, margin, fontSize, leading, tableData, colWidths, null);

			cos.beginText();
			cos.newLineAtOffset(300, yPos + leading);
			cos.setFont(fontMonoBold, fontSize);
			cos.showText("Conceptos T�cnicos");
			cos.endText();
			drawTable(page1, cos, 300, yPos, margin, fontSize, leading, tableData2, colWidths, null);

			int cc = 0;
			cos.close();

			page1 = new PDPage(PDRectangle.LETTER);
			document.addPage(page1);
			cos = new PDPageContentStream(document, page1);
			rect = page1.getMediaBox();

			cos.beginText();
			cos.setFont(fontBold, fontSize);
			cos.newLineAtOffset(50, rect.getHeight() -4 * leading);
			cos.showText("Evaluaci�n T�cnica");
			cos.endText();

			boolean[] rowLines = new boolean[l.listaProveedores.size()+4];
			rowLines[0] = false; rowLines[1] = false; rowLines[2] = false;
			tableData = new String[l.listaProveedores.size()+3][4];
			tableData[0][0] = "Raz�n Social";
			tableData[0][1] = "Ponderaci�n";
			tableData[0][2] = "Ponderaci�n";
			tableData[0][3] = "Total";
			tableData[1][0] = "";
			tableData[1][1] = "Conceptos";
			tableData[1][2] = "Conceptos";
			tableData[1][3] = "Evaluaci�n";
			tableData[2][0] = "";
			tableData[2][1] = "Generales";
			tableData[2][2] = "T�cnicos";
			tableData[2][3] = "";
			contador = 2;
			colWidths = new int[] {275, 75, 75, 75, 0};
			for (HashMap prov: l.listaProveedores) {
				List<String> ls = parteTexto(fontPlain, (String) prov.get("nombre"), fontSize, colWidths[0]);
				tableData[++contador][0] = ls.size()>0?ls.get(0):""; 
				tableData[contador][1] = prov.get("totalFase1") + "%";
				tableData[contador][2] = prov.get("totalFase2") + "%";
				tableData[contador][3] = prov.get("total") + "%";
				rowLines[contador] = true;
			}
			rowLines[++contador] = true;
			yPos = rect.getHeight() -5 * leading;
			drawTable(page1, cos, margin, yPos, margin, fontSize, leading, tableData, colWidths, rowLines);

			cos.beginText();
			yPos -= leading * (l.listaProveedores.size()+5);
			cos.setFont(fontBold, fontSize);
			cos.newLineAtOffset(margin, yPos);
			cos.showText("Evaluaci�n Econ�mica");
			cos.endText();
			tableData = new String[l.listaProveedores.size()+1][3];
			tableData[0][0] = "Raz�n Social";
			tableData[0][1] = "Monto";
			tableData[0][2] = "Ganador";
			contador = 0;
			colWidths = new int[] {335, 90, 75, 0};
			String nombreGanador = "";
			String importeGanador = "";
			for (HashMap prov: l.listaProveedores) {
				if(prov.get("ganador").equals(true)) {
					cos.setFont(fontMonoBold, fontSize);
					nombreGanador = prov.get("numeroSAP").toString() + " - " +prov.get("nombre");
					importeGanador = currencyFormatter.format(prov.get("IMPORTE"));
				}
				List<String> ls = parteTexto(fontPlain, (String) prov.get("nombre"), fontSize, colWidths[0]);
				tableData[++contador][0] = ls.size()>0?ls.get(0):""; 
				tableData[contador][1] = prov.get("disponible").equals(true)? currencyFormatter.format(prov.get("IMPORTE")): "-";
				tableData[contador][2] = (prov.get("ganador").equals(true) ? "GANADOR": "");
			}
			yPos -= leading;
			drawTable(page1, cos, margin, yPos, margin, fontSize, leading, tableData, colWidths, null);
	
			yPos -= leading * (l.listaProveedores.size()+3);
			cos.beginText();
			cos.setFont(fontBold, fontSize);
			cos.newLineAtOffset(margin, yPos);
			cos.showText("Proveedor Seleccionado");
			cos.setFont(fontPlain, fontSize);
			cos.newLineAtOffset(0, -leading);
			if(l.estatus != DAOLicitacion.REASIGNADA)
				texto = "Se asigna a \"" + nombreGanador + "\" por un monto de " + importeGanador + " " + l.moneda + ".";
			else
				texto = "Se asigna a \"" + nombreGanador + "\" por un monto de " + importeGanador + " " + l.moneda
				+ " mediante reasignaci�n. Justificaci�n: " + l.mensajeReasignacion;
			lines = parteTexto(fontPlain, texto, fontSize, width);
			agregaParrafo(cos, fontPlain, lines, fontSize, width, leading);
			yPos -= (lines.size() + 2) * leading;

			if(!l.proveedorGanador.equals(l.proveedorPropuesto) && l.estatus != DAOLicitacion.REASIGNADA) {
				cos.setFont(fontBold, fontSize);
				cos.newLineAtOffset(0, -leading);
				cos.showText("Comentario de Aprobaci�n");
				cos.setFont(fontPlain, fontSize);
				cos.newLineAtOffset(0, -leading);
				lines = parteTexto(fontPlain, l.mensajeAdjudicacion, fontSize, width);
				agregaParrafo(cos, fontPlain, lines, fontSize, rect.getWidth() - 2*margin, leading);
			}

			cos.setFont(fontBold, fontSize);
			cos.newLineAtOffset(0, -leading);
			cos.showText("Aprobaci�n de Comit�");
			cos.endText();
			tableData = new String[l.lAprobaciones.size()+1][4];
			tableData[0][0] = "Responsable";
			tableData[0][1] = "Aprueba";
			tableData[0][2] = "Fecha";
			tableData[0][3] = "Mensaje";
			contador = 0;
			colWidths = new int[] {77, 48, 75, 300, 0};
			for (HashMap apro: l.lAprobaciones) {
				tableData[++contador][0] = (String) apro.get("responsable");
				tableData[contador][1] = (apro.get("aprueba").equals(true) ? "SI": "NO");
				tableData[contador][2] =  dfTradicional.format(df.parse((String) apro.get("fecha")));
				List<String> ls = parteTexto(fontPlain, apro.get("mensaje") == null ? ""
						: ((String) apro.get("mensaje")).replaceAll("\\p{Cc}", " "), fontSize, colWidths[3]);
				tableData[contador][3] = ls.size()>0?ls.get(0):"";
			}
			yPos -= leading * 4;
			drawTable(page1, cos, margin, yPos, margin, fontSize, leading, tableData, colWidths, null);

			cos.close();
			document.save(ruta + fileAR);
	        document.close();
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return fileAR;
	}
	
	public static void main(String[] args) {
		DAOLicitacion d = new DAOLicitacion();
		BeanLicitacion l = d.obtiene("6200445625");
		System.out.println(PDFUtil.generaActaResultados(l, "F:\\indelpro\\licitaciones\\"));
	}
}
