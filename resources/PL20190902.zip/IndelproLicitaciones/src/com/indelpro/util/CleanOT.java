package com.indelpro.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CleanOT {
	public static void main(String[] args) {
		try (BufferedReader br = new BufferedReader(new FileReader("Y:\\Documents\\Arca\\tmp\\OT_SD_OCTUBRE.TXT"))) {
			BufferedWriter bw = new BufferedWriter(new FileWriter("Y:\\Documents\\Arca\\tmp\\OT_SD_OCTUBRE_BORRAR.TXT"));
		    String line;
		    String f;
		    List<String> folios = new ArrayList<>();
		    while ((line = br.readLine()) != null) {
		       f = line.substring(27, 34);
		       System.err.println(f);
		       if(folios.contains(f)) {
		    	   bw.write(line.substring(0, 10));
		    	   bw.newLine();
		       } else
		    	   folios.add(f);
		    }
		    bw.flush();
		    bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
