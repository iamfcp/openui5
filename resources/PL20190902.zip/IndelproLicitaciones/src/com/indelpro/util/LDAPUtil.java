package com.indelpro.util;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;

public class LDAPUtil {

	public static boolean validaLDAP(String usuario, String password) {
		Hashtable props = new Hashtable();
		String principalName = usuario+"@PDCINDELPRO";
		props.put(Context.SECURITY_PRINCIPAL, principalName);
		props.put(Context.SECURITY_CREDENTIALS, password);
		DirContext context;

		//try to authenticate
		try {
			context = com.sun.jndi.ldap.LdapCtxFactory.getLdapCtxInstance("LDAP://10.241.0.5:389" + '/', props);
			context.close();
			System.err.println("Valida LDAP: " + usuario + " - TRUE");
			return true;
		} catch (Exception e) {
			System.err.println("Valida LDAP: " + usuario + " - FALSE - " + e);
			return false;
		}
	}
}
