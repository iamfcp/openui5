package com.indelpro.sched;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.Date;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;

public class MailerJob implements Job {

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		try {
			JobDataMap data = context.getJobDetail().getJobDataMap();
			Message message = (Message) data.get("MESSAGE");
			System.out.println("Mailer Job " + new Date() + " " + message.getSubject() + " " + InternetAddress.toString(message.getAllRecipients()));
			Transport.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
}
