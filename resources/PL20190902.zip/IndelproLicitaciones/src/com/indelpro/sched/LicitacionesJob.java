package com.indelpro.sched;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.TemporalField;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.indelpro.model.BeanLicitacion;
import com.indelpro.model.BeanUsuario;
import com.indelpro.model.dao.DAOLicitacion;
import com.indelpro.model.dao.DAOUsuario;
import com.indelpro.util.Email;

public class LicitacionesJob implements Job {

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		System.out.println("INDELPRO: Cambia estatus licitaciones con plazo vencido " + new Date());
		DAOLicitacion dao = new DAOLicitacion();
		DateFormat f = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = GregorianCalendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		Date hoy = cal.getTime();
		DAOUsuario daou = new DAOUsuario();
		ArrayList<BeanUsuario> usuarios = daou.obtenUsuarios();
		JobDataMap data = arg0.getJobDetail().getJobDataMap();
		String contextPath = data.getString("CONTEXT_PATH");

		// Licitaciones que vencen
		List<BeanLicitacion> ls = dao.lista(DAOLicitacion.ENVIADA);
		for (Iterator iterator = ls.iterator(); iterator.hasNext();) {
			System.out.print("\nLicitacionesJob ");
			BeanLicitacion beanLicitacion = (BeanLicitacion) iterator.next();
			System.out.print(beanLicitacion.numeroLicitacion);
			System.out.print(beanLicitacion.getFechaLimite());
			System.out.print(beanLicitacion.getNumeroLicitacion());
			System.out.print(" " + hoy);
			try {
				System.out.print(" comp fec " + f.parse(beanLicitacion.getFechaLimite()).after(hoy));
				if(f.parse(beanLicitacion.getFechaLimite()).after(hoy)) 
					continue;
			} catch (Exception e) {
				e.printStackTrace();
			}
			int r = dao.cambiaEstatus(beanLicitacion.getNumeroLicitacion(), DAOLicitacion.VENCIO_PLAZO);
			dao.log(beanLicitacion.getNumeroLicitacion(), "PORTAL", DAOLicitacion.VENCIO_PLAZO, 
					beanLicitacion.getFechaLimite() + " " + hoy, "Vence plazo para enviar propuesta " + new Date());
			System.out.println(" result " + r);
			System.out.println("LicitacionesJob Vencidas:" + contextPath + " \n");
			String htmlMessage = "";
			try {
				htmlMessage = Email.mensajeBase(beanLicitacion, 
						"La fecha limite para recibir informaci�n correspondiente a la licitaci�n "
						+ beanLicitacion.getNumeroLicitacion()
						+ " \"" + beanLicitacion.descripcion + "\" ha vencido."
						+ "Favor de ingresar al portal de licitaciones Indelpro para liberar la informaci�n t�cnica y continuar con el proceso de evaluaci�n.",
						"", false, contextPath);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(htmlMessage);
			for (Iterator itUsr = usuarios.iterator(); itUsr.hasNext();) {
				BeanUsuario u = (BeanUsuario) itUsr.next();
				if(u.liberaPT) {
					Email.enviarCorreo(contextPath, 
						u.correo,
						"Licitaci�n lista para ser liberada", 
						htmlMessage,
						null,
						null);
					System.out.print(u.usuario);
				}
			}
		}


		LocalDateTime ldt = LocalDateTime.now();
		System.out.println("LicitacionesJob Hora: " + ldt.toString());
		if(ldt.getHour() < 8) {
			return;
		}
		// Proveedores que no han enviado propuesta
		ls = dao.lista(DAOLicitacion.ENVIADA);
		for (BeanLicitacion beanLicitacion: ls) {
			try {
				Calendar c = GregorianCalendar.getInstance();
				c.setTime(f.parse(beanLicitacion.getFechaLimite()));
				c.add(Calendar.DATE, -1);
				System.out.println("LicitacionesJob Proveedores que no han enviado propuesta " + beanLicitacion.numeroLicitacion + c.getTime().compareTo(hoy));
				if(c.getTime().compareTo(hoy) == 0) {
					beanLicitacion = dao.obtiene(beanLicitacion.numeroLicitacion);
					for (Iterator itProv = beanLicitacion.listaProveedores.iterator(); itProv.hasNext();) {
						HashMap map = (HashMap) itProv.next();
						if((double)map.get("IMPORTE") > 0)
							continue;
						String htmlMessage = Email.mensajeEnvio(beanLicitacion,  (String)map.get("rfc"), (String)map.get("clave"), contextPath);
						Email.enviarCorreo(contextPath, 
								(String)map.get("correo"), 
								"RECORDATORIO: Invitaci�n a participar en Licitaci�n Indelpro / Invitation to Bid", 
								htmlMessage, 
								null,
								null);
					}
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		}
		
		// Falta aprobaci�n
		ls = dao.lista(DAOLicitacion.ESPERA_APROBACION);
		for (BeanLicitacion beanLicitacion: ls) {
			try {
				System.out.println("LicitacionesJob Aprobadores pendientes " + beanLicitacion.numeroLicitacion);
				beanLicitacion = dao.obtiene(beanLicitacion.numeroLicitacion);
				String htmlMessage = Email.mensajeBase(beanLicitacion, "Se requiere de su aprobaci�n para continuar con el proceso.", "", false, contextPath);
				for (HashMap map: beanLicitacion.lAprobaciones) {
					if((boolean) map.get("enviada"))
						continue;
					BeanUsuario bu = daou.obtenUsuario((String) map.get("responsable"));
					if(bu == null || bu.correo == null)
						continue;
					Email.enviarCorreo(contextPath, 
							bu.correo,
							"RECORDATORIO: Licitaci�n lista para aprobaci�n", 
							htmlMessage, 
							null,
							null);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}

}
