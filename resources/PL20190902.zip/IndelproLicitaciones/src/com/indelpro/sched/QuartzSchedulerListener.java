package com.indelpro.sched;

import java.util.Date;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class QuartzSchedulerListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		Scheduler scheduler;
		try {
			scheduler = new StdSchedulerFactory().getScheduler();
			scheduler.shutdown();
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		String ctxPath = arg0.getServletContext().getContextPath();
		JobDetail job = JobBuilder.newJob(LicitacionesJob.class)
				.withIdentity("IndelproLicitacionesJob" + ctxPath, "GRUPO_1" + ctxPath).build();
		job.getJobDataMap().put("CONTEXT_PATH", ctxPath);
		JobDetail job2 = JobBuilder.newJob(LicitacionesJob.class)
				.withIdentity("IndelproLicitacionesJob2" + ctxPath, "GRUPO_1" + ctxPath).build();
		job2.getJobDataMap().put("CONTEXT_PATH", ctxPath);
		System.out.println("Inicializa Jobs Licitaciones: " + ctxPath);

		try {
			Trigger trigger = TriggerBuilder.newTrigger()
					.withIdentity("IndelproSchedTrigger" + ctxPath, "GRUPO_1" + ctxPath)
					.withSchedule(CronScheduleBuilder.cronSchedule("0 0 12 ? * MON-SUN *")).build();

			Trigger trigger2 = TriggerBuilder.newTrigger()
					.withIdentity("IndelproSchedTrigger2" + ctxPath, "GRUPO_1" + ctxPath)
					.withSchedule(CronScheduleBuilder.cronSchedule("0 0 23 ? * MON-SUN *")).build();

			Scheduler scheduler = new StdSchedulerFactory().getScheduler();
			scheduler.start();
			scheduler.scheduleJob(job, trigger);
			scheduler.scheduleJob(job2, trigger2);
			System.out.print("Scheduler: " + ctxPath + " - " + scheduler.toString() + " Jobs: ");
			List<String> jn = scheduler.getJobGroupNames();
			for(String n: jn)
				System.out.print(" " + n);
			System.out.println(". "+ new Date());
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
	}

}

