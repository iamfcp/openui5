package com.indelpro.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

public class MenuAction extends ActionSupport implements ServletResponseAware, SessionAware{
	private List<Map> menu = new ArrayList<Map>();
	private HttpServletResponse response;
	private SessionMap<String,Object> sessionMap; 
	
	
	public String execute() {
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		Map<String, String> menuItem; 
		
		if(bu != null) {
			if(bu.liberaPT) {
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Usuarios");
				menuItem.put("icon", "sap-icon://customer");
				menuItem.put("targetPage", "Usuarios");
//				menuItem.put("description", "Administraci�n de Usuarios");
				menu.add(menuItem);
			} if(bu.abastecimientos || bu.liberaPT) {
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Proveedores");
				menuItem.put("icon", "sap-icon://supplier");
				menuItem.put("targetPage", "Proveedores");
//				menuItem.put("description", "Administraci�n de Proveedores");
				menu.add(menuItem);
			}
			if(bu.abastecimientos) {
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Crear Licitaci�n");
				menuItem.put("icon", "sap-icon://create");
				menuItem.put("targetPage", "CreaLicitacion");
//				menuItem.put("description", "Crear Licitaci�n");
				menu.add(menuItem);
			}
			if(bu.liberaPT) {
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Libera Propuestas T�cnicas");
				menuItem.put("icon", "sap-icon://multi-select");
				menuItem.put("targetPage", "LiberaPropuestasTecnicas");
//				menuItem.put("description", "Libera Propuestas T�cnicas");
				menu.add(menuItem);
			}
			if(bu.evalTecnico) {
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Evalua Propuestas T�cnicas");
				menuItem.put("icon", "sap-icon://order-status");
				menuItem.put("targetPage", "EvaluaPropuestasTecnicas");
//				menuItem.put("description", "Evalua Propuestas T�cnicas");
				menu.add(menuItem);
			}
			if(bu.liberaPE) {
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Comit� de Apertura Econ�mica");
				menuItem.put("icon", "sap-icon://payment-approval");
				menuItem.put("targetPage", "AperturaEconomica");
//				menuItem.put("description", "Junta de Comit�");
				menu.add(menuItem);
			}
			if(bu.abastecimientos || bu.comite || bu.evalTecnico || bu.directorGeneral) {
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Aprobaci�n de Evaluaci�n");
				menuItem.put("icon", "sap-icon://employee-approvals");
				menuItem.put("targetPage", "AprobacionEvaluacion");
				menu.add(menuItem);
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Aprobaci�n de Resultados");
				menuItem.put("icon", "sap-icon://approvals");
				menuItem.put("targetPage", "Aprobacion");
				menu.add(menuItem);
			}
//			if(!bu.evalTecnico) { // Evaluadores no tienen acceso a consulta 20170116 RR solicita que todos los usuarios tengan consulta
				menuItem = new HashMap<String, String>(); 
				menuItem.put("title", "Consulta Licitaciones");
				menuItem.put("icon", "sap-icon://search");
				menuItem.put("targetPage", "ConsultaLicitaciones");
	//			menuItem.put("description", "Consulta Licitaciones");
				menu.add(menuItem);
//			}
		}

		// PROVEEDORES
		BeanProveedor bp = (BeanProveedor) sessionMap.get("proveedor");
		if(bp != null) {
			menuItem = new HashMap<String, String>(); 
			menuItem.put("title", "Enviar Propuesta");
			menuItem.put("icon", "sap-icon://action");
			menuItem.put("targetPage", "EnvioPropuesta");
//			menuItem.put("description", "Enviar Propuesta");
			menu.add(menuItem);
		}

		menuItem = new HashMap<String, String>(); 
		menuItem.put("title", "Acerca De");
		menuItem.put("icon", "sap-icon://sys-help");
		menuItem.put("targetPage", "Info");
//		menuItem.put("description", "Mas Informaci�n");
		menu.add(menuItem);

		return Action.SUCCESS;
    }

	public List<Map> getMenu() {
		return menu;
	}

	@Override  
	public void setSession(Map<String, Object> map) {  
	    sessionMap=(SessionMap)map;  
	}  

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	
}
