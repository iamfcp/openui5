package com.indelpro.action;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.indelpro.model.BeanLicitacion;
import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.indelpro.model.dao.DAOLicitacion;
import com.indelpro.model.dao.DAOProveedor;
import com.indelpro.model.dao.DAOUsuario;
import com.indelpro.security.Util;
import com.indelpro.util.Email;
import com.indelpro.util.LDAPUtil;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport implements ServletResponseAware, SessionAware {
	private String username;
	private String password;
	private String licitacion;
	private boolean login;
	
	private HttpServletResponse response;
	private SessionMap<String,Object> sessionMap; 
	

	
	public String execute() throws IOException {
		DAOUsuario dao = new DAOUsuario();
		BeanUsuario bu = dao.obtenUsuario(username);

		if (bu == null || password == null || password.length() == 0
				|| (!bu.validaPassword(password) && !LDAPUtil.validaLDAP(username, password))) {
			response.sendError(401);
			login = false;
			return Action.ERROR;
		} else {
			sessionMap.put("usuario", bu);
			login = true;
			return Action.SUCCESS;
		}
	}

	public String revisaSesion() throws IOException {
		login = sessionMap.get("proveedor") != null || sessionMap.get("usuario") != null;
		if(!login) {
			response.sendError(401);
			return Action.ERROR;
		} else
			return Action.SUCCESS;
	}

	public String loginProveedor() throws IOException {
		sessionMap.clear();
		DAOLicitacion dl = new DAOLicitacion();
		
		BeanLicitacion l = dl.obtiene(licitacion, false); // Obtiene el registro mas reciente por proovedor
		if(l == null) {
			response.sendError(401);
			return Action.NONE;
		}
		System.err.println("login "+username+" "+password);
		for (HashMap mp : l.listaProveedores) {
			String rfc = (String) mp.get("rfc");
			String clave = (String) mp.get("clave");
			System.err.println("login "+rfc+" "+clave+" "+mp.get("ACTIVO"));
			if(rfc != null && rfc.equals(username))
				if(clave.equals(password) && (boolean)mp.get("ACTIVO")) {
					BeanProveedor bp = new BeanProveedor();
					try {
						BeanUtils.populate(bp, mp);
						sessionMap.put("proveedor", bp);
						sessionMap.put("licitacion", l);
						sessionMap.put("ID", mp.get("ID"));
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else
					response.sendError(401);
			else 
				mp.clear();
		}

		return Action.SUCCESS;
	}

	public String resetPass() throws IOException {
		DAOUsuario dao = new DAOUsuario();
		BeanUsuario bu = dao.obtenUsuario(username);
		
		if(bu != null) {
			SecureRandom r = new SecureRandom();
			byte[] salt = new byte[32];
			r.nextBytes(salt);
			String encodedSalt = Util.bytesToHex(salt); 
			String newPass = Util.generaPassword();
			String newHash = Util.getSHA256Hash(newPass + encodedSalt);
			bu.hash = newHash;
			bu.salt = encodedSalt;
			String claveLiberacion = Util.generaPassword();
			newHash = Util.getSHA256Hash(claveLiberacion + encodedSalt);
			bu.hashl = newHash;
			dao.actualizarCompleto(bu);
			
			String htmlMessage = 
					"<html><body>"
					+ "<p>Se le han asignado nuevas claves para el Portal de Licitaciones"
					+ "<UL>"
					+ "<LI>Usuario: <b>" + bu.usuario + "</b>"
					+ "<LI>Clave de Acceso: <b>" + newPass + "</b>"
					+ "<LI>Clave de Liberaci�n: <b>" + claveLiberacion + "</b>"
					+ "</UL>"
					+ "<p> "
					+ "</body></html>";
			System.out.println(htmlMessage);
			Email.enviarCorreo(ServletActionContext.getRequest().getContextPath(),
					bu.correo, "Acceso al Portal de Licitaciones Indelpro", htmlMessage, null, null); 
		}
		
		return Action.SUCCESS;
	}

	public String logout() throws IOException {
		sessionMap.invalidate();
		return Action.SUCCESS;
	}

	@Override  
	public void setSession(Map<String, Object> map) {  
	    sessionMap=(SessionMap)map;  
	}  

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	public HttpServletResponse getServletResponse() {
		return this.response;
	}

	public String getLicitacion() {
		return licitacion;
	}

	public void setLicitacion(String licitacion) {
		this.licitacion = licitacion;
	}

	public boolean getLogin() {
		return login;
	}

	public void setLogin(boolean login) {
		this.login = login;
	}	
}