package com.indelpro.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.indelpro.model.dao.DAOProveedor;
import com.opensymphony.xwork2.Action;

public class ProveedorAction implements SessionAware{
	private List<Map> proveedores = new ArrayList<Map>();
	
	private SessionMap<String,Object> sessionMap; 

	public int 	  codigo              ;
	public String mensaje             ;
	
	private String numeroSAP ;
	private String rfc       ;
	private String nombre    ;
	private String correo    ;
	private String notas     ;
	
	public String execute() {
		return Action.SUCCESS;
    }
	
	public String lista() {
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		if(bu != null) {
			DAOProveedor dao = new DAOProveedor();
			proveedores = dao.listaProveedores();
		} else {
			codigo = 401;
			mensaje = "Sesi�n Inv�lida";
		}
		return Action.SUCCESS;
    }

	public String crea() {
		System.err.println("crear");
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		if(bu != null) {
			BeanProveedor bean = new BeanProveedor();
			try {
				BeanUtils.copyProperties(bean, this);
				if(bean.numeroSAP == null || bean.numeroSAP.length() < 5) {
					codigo = 500;
					mensaje = "N�mero SAP muy corto";
				}
				if(bean.rfc == null || bean.rfc.length() < 9) {
					codigo = 500;
					mensaje = "RFC muy corto";
				}
				DAOProveedor dao = new DAOProveedor();
				if(dao.crear(bean) == 1) {
					codigo = 200;
					mensaje = "OK";
				} else if(dao.crear(bean) == -5) {
					codigo = 500;
					mensaje = "Ya existe un proveedor con ese N�mero SAP/RFC";
				} else {
					codigo = 500;
					mensaje = "Error al insertar ";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			codigo = 401;
			mensaje = "Sesi�n Inv�lida";
		}
		return Action.SUCCESS;
    }

	public String actualiza() {
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		if(bu != null) {
			BeanProveedor bean = new BeanProveedor();
			try {
				BeanUtils.copyProperties(bean, this);
				DAOProveedor dao = new DAOProveedor();
				boolean ok = dao.actualizar(bean) == 1;
				if(ok) {
					codigo = 200;
					mensaje = "OK";
				} else {
					codigo = 500;
					mensaje = "Error al actualizar ";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			codigo = 401;
			mensaje = "Sesi�n Inv�lida";
		}
		return Action.SUCCESS;
	}

	@Override  
	public void setSession(Map<String, Object> map) {  
	    sessionMap=(SessionMap)map;  
	}  
	
	public List<Map> getProveedores() {
		return proveedores;
	}


	public int getCodigo() {
		return codigo;
	}


	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}


	public String getMensaje() {
		return mensaje;
	}


	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}


	public String getNumeroSAP() {
		return numeroSAP;
	}


	public void setNumeroSAP(String numeroSAP) {
		this.numeroSAP = numeroSAP;
	}


	public String getRfc() {
		return rfc;
	}


	public void setRfc(String rfc) {
		this.rfc = rfc;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}


	public String getNotas() {
		return notas;
	}


	public void setNotas(String notas) {
		this.notas = notas;
	}

	
}
