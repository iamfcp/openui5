package com.indelpro.action;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.indelpro.model.BeanUsuario;
import com.indelpro.model.dao.DAOUsuario;
import com.opensymphony.xwork2.Action;

public class UsuarioAction  {
	private List<Map> usuarios = new ArrayList<Map>();
	public String usuario             ;
	public String jefe                ;
	public String nombre              ; 
	public String departamento        ; 
	public String correo              ; 
	public Boolean activo             ;
	public Boolean liberaPT           ;
	public Boolean liberaPE           ;
	public Boolean comite             ;
	public Boolean abastecimientos    ;
	public Boolean evalTecnico        ;
	public Boolean directorGeneral    ;

	public int 	  codigo              ;
	public String mensaje             ;

	public String execute() {
		// TODO Rol session
		return Action.SUCCESS;
    }

	
	public String lista() {
		// TODO Rol session
		DAOUsuario dao = new DAOUsuario();
		usuarios = dao.lista();

		return Action.SUCCESS;
    }
	
	public String listaEvalTec() {
		usuarios.clear();
		DAOUsuario dao = new DAOUsuario();
		List<Map> usuariosTmp = dao.lista();
		
		for (Iterator iterator = usuariosTmp.iterator(); iterator.hasNext();) {
			Map map = (Map) iterator.next();
			if((Boolean)map.get("evalTecnico"))
				usuarios.add(map);
		}

		return Action.SUCCESS;
    }
	

	public String actualizaUsuario() {
		BeanUsuario bu = new BeanUsuario();
		try {
			BeanUtils.copyProperties(bu, this);
			DAOUsuario dao = new DAOUsuario();
			boolean ok = dao.actualizar(bu) == 1;
			if(ok) {
				codigo = 200;
				mensaje = "OK";
			} else {
				codigo = 500;
				mensaje = "Error al insertar usuario";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
    }

	public String crear() {
		BeanUsuario bu = new BeanUsuario();
		try {
			BeanUtils.copyProperties(bu, this);
			DAOUsuario dao = new DAOUsuario();
			boolean ok = dao.insertaUsuario(bu) == 1;
			if(ok) {
				codigo = 200;
				mensaje = "OK";
			} else {
				codigo = 500;
				mensaje = "Error al insertar usuario";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
    }
	
	public List<Map> getUsuarios() {
		return usuarios;
	}

	public String getUsuario() {
		return usuario;
	}


	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getDepartamento() {
		return departamento;
	}


	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}


	public Boolean getActivo() {
		return activo;
	}


	public void setActivo(Boolean activo) {
		this.activo = activo;
	}


	public Boolean getLiberaPT() {
		return liberaPT;
	}


	public void setLiberaPT(Boolean liberaPT) {
		this.liberaPT = liberaPT;
	}


	public Boolean getLiberaPE() {
		return liberaPE;
	}


	public void setLiberaPE(Boolean liberaPE) {
		this.liberaPE = liberaPE;
	}


	public Boolean getComite() {
		return comite;
	}


	public void setComite(Boolean comite) {
		this.comite = comite;
	}


	public Boolean getAbastecimientos() {
		return abastecimientos;
	}


	public void setAbastecimientos(Boolean abastecimientos) {
		this.abastecimientos = abastecimientos;
	}


	public Boolean getEvalTecnico() {
		return evalTecnico;
	}


	public void setEvalTecnico(Boolean evalTecnico) {
		this.evalTecnico = evalTecnico;
	}


	public void setUsuarios(List<Map> usuarios) {
		this.usuarios = usuarios;
	}


	public String getMensaje() {
		return mensaje;
	}


	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}


	public int getCodigo() {
		return codigo;
	}


	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}


	public Boolean getDirectorGeneral() {
		return directorGeneral;
	}


	public void setDirectorGeneral(Boolean directorGeneral) {
		this.directorGeneral = directorGeneral;
	}


	public String getJefe() {
		return jefe;
	}


	public void setJefe(String jefe) {
		this.jefe = jefe;
	}

	
}
