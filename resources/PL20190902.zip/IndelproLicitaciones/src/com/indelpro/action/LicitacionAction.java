package com.indelpro.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanMap;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import com.indelpro.model.BeanLicitacion;
import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.indelpro.model.dao.DAOLicitacion;
import com.indelpro.model.dao.DAOUsuario;
import com.indelpro.security.Util;
import com.indelpro.util.Email;
import com.indelpro.util.LDAPUtil;
import com.indelpro.util.PDFUtil;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LicitacionAction extends ActionSupport 
	implements ServletResponseAware, SessionAware, ServletContextAware {
	private Map data = new HashMap();
	private List<Map> licitaciones = new ArrayList<Map>();
	private SessionMap<String,Object> sessionMap; 
	private ServletContext servletContext;
	private HttpServletResponse response;

	public int 	  codigo              ;
	public String mensaje             ;
	
	public int 	  estatus             ;
	public BeanUsuario beanUsuario	  ;

	private static final SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
	private static final SimpleDateFormat dfTradicional = new SimpleDateFormat("dd / MM / yyyy");

	private String contextPath = ServletActionContext.getRequest().getContextPath();
	
	public String execute() {
		return Action.SUCCESS;
    }

	public String enviaInvitaciones() {
		DAOLicitacion dao = new DAOLicitacion();
		BeanUsuario bu = validaSesion();
		if(bu == null)
			return Action.NONE;
		BeanLicitacion bl = dao.obtiene((String)data.get("numeroLicitacion"));
		ArrayList lp = bl.listaProveedores;
		if(servletContext == null) 
			servletContext = ServletActionContext.getServletContext();
		String rutaArchivos = servletContext.getInitParameter("rutaArchivos");
		for (Iterator iterator = lp.iterator(); iterator.hasNext();) {
			HashMap map = (HashMap) iterator.next();
			try {
				String htmlMessage = 
						Email.mensajeEnvio(bl, (String)map.get("rfc"), (String)map.get("clave"), contextPath);
				System.out.println("Invitacion " + bl.numeroLicitacion + " " + map.get("rfc") + " " + map.get("clave") + " " + map.get("correo"));
				HashMap<String, String> archivos = new HashMap<>();
				archivos.put(bl.idArchivoBases, bl.nombreArchivoBases);
				archivos.put(bl.idArchivoEvaluacion, bl.nombreArchivoEvaluacion);
				for(HashMap archivoAdicional: bl.listaArchivosAdicionales)
					archivos.put((String) archivoAdicional.get("id"), (String) archivoAdicional.get("nombre"));
				Email.enviarCorreo(contextPath, 
						(String)map.get("correo"), // TODO Parsear varios correos
						"Invitaci�n a participar en Licitaci�n Indelpro / Invitation to Bid", 
						htmlMessage,
						rutaArchivos,
						null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		dao.cambiaEstatus(bl.numeroLicitacion, DAOLicitacion.ENVIADA);
		dao.log(bl.numeroLicitacion, bu.usuario, DAOLicitacion.ENVIADA, "Enviar Invitaciones", "enviaInvitaciones");
		setCodigo(200);
		setMensaje("OK");
		return Action.SUCCESS;
    }
	
	public String eliminaProveedores() {
		DAOLicitacion dao = new DAOLicitacion();
		BeanUsuario bu = validaSesion();
		if(bu == null)
			return Action.NONE;
		BeanLicitacion bl = dao.obtiene((String)data.get("numeroLicitacion"));
		ArrayList lp = (ArrayList) data.get("listaProveedoresBorrar");
		if(servletContext == null) 
			servletContext = ServletActionContext.getServletContext();
		String rutaArchivos = servletContext.getInitParameter("rutaArchivos");
		dao.eliminaProveedores(bl, lp);
		dao.log(bl.numeroLicitacion, bu.usuario, bl.estatus, "Elimina Proveedores", lp.toString());
		setCodigo(200);
		setMensaje("OK");
		return Action.SUCCESS;
    }

	public String agregaProveedores() {
		DAOLicitacion dao = new DAOLicitacion();
		BeanUsuario bu = validaSesion();
		if(bu == null)
			return Action.NONE;
		BeanLicitacion bl = dao.obtiene((String)data.get("numeroLicitacion"));
		ArrayList lp = (ArrayList) data.get("listaProveedoresAdicionales");
		if(servletContext == null) 
			servletContext = ServletActionContext.getServletContext();
		String rutaArchivos = servletContext.getInitParameter("rutaArchivos");
		for (Iterator iterator = lp.iterator(); iterator.hasNext();) {
			HashMap map = (HashMap) iterator.next();
			try {
				map.put("clave", Util.generaPassword());
				String htmlMessage = 
						Email.mensajeEnvio(bl, (String)map.get("rfc"), (String)map.get("clave"), contextPath);
				System.out.println("Invitacion " + bl.numeroLicitacion + " " + map.get("rfc") + " " + map.get("clave") + " " + map.get("correo"));
				HashMap<String, String> archivos = new HashMap<>();
				archivos.put(bl.idArchivoBases, bl.nombreArchivoBases);
				archivos.put(bl.idArchivoEvaluacion, bl.nombreArchivoEvaluacion);
				for(HashMap archivoAdicional: bl.listaArchivosAdicionales)
					archivos.put((String) archivoAdicional.get("id"), (String) archivoAdicional.get("nombre"));
				Email.enviarCorreo(contextPath, 
						(String)map.get("correo"), // TODO Parsear varios correos
						"Invitaci�n a participar en Licitaci�n Indelpro / Invitation to Bid", 
						htmlMessage, 
						rutaArchivos,
						null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		bl.setEstatus(DAOLicitacion.ENVIADA);
		dao.actualiza(bl);
		dao.agregaProveedores(bl, lp);
		dao.log(bl.numeroLicitacion, bu.usuario, bl.estatus, "Agrega Proveedores", lp.toString());
		setCodigo(200);
		setMensaje("OK");
		return Action.SUCCESS;
    }

	public String guardar() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		Logger logger = Logger.getLogger(LicitacionAction.class.getName());
		logger.log(Level.FINE, "action parameters: " + data);
		BeanLicitacion bean = new BeanLicitacion();
		bean.numeroLicitacion		 = (String)data.get("numeroLicitacion");
		bean.descripcion			 = (String)data.get("descripcion");
		bean.fechaLimite             = (String)data.get("fechaLimite");
		bean.responsable             = (String)data.get("responsable");
		bean.elementoPEP             = (String)data.get("elementoPEP");
		bean.nombreArchivoBases      = (String)data.get("nombreArchivoBases");
		bean.nombreArchivoEvaluacion = (String)data.get("nombreArchivoEvaluacion");
		bean.idArchivoBases          = (String)data.get("idArchivoBases");
		bean.idArchivoEvaluacion     = (String)data.get("idArchivoEvaluacion");
		bean.importeEstimado         = Double.parseDouble(data.get("importeEstimado")+"");
		bean.tipo                    = Integer.parseInt((String)data.get("tipo"));
		bean.creador				 = bu.usuario;
		
		bean.lConceptosEvaluacion    = (ArrayList) data.get("lConceptosEvaluacion");
		bean.listaProveedores        = (ArrayList) data.get("listaProveedores");

		bean.moneda                  = (String)data.get("moneda");
		bean.nombreArchivoPresupuesto= (String)data.get("nombreArchivoPresupuesto");
		bean.idArchivoPresupuesto    = (String)data.get("idArchivoPresupuesto");
		bean.fechaVisitaObra         = (String)data.get("fechaVisitaObra");
		bean.listaArchivosAdicionales= (ArrayList) data.get("listaArchivosAdicionales"); 
		
		boolean nueva = (boolean) data.get("esNueva");
		DAOLicitacion dao = new DAOLicitacion();
		int ok = dao.crea(bean, nueva);
		if(ok == -5) {
			setCodigo(500);
			setMensaje("Ya existe una licitaci�n con esa clave.");
		} else if(ok < 0) {
			setCodigo(500);
			setMensaje("Ocurri� un error al guardar la licitaci�n");
			dao.log(bean.numeroLicitacion, bu.usuario, DAOLicitacion.NUEVA, "ERROR", "guardar: estatus:" + getCodigo() + getMensaje() + " DATA "+ data);
		} else {
			setCodigo(200);
			setMensaje("OK");
			String msgCreacion = Email.mensajeBase(bean, "Se le informa que se ha creado la licitaci�n:", "", false, contextPath);
			Email.enviarCorreo(contextPath, bu.correo, "Confirmaci�n de creaci�n de Licitaci�n", msgCreacion, null, null);
			dao.log(bean.numeroLicitacion, bu.usuario, DAOLicitacion.NUEVA, "Guardar", "guardar: estatus:" + getCodigo() + getMensaje() + " DATA "+ data);
		}
		return Action.SUCCESS;
    }

	public String actualizaPonderacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		Logger logger = Logger.getLogger(LicitacionAction.class.getName());
		logger.log(Level.FINE, "action parameters: " + data);
		String numeroLicitacion		   = (String)data.get("numeroLicitacion");
		ArrayList lConceptosEvaluacion = (ArrayList) data.get("lConceptosEvaluacion");
		
		DAOLicitacion dao = new DAOLicitacion();
		int ok = dao.actualizaPonderacion(numeroLicitacion, lConceptosEvaluacion);
		if(ok < 0) {
			setCodigo(500);
			setMensaje("Ocurri� un error al actualizar datos");
			dao.log(numeroLicitacion, bu.usuario, DAOLicitacion.PT_LIBERADA, "ERROR", "actualizaPonderacion: estatus:" + getCodigo() + getMensaje() + " DATA "+ data);
		} else {
			setCodigo(200);
			setMensaje("OK");
			dao.log(numeroLicitacion, bu.usuario, DAOLicitacion.PT_LIBERADA, "Actualizar Ponderaci�n", "actualizaPonderacion: estatus:" + getCodigo() + getMensaje() + " DATA "+ data);
		}
		return Action.SUCCESS;
    }


	public String guardaResultadosEvaluacion() {
		String numeroLicitacion		 = (String)data.get("numeroLicitacion");
		ArrayList lResultadosEvaluacion = (ArrayList) data.get("lResultadosEvaluacion");
		String idArchivoResultados		 = (String)data.get("idArchivoResultados");
		String nombreArchivoResultados		 = (String)data.get("nombreArchivoResultados");
		
		DAOLicitacion dao = new DAOLicitacion();
		int ok = dao.guardaResultadosEvaluacion(numeroLicitacion, lResultadosEvaluacion);
		BeanLicitacion l = dao.obtiene(numeroLicitacion);
		if(idArchivoResultados != null && nombreArchivoResultados != null) {
			l.idArchivoResultados = idArchivoResultados;
			l.nombreArchivoResultados = nombreArchivoResultados;
			dao.actualiza(l);
		}
		
		if(ok < 0) {
			setCodigo(500);
			setMensaje("Ocurri� un error al guardar");
		} else {
			setCodigo(200);
			setMensaje("OK");
		}
		return Action.SUCCESS;
    }
	
	public String apruebaEvaluacionLicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String numeroLicitacion		 = (String)data.get("numeroLicitacion");
		Boolean autoriza		 = (Boolean)data.get("autoriza");
		String mensaje		 = (String)data.get("mensaje");
		String password		 = (String)data.get("password");
		
		DAOLicitacion dao = new DAOLicitacion();
		if(bu == null || password == null || password.length() == 0
				|| (!bu.validaPassword(password) && !LDAPUtil.validaLDAP(bu.usuario, password))) {
			setCodigo(500);
			setMensaje("La contrase�a es incorrecta.");
		} else {
			if(autoriza != null && autoriza) {
				data.put("estatus", new Integer(DAOLicitacion.EVALUDADA));
				cambiaEstatus(true);
				setCodigo(200);
				setMensaje("Se ha guardado su autorizaci�n.");
			} else {
				DAOUsuario daou = new DAOUsuario();
				dao.cambiaEstatus(numeroLicitacion, DAOLicitacion.PT_LIBERADA);
				BeanLicitacion l = dao.obtiene(numeroLicitacion);
				setCodigo(200);
				setMensaje("Se ha informado al responsable del rechazo.");
				String mensajeCorreo = Email.mensajeBase(l, "La evaluaci�n de esta licitacion no fue aceptada, favor de revisar.", mensaje, false, null);
				Email.enviarCorreo(contextPath, 
						daou.obtenUsuario(l.responsable).correo, 
						"Evaluaci�n Rechazada", 
						mensajeCorreo, null, null);	
			}
		}


		return Action.SUCCESS;
	}
	
	public String apruebaLicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String numeroLicitacion		 = (String)data.get("numeroLicitacion");
		Boolean autoriza		 = (Boolean)data.get("autoriza");
		String mensaje		 = (String)data.get("mensaje");
		
		System.out.println("apruebaLicitacion: " + (new Date()) + " " + numeroLicitacion + " " + autoriza + " " + mensaje);

		DAOLicitacion dao = new DAOLicitacion();
		int ok = dao.guardaAprobacion(numeroLicitacion, bu.usuario, autoriza, mensaje);
		dao.log(numeroLicitacion, bu.usuario, DAOLicitacion.ESPERA_APROBACION, "Aprueba: " + (autoriza?"SI":"NO"), "Mensaje:" + mensaje);
		if(ok < 0) {
			setCodigo(500);
			setMensaje("Ocurri� un error al guardar");
		} else {
			setCodigo(200);
			setMensaje("OK");
		}
		
		// Revisa si aprob� todo el comit�
		boolean aprobada = true; // dao.licitacionAprobada(numeroLicitacion);
		BeanLicitacion l = dao.obtiene(numeroLicitacion);
		boolean comiteAprueba = true;
		BeanUsuario u;
		DAOUsuario daou = new DAOUsuario();
		String dg = null;
		for(HashMap aprobaciones: l.lAprobaciones) {
			u = daou.obtenUsuario((String) aprobaciones.get("responsable"));
			aprobada &= (boolean)aprobaciones.get("aprueba");
			if(u.directorGeneral)
				dg = u.correo;
			else
				comiteAprueba &= (boolean)aprobaciones.get("aprueba");
		}
		
		if(comiteAprueba && !aprobada && dg != null) { // Mail para el Gerente de Abastecimientos (Director General)
			String mensajeCorreo = l.proveedorReasignado != null 
					? Email.mensajeBase(l, "La siguiente licitaci�n ha sido reasignada",
							"Favor de proceder con la aprobaci�n de la licitaci�n para continuar con el proceso.<br>Mensaje de justificaci�n: "
									+ l.mensajeReasignacion,
							false, contextPath)
					: Email.mensajeBase(l,
							"Las propuestas t�cnicas y econ�micas de la siguiente licitaci�n han sido aprobadas por el comit�.",
							"Se requiere de su aprobaci�n para continuar con el proceso.",
							false, contextPath);
			Email.enviarCorreo(contextPath, 
					dg, 
					"Licitaci�n lista para aprobaci�n", 
					mensajeCorreo, null, null);			
		}
		
		System.out.println("apruebaLicitacion: " + (new Date()) + " " + l.numeroLicitacion + " " + aprobada);
		if(aprobada) {
			u = daou.obtenUsuario(l.creador);
			if(servletContext == null) 
				servletContext = ServletActionContext.getServletContext();
			String rutaArchivos = servletContext.getInitParameter("rutaArchivos");
		        
	        l.estatus = l.proveedorReasignado != null?DAOLicitacion.REASIGNADA:DAOLicitacion.CONCLUIDA;
	        l.idArchivoActaResultados = PDFUtil.generaActaResultados(l, rutaArchivos);
	        dao.actualiza(l);
            
			HashMap<String, String> archivos = new HashMap<>();
			archivos.put(l.idArchivoActaResultados, l.idArchivoActaResultados);
			String mensajeCorreo = Email.mensajeBase(l, 
					"Las propuestas t�cnicas y econ�micas de la siguiente licitaci�n han sido evaluadas y aprobadas", 
					"Se adjunta acta de resultados. Favor de proceder con el proceso de compras.", false, contextPath);
			Email.enviarCorreo(contextPath, u.correo, "Licitaci�n Concluida", mensajeCorreo, rutaArchivos, archivos);
			dao.log(l.numeroLicitacion, bu.usuario,
					l.estatus,
					"Licitaci�n Concluida", "Data: " + data);
		}
		return Action.SUCCESS;
    }
	
	public String apruebaEvalTec() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String numeroLicitacion	= (String)data.get("numeroLicitacion");
		boolean aprueba = ((boolean) data.get("aprueba"));
				
		DAOLicitacion dao = new DAOLicitacion();
		int ok;
		if(aprueba) {
			ok = dao.cambiaEstatus(numeroLicitacion, DAOLicitacion.EVALUDADA);
			dao.log(numeroLicitacion, bu.usuario, estatus, 
					"Aprueba Evaluaci�n T�cnica: " + DAOLicitacion.DESCRIPCION_ESTATUS[estatus], "cambiaEstatus");
			BeanLicitacion l = dao.obtiene(numeroLicitacion);
			String mensajeCorreo = Email.mensajeBase(l, 
					"Las propuestas t�cnicas de la siguiente licitaci�n han sido evaluadas.", 
					"", false, contextPath);
			Email.mensajeAlComite(contextPath, "Fase de Evaluaci�n Completa", mensajeCorreo, l);			
		} else {
			ok = dao.cambiaEstatus(numeroLicitacion, DAOLicitacion.PT_LIBERADA);
			dao.log(numeroLicitacion, bu.usuario, estatus, 
					"Rechaza Evaluaci�n T�cnica: " + DAOLicitacion.DESCRIPCION_ESTATUS[estatus], "cambiaEstatus");
			BeanLicitacion l = dao.obtiene(numeroLicitacion);
			String mensajeCorreo = Email.mensajeBase(l, 
					"La evaluaci�n t�cnica ha sido rechazada.", 
					"", false, contextPath);
			DAOUsuario daou = new DAOUsuario();
			BeanUsuario usuarioResponsable = daou.obtenUsuario(l.responsable);
			Email.enviarCorreo(contextPath, usuarioResponsable.correo, 
					"Evaluaci�n Rechazada", mensajeCorreo, null, null);
		}
				
		if(ok < 0) {
			setCodigo(500);
			setMensaje("Ocurri� un error al guardar");
		} else {
			setCodigo(200);
			setMensaje("OK");
		}
		return Action.SUCCESS;
    }

	public String cambiaEstatus() {
		return cambiaEstatus(false);
	}
	
	public String cambiaEstatus(boolean desdeAprobacionEvaluacion) {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String numeroLicitacion	= (String)data.get("numeroLicitacion");
		int estatus = 1;
		try {
			estatus = ((Integer) data.get("estatus")).intValue();			
		} catch (Exception e) {
			estatus = ((Long) data.get("estatus")).intValue();			
		}
		DAOLicitacion dao = new DAOLicitacion();
		
		if(!desdeAprobacionEvaluacion && estatus == DAOLicitacion.EVALUDADA) {
			if(bu.jefe != null && bu.jefe.length() > 0) {
				estatus = DAOLicitacion.EN_APROBACION_EVAL;
				BeanLicitacion l = dao.obtiene(numeroLicitacion);
				String mensajeCorreo = Email.mensajeBase(l, 
						"Las propuestas t�cnicas de la siguiente licitaci�n han sido evaluadas. Favor de revisar y aprobar.", 
						"", false, contextPath);
				try {
					DAOUsuario daou = new DAOUsuario();
					BeanUsuario jefe = daou.obtenUsuario(bu.jefe);
					Email.enviarCorreo(contextPath, 
							jefe.correo,
							"Se solicita su aprobaci�n de la evaluaci�n", mensajeCorreo, null, null);
				} catch (Exception e) {
					e.printStackTrace();
				}			
			}
		}
		
		int ok = dao.cambiaEstatus(numeroLicitacion, (int)estatus);
		dao.log(numeroLicitacion, bu.usuario, estatus, "Cambia Estatus: " + DAOLicitacion.DESCRIPCION_ESTATUS[estatus], "cambiaEstatus");
		
		if(estatus == DAOLicitacion.EVALUDADA) {
			BeanLicitacion l = dao.obtiene(numeroLicitacion);
			String mensajeCorreo = Email.mensajeBase(l, 
					"Las propuestas t�cnicas de la siguiente licitaci�n han sido evaluadas.", 
//					"Favor de proceder con la programaci�n de la reuni�n para conocer los resultados y continuar con el proceso.", 
					"", false, contextPath);
//					"<html><body>"
//					+ "<p>Las propuestas t�cnicas de la licitaci�n " + l.numeroLicitacion
//					+ " \"" + l.descripcion + "\""
//					+ " han sido evaluadas."
//					+ "Favor de proceder con la programaci�n de la reuni�n para conocer los resultados y continuar con el proceso.";
//			boolean evaluacionesCompletas = true;
//			for(HashMap p: l.listaProveedores) 
//				evaluacionesCompletas &= (int) p.get("total") > 0;
//			if(evaluacionesCompletas)
			Email.mensajeAlComite(contextPath, "Fase de Evaluaci�n Completa", mensajeCorreo, l);			
		}
		if(ok < 0) {
			setCodigo(500);
			setMensaje("Ocurri� un error al guardar");
		} else {
			setCodigo(200);
			setMensaje("OK");
		}
		return Action.SUCCESS;
    }

	public String cambiaEstatusDirecto() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String numeroLicitacion	= (String)data.get("numeroLicitacion");
		int estatus = ((Long) data.get("estatus")).intValue();
		
		
		DAOLicitacion dao = new DAOLicitacion();
		int ok = dao.cambiaEstatus(numeroLicitacion, (int)estatus);
		dao.log(numeroLicitacion, bu.usuario, estatus, "Cambia Estatus: " + DAOLicitacion.DESCRIPCION_ESTATUS[estatus], "cambiaEstatus");
		
		if(ok < 0) {
			setCodigo(500);
			setMensaje("Ocurri� un error al guardar");
		} else {
			setCodigo(200);
			setMensaje("OK");
		}
		return Action.SUCCESS;
    }

	public String ampliaPlazoLicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String numeroLicitacion	= (String)data.get("numeroLicitacion");
		
		DAOLicitacion dao = new DAOLicitacion();
		BeanLicitacion l = dao.obtiene(numeroLicitacion);
		l.estatus = DAOLicitacion.ENVIADA; // Solicitado por RR IB 20170424
		l.fechaLimite = (String)data.get("fechaLimite");
		dao.actualiza(l);
		data = new BeanMap(l);
		
		setCodigo(200);
		setMensaje("OK");
		
		String mensaje = Email.mensajeBase(l, 
				"Se le informa que la fecha l�mite de la siguiente licitaci�n ha cambiado", 
				"", false, contextPath);
		Email.mensajeAlComite(contextPath, "Cambio de Fecha L�mite", mensaje, l);
		try {
			dao.log(l.numeroLicitacion, bu.usuario, l.estatus, "Amplia plazo " + l.fechaLimite, "Data: " + data);
		} catch (Exception e) {e.printStackTrace();}

		return Action.SUCCESS;
    }

	public String listaLicitaciones() {
		BeanUsuario bu = validaSesion();

		data = new HashMap<>();
		data.put("usuario", bu.usuario);

		DAOLicitacion dao = new DAOLicitacion();
		List<BeanLicitacion> l = dao.lista(-1);
		licitaciones = new ArrayList<Map>();
		for (Iterator iterator = l.iterator(); iterator.hasNext();) {
			BeanLicitacion bl = (BeanLicitacion) iterator.next();
			BeanMap bml = new BeanMap(bl);
			if (estatus == DAOLicitacion.VENCIO_PLAZO) {
				if (bl.estatus < DAOLicitacion.ENVIADA || bl.estatus > DAOLicitacion.VENCIO_PLAZO)
					continue;
			} else if (estatus == DAOLicitacion.PT_LIBERADA) {
				if (bl.estatus < DAOLicitacion.ENVIADA || bl.estatus > DAOLicitacion.PT_LIBERADA)
					continue;				
			} else if (bl.estatus != estatus) 
				continue;
			boolean debeAprobar = false;
			if(estatus == 6)
				for(HashMap a: bl.lAprobaciones)
					if(a.get("responsable") != null && a.get("responsable").equals(bu.usuario))
						debeAprobar = !Boolean.parseBoolean(a.get("enviada").toString());
			if(estatus == 10) {
				DAOUsuario du = new DAOUsuario();
				if(bl.responsable != null) {
					BeanUsuario resp = du.obtenUsuario(bl.responsable);
					debeAprobar = resp.jefe != null && resp.jefe.equals(bu.usuario);
				}
			}
			HashMap m = new HashMap<>();
			m.put("debeAprobar", debeAprobar);
			for(Iterator<String> i = bml.keyIterator(); i.hasNext();) {
				String key = i.next();
//				System.err.println(key + "; "+bml.get(key));
				m.put(key, bml.get(key));
			}
			licitaciones.add(m);
		}
		return Action.SUCCESS;
	}

	public String obtenLicitacion() {
		BeanUsuario bu = validaSesion();
		
		DAOLicitacion dao = new DAOLicitacion();
		BeanLicitacion l = dao.obtiene((String) data.get("numeroLicitacion"));
		data = new BeanMap(l);
		
		return Action.SUCCESS;
	}

	public String obtenLicitacionParaProveedor() {
		if(sessionMap == null)
			sessionMap = (SessionMap<String, Object>) ActionContext.getContext().getSession();
		
		BeanLicitacion l = (BeanLicitacion) sessionMap.get("licitacion");
		BeanProveedor p = (BeanProveedor) sessionMap.get("proveedor");
		int id = (int) sessionMap.get("ID");
		l.lConceptosEvaluacion.clear();
		l.lResultadosEvaluacion.clear();
		l.lAprobaciones.clear();
		l.idArchivoPresupuesto = "";
		l.idArchivoResultados = "";
		l.importeEstimado = 0;
		l.lMovimientos.clear();
		l.mensajeAdjudicacion = "";
		l.proveedorGanador = "";
		if(p == null) {
			setCodigo(500);
			setMensaje("Su sesi�n caduc�");
			return Action.SUCCESS;
		}
		
		BeanMap bm = new BeanMap(l);
		data = new HashMap(bm);
		data.put("nombreEmpresa", p.nombre);
		data.put("correo", p.correo);
		data.put("ID", id);
		Date fechaLimite = null;
		try {
			Calendar cal = GregorianCalendar.getInstance();
			cal.setTime(df.parse(l.fechaLimite));
			cal.set(Calendar.HOUR_OF_DAY, 23);
			cal.set(Calendar.MINUTE, 59);
			fechaLimite = cal.getTime();
		} catch (Exception e) {e.printStackTrace();}
		if(fechaLimite == null || fechaLimite.before(new Date()) || l.estatus != 1) {
			setCodigo(500);
			setMensaje("El plazo de env�o ha conclu�do.");
		} else
			setCodigo(200);
		System.out.println("Acceso proveedor: " + codigo + " " + new Date() + " " + l.numeroLicitacion + " " + p.numeroSAP + " " + fechaLimite + " " + l.fechaLimite);
		return Action.SUCCESS;
	}

	public String guardaPropuesta() {
		if(sessionMap == null)
			sessionMap = (SessionMap<String, Object>) ActionContext.getContext().getSession();
		BeanProveedor p = (BeanProveedor) sessionMap.get("proveedor"); 
		if(p == null) {
			setCodigo(500);
			setMensaje("Su sesi�n ha caducado.");
			return Action.SUCCESS;
		}
		DAOLicitacion dao = new DAOLicitacion();
		if(data.get("nombrePropuestaTecnica") == null || data.get("idPropuestaTecnica") == null || 
				((String)data.get("nombrePropuestaTecnica")).trim().equals("") || ((String)data.get("idPropuestaTecnica")).trim().equals("")) {
			setCodigo(500);
			setMensaje("No ha cargado el archivo de propuesta t�cnica");
			return Action.SUCCESS;
		}
		if(data.get("nombrePropuestaEconomica") == null || data.get("idPropuestaEconomica") == null || 
				((String)data.get("nombrePropuestaEconomica")).trim().equals("") || ((String)data.get("idPropuestaEconomica")).trim().equals("")) {
			setCodigo(500);
			setMensaje("No ha cargado el archivo de propuesta econ�mica");
			return Action.SUCCESS;
		}
		double importe = 0;
		try {
			importe = Double.parseDouble(data.get("importeEstimado")+"");
		} catch (Exception e) {
			setCodigo(500);
			setMensaje("El importe es incorrecto");
			return Action.SUCCESS;
		}
		dao.guardaPropuesta((String) data.get("numeroLicitacion"), ((Long)data.get("ID")).intValue(), 
				(String) data.get("nombrePropuestaTecnica"), (String) data.get("idPropuestaTecnica"),
				(String) data.get("nombrePropuestaEconomica"), (String) data.get("idPropuestaEconomica"),
				importe);
		setCodigo(200);
		setMensaje("OK");
		
		BeanLicitacion l = dao.obtiene((String) data.get("numeroLicitacion"));
		try {
			String mensaje = Email.mensajeBaseProveedor(l, "Su propuesta para la licitaci�n que a continuaci�n se describe ha sido recibida en el Portal de Licitaciones Indelpro. El proceso continuar� con la evaluaci�n de la informaci�n y posteriormente se notificar�n los resultados.", 
					"Agradecemos de antemano su participaci�n en este proceso de licitaci�n. Para cualquier duda o aclaraci�n favor de consultar al comprador.",
					contextPath);
			Email.enviarCorreo(contextPath, p.correo, "Confirmaci�n de Recepci�n de Propuesta", mensaje, null, null);
			mensaje = Email.mensajeBaseProveedor(l, "El proveedor " + p.numeroSAP + " - " + p.nombre + " ha enviado una propuesta para la siguiente licitaci�n.", "", contextPath);
			DAOUsuario du = new DAOUsuario();
			BeanUsuario bu = du.obtenUsuario(l.creador);
			Email.enviarCorreo(contextPath, bu.correo, "Confirmaci�n de Recepci�n de Propuesta", mensaje, null, null);
			Email.enviarCorreo(contextPath, "iblanco@indelpro.com", "Confirmaci�n de Recepci�n de Propuesta", mensaje, null, null);
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}

	public String asignaLicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;

		DAOLicitacion dao = new DAOLicitacion();
		BeanLicitacion l = dao.obtiene((String) data.get("numeroLicitacion"));
		l.proveedorGanador = (String) data.get("proveedorGanador");
		l.mensajeAdjudicacion = (String) data.get("mensajeAdjudicacion");
		l.estatus = DAOLicitacion.ESPERA_APROBACION;
		String proveedorPropuesto = (String) data.get("proveedorPropuesto");
		dao.actualiza(l);
		dao.guardaAprobaciones(
				l.numeroLicitacion, 
				l.descripcion, 
				l.creador, 
				l.responsable, 
				!l.proveedorGanador.equals(proveedorPropuesto),
				contextPath);
		dao.log(l.numeroLicitacion, bu.usuario, DAOLicitacion.ESPERA_APROBACION, "Asigna Ganador, Solicita Aprobaci�n", "Data: " + data);
//		dao.cambiaEstatus((String) data.get("numeroLicitacion"), DAOLicitacion.ESPERA_APROBACION);
		setCodigo(200);
		setMensaje("OK");

		return Action.SUCCESS;
	}


	public String reasignaLicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String rutaArchivos = servletContext.getInitParameter("rutaArchivos");
		
		DAOLicitacion dao = new DAOLicitacion();
		BeanLicitacion l = dao.obtiene((String) data.get("numeroLicitacion"));
		l.proveedorReasignado = l.proveedorGanador;
		l.proveedorGanador = (String) data.get("nuevoGanador");
		l.mensajeReasignacion = (String) data.get("mensajeReasignacion");
		l.estatus = DAOLicitacion.ESPERA_APROBACION;
//		l.idArchivoActaResultados = PDFUtil.generaActaResultados(l, rutaArchivos);
		dao.actualiza(l);
		
		dao.log(l.numeroLicitacion, bu.usuario, DAOLicitacion.REASIGNADA, "Reasigna Ganador: " + l.proveedorReasignado + " -> " + l.proveedorGanador, "Data: " + data);
		dao.guardaAprobaciones(
				l.numeroLicitacion, 
				l.descripcion, 
				l.creador, 
				l.responsable, 
				true,
				contextPath);

//		String mensajeCorreo = Email.mensajeBase(
//				l, "La siguiente licitaci�n ha sido reasignada", 
//				"Mensaje de justificaci�n: " + l.mensajeReasignacion, false);
//		Email.mensajeAlComite("Licitaci�n " + l.numeroLicitacion + " reasignada", mensajeCorreo);
		
		setCodigo(200);
		setMensaje("OK");
		data = new BeanMap(l);

		return Action.SUCCESS;
	}

	public String liberaPTLicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
//		boolean ok = bu.validaClaveLiberacion((String) data.get("claveLiberacion"));
		boolean ok =  bu.liberaPT && LDAPUtil.validaLDAP(bu.usuario, (String) data.get("claveLiberacion"));

		if(ok) {
			DAOLicitacion dao = new DAOLicitacion();
			BeanLicitacion l = dao.obtiene((String) data.get("numeroLicitacion"));
			l.liberadorPT = bu.usuario;
			l.fechaLiberacionPT = df.format(new Date());
			if(l.estatus == DAOLicitacion.VENCIO_PLAZO)
				l.estatus = DAOLicitacion.PT_LIBERADA;
			dao.actualiza(l);
			ArrayList listaProveedores = (ArrayList) data.get("listaProveedores");
			dao.liberaPropuestaEconomica(l.numeroLicitacion, listaProveedores);
//			DAOUsuario du = new DAOUsuario();
//			BeanUsuario u = du.obtenUsuario(l.responsable);
			String mensajeCorreo = Email.mensajeBase(
					l, "Las propuestas t�cnicas de la siguiente licitaci�n han sido liberadas para consulta", 
					"Favor de proceder con la evaluaci�n t�cnica de la informaci�n.", false, contextPath);
			Email.mensajeAlComite(contextPath, "Propuestas T�cnicas Liberadas", mensajeCorreo, l);
			dao.log(l.numeroLicitacion, bu.usuario, l.estatus, "Propuestas T�cnicas Liberada por " + bu.usuario, "Data: " + data);
			setCodigo(200);
			setMensaje("OK");
		} else {
			setCodigo(500);
			setMensaje("La clave de liberaci�n es incorrecta");
		}
		return Action.SUCCESS;
	}

	public String liberaPELicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;

		String liberador1 = (String) data.get("liberador1");
		String liberador2 = (String) data.get("liberador2");
		String claveLiberacion1 = (String) data.get("claveLiberacion1");
		String claveLiberacion2 = (String) data.get("claveLiberacion2");
		DAOUsuario daou = new DAOUsuario();
		
		boolean ok = true;
		bu = daou.obtenUsuario(liberador1);
//		ok = ok && bu != null && bu.liberaPE && bu.validaClaveLiberacion(claveLiberacion1); 
		ok = ok && bu != null && bu.liberaPE && LDAPUtil.validaLDAP(liberador1, claveLiberacion1); 
		bu = daou.obtenUsuario(liberador2);
//		ok = ok && bu != null && bu.liberaPE && bu.validaClaveLiberacion(claveLiberacion2); 
		ok = ok && bu != null && bu.liberaPE && LDAPUtil.validaLDAP(liberador2, claveLiberacion2); 
		ok = ok && !(liberador1.equals(liberador2));

		if(ok) {
			DAOLicitacion dao = new DAOLicitacion();
			BeanLicitacion l = dao.obtiene((String) data.get("numeroLicitacion"));
			l.liberadorPE1 = liberador1;
			l.liberadorPE2 = liberador2;
//			l.estatus = DAOLicitacion.PE_LIBERADA;
			l.fechaLiberacionPE = df.format(new Date());
			dao.actualiza(l);
//			ok = 1 == dao.cambiaEstatus((String) data.get("numeroLicitacion"), DAOLicitacion.PE_LIBERADA);
			setCodigo(200);
			setMensaje("OK");
			dao.log(l.numeroLicitacion, bu.usuario, l.estatus, "Propuesta Econ�mica Liberada por " + liberador1 + ", " + liberador2, "Data: " + data);
		} else {
			setCodigo(500);
			setMensaje("La clave de liberaci�n es incorrecta");
		}
		return Action.SUCCESS;
	}

	public String buscaLicitaciones() {
		BeanUsuario bu = validaSesion();
		String numLic = (String) data.get("numeroLicitacion");
		String elementoPEP = (String) data.get("elementoPEP");
		String desde = (String) data.get("desde");
		String hasta = (String) data.get("hasta");
		String comprador = (String) data.get("comprador");
		int estatus = -1;
		try {
			estatus = Integer.parseInt((String) data.get("estatus"));
		} catch (Exception e) {e.printStackTrace();}

		DAOLicitacion dao = new DAOLicitacion();
		List<BeanLicitacion> l = dao.lista(-1);
		licitaciones = new ArrayList<Map>();
		for (Iterator iterator = l.iterator(); iterator.hasNext();) {
			BeanLicitacion b = (BeanLicitacion) iterator.next();
			if(numLic != null && numLic.trim().length() > 0 && b.numeroLicitacion.toLowerCase().indexOf(numLic.toLowerCase()) == -1)
				continue;
			if(elementoPEP != null && elementoPEP.trim().length() > 0 && b.elementoPEP.indexOf(elementoPEP) == -1)
				continue;
			if(comprador != null && comprador.trim().length() > 0 && b.creador != null && b.creador.indexOf(comprador) == -1)
				continue;
			if(desde != null && desde.trim().length() > 0 && desde.compareTo(b.fechaLimite) > 0)
				continue;
			if(hasta != null && hasta.trim().length() > 0 && hasta.compareTo(b.fechaLimite) < 0)
				continue;
			if(estatus >= 0 && b.estatus != estatus)
				continue;
			
			BeanMap bml = new BeanMap(b);
			HashMap m = new HashMap<>();
			for(Iterator<String> i = bml.keyIterator(); i.hasNext();) {
				String key = i.next();
//				System.err.println(key + "; "+bml.get(key));
				m.put(key, bml.get(key));
			}
			licitaciones.add(m);
		}
		return Action.SUCCESS;
	}

	public String borraLicitacion() {
		BeanUsuario bu = validaSesion();
		if(bu == null) 
			return Action.SUCCESS;
		String numLic = (String) data.get("numeroLicitacion");

		DAOLicitacion dao = new DAOLicitacion();
		dao.borraLicitacion(numLic);
		dao.log(numLic, bu.usuario, 8, "Licitaci�n Borrada", "Data: " + data);

		return Action.SUCCESS;
	}


	public BeanUsuario validaSesion() {
		if(sessionMap == null)
			sessionMap = (SessionMap<String, Object>) ActionContext.getContext().getSession();
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		if(bu == null) {
			setCodigo(401);
			setMensaje("Su sesi�n ha caducado");
			return null;
		}
		beanUsuario = bu;
		if(servletContext == null) 
			servletContext = ServletActionContext.getServletContext();
		return bu;
	}

	@Override  
	public void setSession(Map<String, Object> map) {  
	    sessionMap=(SessionMap)map;  
	}  

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	@Override
    public void setServletContext(ServletContext context) {
        this.servletContext = context;
    }

	public Map getData() {
		return data;
	}

	public void setData(Map data) {
		this.data = data;
	}

	public List<Map> getLicitaciones() {
		return licitaciones;
	}

	public void setLicitaciones(List<Map> licitaciones) {
		this.licitaciones = licitaciones;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public int getEstatus() {
		return estatus;
	}

	public void setEstatus(int estatus) {
		this.estatus = estatus;
	}

	public BeanUsuario getBeanUsuario() {
		return beanUsuario;
	}

	public void setBeanUsuario(BeanUsuario beanUsuario) {
		this.beanUsuario = beanUsuario;
	}
}
