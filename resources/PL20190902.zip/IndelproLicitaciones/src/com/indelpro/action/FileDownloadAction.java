package com.indelpro.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class FileDownloadAction extends ActionSupport
		implements SessionAware, ServletContextAware {
	private static final long serialVersionUID = 1L;
	private ServletContext servletContext;
	private SessionMap<String, Object> sessionMap;

	private InputStream fileInputStream;
	private String uuid;
	private String fileName;
	private String contentType;
//	private String contentDisposition;

	public String execute() throws Exception {
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		BeanProveedor bp = (BeanProveedor) sessionMap.get("proveedor");
		if(bu == null && bp == null) // No se ha logeado
			return "authReq";

		String rutaArchivos = servletContext.getInitParameter("rutaArchivos");
//		if(contentDisposition == null || contentDisposition.equals("")) 
//			contentDisposition = "inline";
		if(fileName.toLowerCase().endsWith(".pdf"))
			contentType = "application/pdf";
		else if(fileName.toLowerCase().endsWith(".xlsx"))
			contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		else if(fileName.toLowerCase().endsWith(".xls"))
			contentType = "application/vnd.ms-excel";
		else
			contentType = "application/octet-stream";
		File archivo = new File(rutaArchivos + uuid);
		if(archivo == null || !archivo.exists())
			archivo =  new File(rutaArchivos + "404.pdf");
		fileInputStream = new FileInputStream(archivo);
		return SUCCESS;
	}
	

	@Override
	public void setSession(Map<String, Object> map) {
		sessionMap = (SessionMap) map;
	}
	@Override
    public void setServletContext(ServletContext context) {
        this.servletContext = context;
    }

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public SessionMap<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSessionMap(SessionMap<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}

	public void setFileInputStream(InputStream fileInputStream) {
		this.fileInputStream = fileInputStream;
	}



	public String getUuid() {
		return uuid;
	}



	public void setUuid(String uuid) {
		this.uuid = uuid;
	}



	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}


	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

//
//	public String getContentDisposition() {
//		return contentDisposition;
//	}
//
//
//	public void setContentDisposition(String contentDisposition) {
//		this.contentDisposition = contentDisposition;
//	}

}