package com.indelpro.action;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.opensymphony.xwork2.ActionSupport;

public class WelcomeAction extends ActionSupport 
	implements ServletResponseAware, SessionAware{
	private HttpServletResponse response;
	private SessionMap<String,Object> sessionMap; 
	
	public String execute() {
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		// bean proveedor
		if(bu != null) {
			return "success";
		} else {
			return "error";
		}
	}

	public String welcomeProveedor() {
		BeanProveedor bp = (BeanProveedor) sessionMap.get("proveedor");
		// bean proveedor
		if(bp != null) {
			return "success";
		} else {
			return "error";
		}
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	public HttpServletResponse getServletResponse() {
		return this.response;
	}

	@Override  
	public void setSession(Map<String, Object> map) {  
	    sessionMap=(SessionMap)map;  
	}  

	
	
}