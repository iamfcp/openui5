package com.indelpro.action;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanMap;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import com.indelpro.model.BeanLicitacion;
import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.indelpro.model.dao.DAOForo;
import com.indelpro.model.dao.DAOLicitacion;
import com.indelpro.model.dao.DAOUsuario;
import com.indelpro.util.Email;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class ForoAction extends ActionSupport implements ServletResponseAware, SessionAware, ServletContextAware {
	private SessionMap<String,Object> sessionMap; 
	private ServletContext servletContext;
	private HttpServletResponse response;
	private Map data = new HashMap();
	private String contextPath = ServletActionContext.getRequest().getContextPath();


	public String numeroLicitacion   ;
	public int 	  codigo              ;
	public String mensaje             ;

	public String foro() {
		if (sessionMap == null)
			sessionMap = (SessionMap<String, Object>) ActionContext.getContext().getSession();
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		BeanProveedor p = (BeanProveedor) sessionMap.get("proveedor");

		DAOForo df = new DAOForo();
		ArrayList<Map> foro = df.obtenForo(numeroLicitacion, p != null);
		data.put("foro", foro);

		return Action.SUCCESS;
	}

	public String pregunta() {
		if (sessionMap == null)
			sessionMap = (SessionMap<String, Object>) ActionContext.getContext().getSession();
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		BeanProveedor p = (BeanProveedor) sessionMap.get("proveedor");
		String nl = (String) data.get("numeroLicitacion");
		String pregunta = (String) data.get("mensaje");
		String archivo = (String) data.get("archivo");
		String idArchivo = (String) data.get("idArchivo");

		DAOForo df = new DAOForo();
		df.pregunta(nl, pregunta, archivo, idArchivo, bu!=null);
		
//		if(bu==null) {
			DAOLicitacion daol = new DAOLicitacion();
			BeanLicitacion bl = daol.obtiene(nl);
			DAOUsuario daou = new DAOUsuario();
			if(bl == null || bl.creador == null || bl.responsable == null) {
				System.err.println("Foro - pregunta - Error NULL");
				return Action.SUCCESS;
			}
			bu = daou.obtenUsuario(bl.creador);
			String correos = bu.correo+";";
			bu = daou.obtenUsuario(bl.responsable);
			correos += bu.correo;
			
			String htmlMessage;
			try {
				htmlMessage = Email.mensajeBaseProveedor(
						bl, 
						"Se recibi� una pregunta en el foro de discusi�n para la licitaci�n " + bl.numeroLicitacion + " - " + bl.descripcion + 
							"<br><b>Pregunta: " + pregunta + "</b>", 
						"Puede publicar una respuesta accediendo al foro en la consulta de licitaciones.", contextPath);
				Email.enviarCorreo(contextPath, 
						correos,
						"Se recibi� una pregunta en el foro de discusi�n", 
						htmlMessage,
						null,
						null);
			} catch (ParseException e) {
				e.printStackTrace();
			}

//		}

		return Action.SUCCESS;
	}	
	
	public String respuesta() {
		if (sessionMap == null)
			sessionMap = (SessionMap<String, Object>) ActionContext.getContext().getSession();
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		BeanProveedor p = (BeanProveedor) sessionMap.get("proveedor");
		String nl = (String) data.get("numeroLicitacion");
		int np = ((Long) data.get("idPregunta")).intValue();
		String respuesta = (String) data.get("mensaje");
		String archivo = (String) data.get("archivo");
		String idArchivo = (String) data.get("idArchivo");
		DAOForo df = new DAOForo();
		df.respuesta(nl, respuesta, archivo, idArchivo, np);
		
		DAOLicitacion daol = new DAOLicitacion();
		BeanLicitacion bl = daol.obtiene(nl);
		String correos ="";
		for(HashMap mapProv: bl.listaProveedores)
			correos += mapProv.get("correo") + ";";

		String htmlMessage;
		try {
			htmlMessage = Email.mensajeBaseProveedor(
					bl, 
					"Hay mensajes nuevos en el foro de discusi�n de la licitaci�n " + bl.numeroLicitacion + " - " + bl.descripcion, 
					"Puede consultarlos accediendo al foro en el env�o de propuesta.", contextPath+"/loginProveedor.jsp");
			Email.enviarCorreo(contextPath, 
					correos,
					"Hay mensajes nuevos en el foro de discusi�n", 
					htmlMessage,
					null,
					null);
		} catch (ParseException e) {
			e.printStackTrace();
		}


		return Action.SUCCESS;
	}	
	
	public BeanUsuario validaSesion() {
		if (sessionMap == null)
			sessionMap = (SessionMap<String, Object>) ActionContext.getContext().getSession();
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		if (bu == null) {
			setCodigo(401);
			setMensaje("Su sesi�n ha caducado");
			return null;
		}
		if (servletContext == null)
			servletContext = ServletActionContext.getServletContext();
		return bu;
	}
	
	@Override  
	public void setSession(Map<String, Object> map) {  
	    sessionMap=(SessionMap)map;  
	}  

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	@Override
    public void setServletContext(ServletContext context) {
        this.servletContext = context;
    }

	public Map getData() {
		return data;
	}

	public void setData(Map data) {
		this.data = data;
	}
	
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getNumeroLicitacion() {
		return numeroLicitacion;
	}

	public void setNumeroLicitacion(String numeroLicitacion) {
		this.numeroLicitacion = numeroLicitacion;
	}
}
