package com.indelpro.action;

import java.io.File;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;
import com.opensymphony.xwork2.ActionSupport;

public class FileUploadAction extends ActionSupport 
	implements ServletResponseAware, SessionAware, ServletContextAware {
	private static final long serialVersionUID = 1L;
	private HttpServletResponse response;
	private ServletContext servletContext;
	private SessionMap<String, Object> sessionMap;

	private File archivoUno;
	private String archivoUnoContentType;
	private String archivoUnoFilename;
	private File archivoDos;
	private String archivoDosContentType;
	private String archivoDosFileName;
	private File archivoTres;
	private String archivoTresContentType;
	private String archivoTresFileName;
	private File archivoN;
	private String archivoNContentType;
	private String archivoNFileName;
	
	private String _charset_;
	
	
	public String execute() {
		BeanUsuario bu = (BeanUsuario) sessionMap.get("usuario");
		BeanProveedor bp = (BeanProveedor) sessionMap.get("proveedor");
		if(bu == null && bp == null) { // No se ha logeado
			addActionMessage("Authentication Required.");
			return "error";
		}
		System.out.print("FileUploadAction: " + new Date() + 
				(bu != null? bu.usuario:"") + (bp != null? bp.rfc:"") +
				" " + archivoUnoFilename + " " + archivoDosFileName + " " + archivoTresFileName);
		try {
			String rutaArchivos = servletContext.getInitParameter("rutaArchivos");
			String na = "";
			String uuid = UUID.randomUUID().toString();
			if(new File(rutaArchivos + uuid).exists())
				uuid = UUID.randomUUID().toString();
			if(archivoUno != null) {
				na = archivoUnoFilename;
				archivoUno.renameTo(new File(rutaArchivos + uuid));
			}
			if(archivoDos != null) {
				na = archivoDosFileName;
				archivoDos.renameTo(new File(rutaArchivos + uuid));
			}
			if(archivoTres != null) {
				na = archivoTresFileName;
				archivoTres.renameTo(new File(rutaArchivos + uuid));
			}
			if(archivoN != null) {
				na = archivoNFileName;
				archivoN.renameTo(new File(rutaArchivos + uuid));
			}
			addActionMessage("OK");
			addActionMessage(uuid);
			addActionMessage(na);
			System.out.println("---OK--- " + uuid + " " + na);

			return "success";
			
		} catch (Exception e) {
			System.out.println("+++ERROR+++ " + e + new Date());
			return "error";
		}
	}

	public void setArchivoUno(File file) {
		this.archivoUno = file;
	}

	public void setArchivoUnoContentType(String contentType) {
		this.archivoUnoContentType = contentType;
	}

	public void setArchivoUnoFileName(String filename) {
		this.archivoUnoFilename = filename;
	}

	public void set_charset_(String _charset_) {
		this._charset_ = _charset_;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public HttpServletResponse getServletResponse() {
		return this.response;
	}

	@Override
	public void setSession(Map<String, Object> map) {
		sessionMap = (SessionMap) map;
	}
	@Override
    public void setServletContext(ServletContext context) {
        this.servletContext = context;
    }
	
	public void setArchivoDos(File archivoDos) {
		this.archivoDos = archivoDos;
	}

	public void setArchivoDosContentType(String archivoDosContentType) {
		this.archivoDosContentType = archivoDosContentType;
	}

	public void setArchivoDosFileName(String archivoDosFilename) {
		this.archivoDosFileName = archivoDosFilename;
	}

	public void setArchivoUnoFilename(String archivoUnoFilename) {
		this.archivoUnoFilename = archivoUnoFilename;
	}

	public void setArchivoTres(File archivoTres) {
		this.archivoTres = archivoTres;
	}

	public void setArchivoTresContentType(String archivoTresContentType) {
		this.archivoTresContentType = archivoTresContentType;
	}

	public void setArchivoTresFileName(String archivoTresFileName) {
		this.archivoTresFileName = archivoTresFileName;
	}

	public void setArchivoN(File archivoN) {
		this.archivoN = archivoN;
	}

	public void setArchivoNContentType(String archivoNContentType) {
		this.archivoNContentType = archivoNContentType;
	}

	public void setArchivoNFileName(String archivoNFileName) {
		this.archivoNFileName = archivoNFileName;
	}

}