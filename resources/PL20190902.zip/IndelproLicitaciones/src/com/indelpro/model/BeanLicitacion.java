package com.indelpro.model;

import java.util.ArrayList;
import java.util.HashMap;

public class BeanLicitacion {
	public String numeroLicitacion;
	public String descripcion;
	public String fechaLimite;
	public String responsable;
	public String nombreResponsable;
	public String creador;
	public String nombreCreador;
	public String elementoPEP;
	public String nombreArchivoBases;
	public String nombreArchivoEvaluacion;
	public String idArchivoBases;
	public String idArchivoEvaluacion;

	public String liberadorPT;
	public String fechaLiberacionPT;
	public String fechaEvaluacion;
	public String liberadorPE1;
	public String liberadorPE2;
	public String fechaLiberacionPE;
	public String mensajeAdjudicacion;
	public String idArchivoActaResultados;
	public String proveedorGanador;
	public String proveedorPropuesto;
	public String idArchivoResultados;
	public String nombreArchivoResultados;
	public String idArchivoSoporteAsignacion;
	public String nombreArchivoSoporteAsignacion;

	public String fechaVisitaObra;
	public String moneda;
	public String proveedorReasignado;
	public String mensajeReasignacion;
	public String nombreArchivoPresupuesto;
	public String idArchivoPresupuesto;
	public ArrayList<HashMap> listaArchivosAdicionales;

	public double importeEstimado;
	public int tipo;
	public int estatus;

	public ArrayList<HashMap> listaProveedores;
	public ArrayList<HashMap> lConceptosEvaluacion;
	public ArrayList<HashMap> lResultadosEvaluacion;
	public ArrayList<HashMap> lAprobaciones;
	public ArrayList<HashMap> lMovimientos;
	
	
	
	public String getNumeroLicitacion() {
		return numeroLicitacion;
	}
	public void setNumeroLicitacion(String numeroLicitacion) {
		this.numeroLicitacion = numeroLicitacion;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getFechaLimite() {
		return fechaLimite;
	}
	public void setFechaLimite(String fechaLimite) {
		this.fechaLimite = fechaLimite;
	}
	public String getResponsable() {
		return responsable;
	}
	public void setResponsable(String responsable) {
		this.responsable = responsable;
	}
	public String getElementoPEP() {
		return elementoPEP;
	}
	public void setElementoPEP(String elementoPEP) {
		this.elementoPEP = elementoPEP;
	}
	public String getNombreArchivoBases() {
		return nombreArchivoBases;
	}
	public void setNombreArchivoBases(String nombreArchivoBases) {
		this.nombreArchivoBases = nombreArchivoBases;
	}
	public String getNombreArchivoEvaluacion() {
		return nombreArchivoEvaluacion;
	}
	public void setNombreArchivoEvaluacion(String nombreArchivoEvaluacion) {
		this.nombreArchivoEvaluacion = nombreArchivoEvaluacion;
	}
	public String getIdArchivoBases() {
		return idArchivoBases;
	}
	public void setIdArchivoBases(String idArchivoBases) {
		this.idArchivoBases = idArchivoBases;
	}
	public String getIdArchivoEvaluacion() {
		return idArchivoEvaluacion;
	}
	public void setIdArchivoEvaluacion(String idArchivoEvaluacion) {
		this.idArchivoEvaluacion = idArchivoEvaluacion;
	}
	public double getImporteEstimado() {
		return importeEstimado;
	}
	public void setImporteEstimado(double importeEstimado) {
		this.importeEstimado = importeEstimado;
	}
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	public int getEstatus() {
		return estatus;
	}
	public void setEstatus(int estatus) {
		this.estatus = estatus;
	}
	public ArrayList<HashMap> getListaProveedores() {
		return listaProveedores;
	}
	public void setListaProveedores(ArrayList<HashMap> listaProveedores) {
		this.listaProveedores = listaProveedores;
	}
	public ArrayList<HashMap> getlConceptosEvaluacion() {
		return lConceptosEvaluacion;
	}
	public void setlConceptosEvaluacion(ArrayList<HashMap> lConceptosEvaluacion) {
		this.lConceptosEvaluacion = lConceptosEvaluacion;
	}
	public ArrayList<HashMap> getlResultadosEvaluacion() {
		return lResultadosEvaluacion;
	}
	public void setlResultadosEvaluacion(ArrayList<HashMap> lResultadosEvaluacion) {
		this.lResultadosEvaluacion = lResultadosEvaluacion;
	}
	public String getNombreResponsable() {
		return nombreResponsable;
	}
	public void setNombreResponsable(String nombreResponsable) {
		this.nombreResponsable = nombreResponsable;
	}
	public String getFechaLiberacionPT() {
		return fechaLiberacionPT;
	}
	public void setFechaLiberacionPT(String fechaLiberacionPT) {
		this.fechaLiberacionPT = fechaLiberacionPT;
	}
	public String getFechaEvaluacion() {
		return fechaEvaluacion;
	}
	public void setFechaEvaluacion(String fechaEvaluacion) {
		this.fechaEvaluacion = fechaEvaluacion;
	}
	public String getLiberadorPE1() {
		return liberadorPE1;
	}
	public void setLiberadorPE1(String liberadorPE1) {
		this.liberadorPE1 = liberadorPE1;
	}
	public String getLiberadorPE2() {
		return liberadorPE2;
	}
	public void setLiberadorPE2(String liberadorPE2) {
		this.liberadorPE2 = liberadorPE2;
	}
	public String getFechaLiberacionPE() {
		return fechaLiberacionPE;
	}
	public void setFechaLiberacionPE(String fechaLiberacionPE) {
		this.fechaLiberacionPE = fechaLiberacionPE;
	}
	public String getMensajeAdjudicacion() {
		return mensajeAdjudicacion;
	}
	public void setMensajeAdjudicacion(String mensajeAdjudicacion) {
		this.mensajeAdjudicacion = mensajeAdjudicacion;
	}
	public String getIdArchivoActaResultados() {
		return idArchivoActaResultados;
	}
	public void setIdArchivoActaResultados(String idArchivoActaResultados) {
		this.idArchivoActaResultados = idArchivoActaResultados;
	}
	public String getLiberadorPT() {
		return liberadorPT;
	}
	public void setLiberadorPT(String liberadorPT) {
		this.liberadorPT = liberadorPT;
	}
	public String getProveedorGanador() {
		return proveedorGanador;
	}
	public void setProveedorGanador(String proveedorGanador) {
		this.proveedorGanador = proveedorGanador;
	}
	public ArrayList<HashMap> getlAprobaciones() {
		return lAprobaciones;
	}
	public void setlAprobaciones(ArrayList<HashMap> lAprobaciones) {
		this.lAprobaciones = lAprobaciones;
	}
	public String getCreador() {
		return creador;
	}
	public void setCreador(String creador) {
		this.creador = creador;
	}
	public String getIdArchivoResultados() {
		return idArchivoResultados;
	}
	public void setIdArchivoResultados(String idArchivoResultados) {
		this.idArchivoResultados = idArchivoResultados;
	}
	public String getNombreArchivoResultados() {
		return nombreArchivoResultados;
	}
	public void setNombreArchivoResultados(String nombreArchivoResultados) {
		this.nombreArchivoResultados = nombreArchivoResultados;
	}
	public String getProveedorPropuesto() {
		return proveedorPropuesto;
	}
	public void setProveedorPropuesto(String proveedorPropuesto) {
		this.proveedorPropuesto = proveedorPropuesto;
	}
	public String getNombreCreador() {
		return nombreCreador;
	}
	public void setNombreCreador(String nombreCreador) {
		this.nombreCreador = nombreCreador;
	}
	public String getFechaVisitaObra() {
		return fechaVisitaObra;
	}
	public void setFechaVisitaObra(String fechaVisitaObra) {
		this.fechaVisitaObra = fechaVisitaObra;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getProveedorReasignado() {
		return proveedorReasignado;
	}
	public void setProveedorReasignado(String proveedorReasignado) {
		this.proveedorReasignado = proveedorReasignado;
	}
	public String getMensajeReasignacion() {
		return mensajeReasignacion;
	}
	public void setMensajeReasignacion(String mensajeReasignacion) {
		this.mensajeReasignacion = mensajeReasignacion;
	}
	public String getNombreArchivoPresupuesto() {
		return nombreArchivoPresupuesto;
	}
	public void setNombreArchivoPresupuesto(String nombreArchivoPresupuesto) {
		this.nombreArchivoPresupuesto = nombreArchivoPresupuesto;
	}
	public String getIdArchivoPresupuesto() {
		return idArchivoPresupuesto;
	}
	public void setIdArchivoPresupuesto(String idArchivoPresupuesto) {
		this.idArchivoPresupuesto = idArchivoPresupuesto;
	}
	public ArrayList<HashMap> getListaArchivosAdicionales() {
		return listaArchivosAdicionales;
	}
	public void setListaArchivosAdicionales(ArrayList<HashMap> listaArchivosAdicionales) {
		this.listaArchivosAdicionales = listaArchivosAdicionales;
	}
	public ArrayList<HashMap> getlMovimientos() {
		return lMovimientos;
	}
	public void setlMovimientos(ArrayList<HashMap> lMovimientos) {
		this.lMovimientos = lMovimientos;
	}

	public String getIdArchivoSoporteAsignacion() {
		return idArchivoSoporteAsignacion;
	}
	public void setIdArchivoSoporteAsignacion(String idArchivoSoporteAsignacion) {
		this.idArchivoSoporteAsignacion = idArchivoSoporteAsignacion;
	}
	public String getNombreArchivoSoporteAsignacion() {
		return nombreArchivoSoporteAsignacion;
	}
	public void setNombreArchivoSoporteAsignacion(String nombreArchivoSoporteAsignacion) {
		this.nombreArchivoSoporteAsignacion = nombreArchivoSoporteAsignacion;
	}
	
	@Override
	public String toString() {
		return "BeanLicitacion [numeroLicitacion=" + numeroLicitacion + ", descripcion=" + descripcion
				+ ", fechaLimite=" + fechaLimite + ", responsable=" + responsable + ", nombreResponsable="
				+ nombreResponsable + ", creador=" + creador + ", nombreCreador=" + nombreCreador + ", elementoPEP="
				+ elementoPEP + ", nombreArchivoBases=" + nombreArchivoBases + ", nombreArchivoEvaluacion="
				+ nombreArchivoEvaluacion + ", idArchivoBases=" + idArchivoBases + ", idArchivoEvaluacion="
				+ idArchivoEvaluacion + ", liberadorPT=" + liberadorPT + ", fechaLiberacionPT=" + fechaLiberacionPT
				+ ", fechaEvaluacion=" + fechaEvaluacion + ", liberadorPE1=" + liberadorPE1 + ", liberadorPE2="
				+ liberadorPE2 + ", fechaLiberacionPE=" + fechaLiberacionPE + ", mensajeAdjudicacion="
				+ mensajeAdjudicacion + ", idArchivoActaResultados=" + idArchivoActaResultados + ", proveedorGanador="
				+ proveedorGanador + ", proveedorPropuesto=" + proveedorPropuesto + ", idArchivoResultados="
				+ idArchivoResultados + ", nombreArchivoResultados=" + nombreArchivoResultados + ", fechaVisitaObra="
				+ fechaVisitaObra + ", moneda=" + moneda + ", proveedorReasignado=" + proveedorReasignado
				+ ", mensajeReasignacion=" + mensajeReasignacion + ", nombreArchivoPresupuesto="
				+ nombreArchivoPresupuesto + ", idArchivoPresupuesto=" + idArchivoPresupuesto
				+ ", listaArchivosAdicionales=" + listaArchivosAdicionales + ", importeEstimado=" + importeEstimado
				+ ", tipo=" + tipo + ", estatus=" + estatus + ", listaProveedores=" + listaProveedores
				+ ", lConceptosEvaluacion=" + lConceptosEvaluacion + ", lResultadosEvaluacion=" + lResultadosEvaluacion
				+ ", lAprobaciones=" + lAprobaciones + ", lMovimientos=" + lMovimientos 
				+ ", idArchivoSoporteAsignacion=" + idArchivoSoporteAsignacion + ", nombreArchivoSoporteAsignacion=" + nombreArchivoSoporteAsignacion +
				"]";
	}

}
