package com.indelpro.model;

public class BeanConcepto {
	public String concepto           ;
	public double valor              ; 

	public BeanConcepto() {
		concepto = new String();
		valor = 0;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

}
