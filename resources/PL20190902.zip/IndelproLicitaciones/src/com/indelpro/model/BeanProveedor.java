package com.indelpro.model;

public class BeanProveedor {
	public String numeroSAP           ;
	public String nombre              ; 
	public String correo              ; 
	public String rfc		          ; 
	public String notas               ; 
	
	public BeanProveedor() {
		numeroSAP = new String();
		nombre = new String();
		rfc = new String();
		notas = new String();
	}

	public String getNumeroSAP() {
		return numeroSAP;
	}

	public void setNumeroSAP(String numeroSAP) {
		this.numeroSAP = numeroSAP;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public String getNotas() {
		return notas;
	}

	public void setNotas(String notas) {
		this.notas = notas;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}
}
