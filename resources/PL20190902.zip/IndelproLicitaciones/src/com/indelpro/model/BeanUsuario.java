package com.indelpro.model;

import com.indelpro.security.Util;
import com.opensymphony.xwork2.Action;

public class BeanUsuario {
	public String usuario             ;
	public String jefe                ;
	public String nombre              ; 
	public String departamento        ; 
	public String correo              ; 
	public String hash                ; 
	public String hashl               ; 
	public String salt                ; 
	public Boolean activo             ;
	public Boolean liberaPT           ;
	public Boolean liberaPE           ;
	public Boolean comite             ;
	public Boolean abastecimientos    ;
	public Boolean evalTecnico        ;
	public Boolean directorGeneral    ;

	public BeanUsuario() {
		usuario = new String();
		nombre = new String();
		departamento = new String();
		correo = new String();
		activo = new Boolean(false);
		liberaPT = new Boolean(false);
		liberaPE = new Boolean(false);
		comite = new Boolean(false);
		abastecimientos = new Boolean(false);
		evalTecnico = new Boolean(false);
	}
	
	public boolean validaPassword(String password) {
		if(this.hash == null || this.salt == null) {
			return false;
		} else {
			String hash = Util.getSHA256Hash(password + this.salt);
			return hash.equals(this.hash);
		}

	}

	public boolean validaClaveLiberacion(String clave) {
		if(this.hashl == null || this.salt == null) {
			return false;
		} else {
			String h = Util.getSHA256Hash(clave + this.salt);
			return h.equals(this.hashl);
		}
	}

	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public Boolean getActivo() {
		return activo;
	}
	public void setActivo(Boolean activo) {
		this.activo = activo;
	}
	public Boolean getLiberaPT() {
		return liberaPT;
	}
	public void setLiberaPT(Boolean liberaPT) {
		this.liberaPT = liberaPT;
	}
	public Boolean getLiberaPE() {
		return liberaPE;
	}
	public void setLiberaPE(Boolean liberaPE) {
		this.liberaPE = liberaPE;
	}
	public Boolean getComite() {
		return comite;
	}
	public void setComite(Boolean comite) {
		this.comite = comite;
	}
	public Boolean getAbastecimientos() {
		return abastecimientos;
	}
	public void setAbastecimientos(Boolean abastecimientos) {
		this.abastecimientos = abastecimientos;
	}
	public Boolean getEvalTecnico() {
		return evalTecnico;
	}
	public void setEvalTecnico(Boolean evalTecnico) {
		this.evalTecnico = evalTecnico;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getHashl() {
		return hashl;
	}

	public void setHashl(String hashl) {
		this.hashl = hashl;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public Boolean getDirectorGeneral() {
		return directorGeneral;
	}

	public void setDirectorGeneral(Boolean directorGeneral) {
		this.directorGeneral = directorGeneral;
	}

	public String getJefe() {
		return jefe;
	}

	public void setJefe(String jefe) {
		this.jefe = jefe;
	}
}
