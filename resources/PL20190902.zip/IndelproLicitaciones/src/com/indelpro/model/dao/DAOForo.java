package com.indelpro.model.dao;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.indelpro.model.BeanProveedor;

public class DAOForo extends DAO {
	private static SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");

	public ArrayList<Map> obtenForo(String numeroLicitacion, boolean proveedor) {
		Connection conn = getConexion();
		ArrayList<Map>preguntas =  new ArrayList<Map>();
		ArrayList<Map>foro =  new ArrayList<Map>();
		try {
			PreparedStatement st = conn
					.prepareStatement(
							"SELECT ID_PREGUNTA"
							+ ",NUMERO_LICITACION"
							+ ",PUBLICA"
							+ ",FECHA_ENVIO"
							+ ",PREGUNTA"
							+ ",NOMBRE_ANEXO"
							+ ",ID_ANEXO "
							+ "FROM T_FORO_PREGUNTA "
							+ "WHERE NUMERO_LICITACION = ? "	
							+ "ORDER BY ID_PREGUNTA");
			st.setString(1, numeroLicitacion);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				if(proveedor && !rs.getBoolean("PUBLICA"))
					continue;
				HashMap preg = new HashMap();
				preg.put("ID_PREGUNTA"         ,rs.getInt("ID_PREGUNTA"));
				preg.put("NUMERO_LICITACION"   ,rs.getString("NUMERO_LICITACION"));
				preg.put("PUBLICA"             ,rs.getBoolean("PUBLICA"));
				preg.put("FECHA_ENVIO"         ,dateTimeFormatter.format(rs.getTimestamp("FECHA_ENVIO")));
				preg.put("TEXTO"               ,rs.getString("PREGUNTA"));
				preg.put("NOMBRE_ANEXO"        ,rs.getString("NOMBRE_ANEXO"));
				preg.put("ID_ANEXO"            ,rs.getString("ID_ANEXO"));
				preg.put("TIENE_ANEXO"         ,rs.getString("ID_ANEXO") != null && rs.getString("ID_ANEXO").length() > 1);
				preg.put("PREGUNTA"            ,true);
				preg.put("SENDER"         	   ,"Responder");
				preg.put("ICON"         	 ,rs.getString("ID_ANEXO") != null && rs.getString("ID_ANEXO").length() > 1? "sap-icon://download": "sap-icon://sys-help");
				preguntas.add(preg);
			}

			st = conn.prepareStatement(
							"SELECT ID_RESPUESTA "
							+ ",ID_PREGUNTA "
							+ ",NUMERO_LICITACION"
							+ ",FECHA_ENVIO "
							+ ",RESPUESTA "
							+ ",NOMBRE_ANEXO "
							+ ",ID_ANEXO "
							+ "FROM T_FORO_RESPUESTA "
							+ "WHERE ID_PREGUNTA = ? "
							+ "ORDER BY ID_RESPUESTA ");
			
			for(Map preg: preguntas) {
				st.setInt(1, (int)preg.get("ID_PREGUNTA"));
				rs = st.executeQuery();
				foro.add(preg);
				ArrayList<Map>respuestas =  new ArrayList<Map>();
				while (rs.next()) {
					HashMap resp = new HashMap();
					resp.put("ID_RESPUESTA"      , rs.getInt("ID_RESPUESTA"));     
					resp.put("ID_PREGUNTA"       , rs.getInt("ID_PREGUNTA"));   
					resp.put("NUMERO_LICITACION" , rs.getString("NUMERO_LICITACION"));
					resp.put("FECHA_ENVIO"       , dateTimeFormatter.format(rs.getTimestamp("FECHA_ENVIO")));
					resp.put("TEXTO"             , rs.getString("RESPUESTA"));  
					resp.put("NOMBRE_ANEXO"      , rs.getString("NOMBRE_ANEXO"));
					resp.put("ID_ANEXO"          , rs.getString("ID_ANEXO"));
					resp.put("TIENE_ANEXO"       ,rs.getString("ID_ANEXO") != null && rs.getString("ID_ANEXO").length() > 1);
					resp.put("INFO"         	 ,preg.get("TEXTO"));
					resp.put("ICON"         	 ,rs.getString("ID_ANEXO") != null && rs.getString("ID_ANEXO").length() > 1? "sap-icon://download": "sap-icon://response");
					foro.add(resp);
				}
			}
			
			return foro;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		} finally {
			cierraConexion(conn);
		}
		
	}
	
	public int pregunta(String nl, String pregunta, String archivo, String idArchivo, boolean publica) {
		if(pregunta == null)
			return -1;
		Connection conn = getConexion();
		
		try {
			PreparedStatement st = conn.prepareStatement(
					"INSERT INTO T_FORO_PREGUNTA" +
					"           (NUMERO_LICITACION  " +
					"           ,PUBLICA            " +
					"           ,FECHA_ENVIO        " +
					"           ,PREGUNTA           " +
					"           ,NOMBRE_ANEXO       " +
					"           ,ID_ANEXO)          " +
					"     VALUES (?, ?, GETDATE(), ?, ?, ?) ");

			st.setString(1, nl);
			st.setBoolean(2, publica);
			st.setString(3, pregunta.length() > 7999?pregunta.substring(0, 7999): pregunta);
			st.setString(4, archivo);
			st.setString(5, idArchivo);

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int respuesta(String nl, String respuesta, String archivo, String idArchivo, int pregunta) {
		if(respuesta == null)
			return -1;
		Connection conn = getConexion();
		
		try {
			PreparedStatement st = conn.prepareStatement(
					"INSERT INTO T_FORO_RESPUESTA  " +
					"           (ID_PREGUNTA       " +
					"           ,NUMERO_LICITACION " +
					"           ,FECHA_ENVIO       " +
					"           ,RESPUESTA         " +
					"           ,NOMBRE_ANEXO      " +
					"           ,ID_ANEXO)         " +
					"     VALUES (?, ?, GETDATE(), ?, ?, ?) ");

			st.setInt(1, pregunta);
			st.setString(2, nl);
			st.setString(3, respuesta.length() > 7999?respuesta.substring(0, 7999): respuesta);
			st.setString(4, archivo);
			st.setString(5, idArchivo);
			st.executeUpdate();

			st = conn.prepareStatement(
					"UPDATE T_FORO_PREGUNTA"
					+ "   SET PUBLICA = 1"
					+ " WHERE ID_PREGUNTA = ?");

			st.setInt(1, pregunta);
			
			return st.executeUpdate();
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

}
