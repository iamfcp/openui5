package com.indelpro.model.dao;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.indelpro.model.BeanLicitacion;
import com.indelpro.model.BeanUsuario;
import com.indelpro.security.Util;
import com.indelpro.util.Email;


public class DAOLicitacion extends DAO {
	public static final int NUEVA = 0;
	public static final int ENVIADA = 1;
	public static final int VENCIO_PLAZO = 2;
	public static final int PT_LIBERADA = 3;
	public static final int EVALUDADA = 4;
	public static final int PE_LIBERADA = 5;
	public static final int ESPERA_APROBACION = 6;
	public static final int CONCLUIDA = 7;
	public static final int CANCELADA = 8;
	public static final int REASIGNADA = 9;
	public static final int EN_APROBACION_EVAL = 10;
	
	public static final String[] DESCRIPCION_ESTATUS = {
		"Nueva", // 0
		"Licitaci�n enviada", // 1
		"Disponible para Liberaci�n",//2
		"Disponible para Evaluaci�n T�cnica",//3
		"Pendiente de Junta de Comit�",//4
		"Propuesta Econ�mica Liberada",// 5
		"Pendiente de Aprobaci�n",// 6
		"Conclu�da", // 7
		"Cancelada", // 8
		"Reasignada", // 9
		"Espera Aprobaci�n de Evaluaci�n" // 10
	};
	
	private static SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
	private static SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("dd / MM / yyyy HH:mm");

	public List<BeanLicitacion> lista(int estatus) {
		ArrayList<BeanLicitacion> lista = new ArrayList<BeanLicitacion>();
		if(estatus != DAOLicitacion.VENCIO_PLAZO)
			return list(estatus);
		lista = (ArrayList<BeanLicitacion>) list(estatus);
		lista.addAll(list(DAOLicitacion.ENVIADA));
		return lista;
	}
	
	private List<BeanLicitacion> list(int estatus) {
		ArrayList<BeanLicitacion> lista = null;
		Connection conn = getConexion();
        try{
            PreparedStatement st = null;
            if(estatus >= 0) {
            	st = conn.prepareStatement(
	        		"SELECT NUMERO_LICITACION, DESCRIPCION, FECHA_LIMITE, RESPONSABLE, ELEMENTO_PEP, CREADOR, "
	        		+ "NOMBRE_ARCHIVO_BASES, NOMBRE_ARCHIVO_EVALUACION, ID_ARCHIVO_BASES, ID_ARCHIVO_EVALUACION, "
	        		+ "TIPO, IMPORTE_ESTIMADO, ESTATUS "
	        		+ "FROM T_LICITACION "
	        		+ "WHERE ESTATUS = ?");
            	st.setInt(1, estatus);
            } else 
            	st = conn.prepareStatement(
	        		"SELECT NUMERO_LICITACION, DESCRIPCION, FECHA_LIMITE, RESPONSABLE, ELEMENTO_PEP, CREADOR, "
	        		+ "NOMBRE_ARCHIVO_BASES, NOMBRE_ARCHIVO_EVALUACION, ID_ARCHIVO_BASES, ID_ARCHIVO_EVALUACION, "
	        		+ "TIPO, IMPORTE_ESTIMADO, ESTATUS "
	        		+ "FROM T_LICITACION");
            ResultSet rs = st.executeQuery();
            
            lista = new ArrayList<BeanLicitacion>();
            while (rs.next()){
            	BeanLicitacion bean = new BeanLicitacion();
                bean.numeroLicitacion = rs.getString("NUMERO_LICITACION");
                bean.descripcion = rs.getString("DESCRIPCION");
                bean.fechaLimite = rs.getString("FECHA_LIMITE");
                bean.responsable = rs.getString("RESPONSABLE");
                bean.creador = rs.getString("CREADOR");
                bean.elementoPEP = rs.getString("ELEMENTO_PEP");
                bean.nombreArchivoBases = rs.getString("NOMBRE_ARCHIVO_BASES");
                bean.nombreArchivoEvaluacion = rs.getString("NOMBRE_ARCHIVO_EVALUACION");
                bean.idArchivoBases = rs.getString("ID_ARCHIVO_BASES");
                bean.idArchivoEvaluacion = rs.getString("ID_ARCHIVO_EVALUACION");
                bean.tipo = rs.getInt("TIPO");
                bean.estatus = rs.getInt("ESTATUS");
                bean.importeEstimado = rs.getLong("IMPORTE_ESTIMADO");
                lista.add(bean);
            }
            
            for (BeanLicitacion beanLicitacion : lista) {
                st = conn.prepareStatement(
                		"SELECT RESPONSABLE               " +
        				"      ,APRUEBA                   " +
        				"      ,MENSAJE                   " +
        				"      ,FECHA                     " +
        				"      ,ENVIADA                   " +
        				"  FROM T_APROBACIONES_LICITACION " +
        				" WHERE NUMERO_LICITACION = ? ");
                st.setString(1, beanLicitacion.numeroLicitacion);
                rs = st.executeQuery();
                ArrayList la = new ArrayList();
                while (rs.next()) {
                	HashMap map = new HashMap<>();
                	map.put("responsable", rs.getString(1));
                	map.put("aprueba", rs.getBoolean(2));
                	map.put("mensaje", rs.getString(3));
                	map.put("fecha", rs.getString(4));
                	map.put("enviada", rs.getBoolean(5));
                	la.add(map);
                }
                beanLicitacion.lAprobaciones = la;
			}
            
        }catch(Exception ex){
            lista = null;
            ex.printStackTrace();
        }finally{
            cierraConexion(conn);
        }
        
		return lista;
	}

	public BeanLicitacion obtiene(String nl) {
		return obtiene(nl, true);
	}
	
	public BeanLicitacion obtiene(String nl, boolean ultimaOfertaLiberadaProveedor) {
		Connection conn = getConexion();
        try{
            PreparedStatement st = conn.prepareStatement(
        		"SELECT NUMERO_LICITACION, DESCRIPCION, FECHA_LIMITE, RESPONSABLE, CREADOR, ELEMENTO_PEP, "
        		+ "NOMBRE_ARCHIVO_BASES, NOMBRE_ARCHIVO_EVALUACION, ID_ARCHIVO_BASES, ID_ARCHIVO_EVALUACION, "
        		+ "TIPO, IMPORTE_ESTIMADO, ESTATUS, LIBERADOR_PT, FECHA_LIBERACION_PT, FECHA_EVALUACION,"
        		+ "LIBERADOR_PE_1, LIBERADOR_PE_2, FECHA_LIBERACION_PE, MENSAJE_ADJUDICACION, "
        		+ "ID_ARCHIVO_ACTA_RESULTADOS, PROVEEDOR_GANADOR, ID_ARCHIVO_RESULTADO, NOMBRE_ARCHIVO_RESULTADO, "
        		+ "MONEDA, PROVEEDOR_REASIGNADO, MENSAJE_REASIGNACION, NOMBRE_ARCHIVO_PRESUPUESTO, ID_ARCHIVO_PRESUPUESTO, FECHA_VISITA_OBRA,"
        		+ "ID_ARCHIVO_SOPORTE_ASIG, NOMBRE_ARCHIVO_SOPORTE_ASIG "
        		+ "FROM T_LICITACION "
        		+ "WHERE NUMERO_LICITACION = ?");
            st.setString(1, nl);
            ResultSet rs = st.executeQuery();
            
            if (rs.next()){
            	BeanLicitacion bean = new BeanLicitacion();
                bean.numeroLicitacion = rs.getString("NUMERO_LICITACION");
                bean.descripcion = rs.getString("DESCRIPCION");
                bean.fechaLimite = rs.getString("FECHA_LIMITE");
                bean.responsable = rs.getString("RESPONSABLE");
                bean.creador = rs.getString("CREADOR");
                bean.elementoPEP = rs.getString("ELEMENTO_PEP");
                bean.nombreArchivoBases = rs.getString("NOMBRE_ARCHIVO_BASES");
                bean.nombreArchivoEvaluacion = rs.getString("NOMBRE_ARCHIVO_EVALUACION");
                bean.idArchivoBases = rs.getString("ID_ARCHIVO_BASES");
                bean.idArchivoEvaluacion = rs.getString("ID_ARCHIVO_EVALUACION");
                bean.tipo = rs.getInt("TIPO");
                bean.importeEstimado = rs.getDouble("IMPORTE_ESTIMADO");
                bean.estatus = rs.getInt("ESTATUS");
                bean.liberadorPT = rs.getString("LIBERADOR_PT");
                bean.fechaLiberacionPT = rs.getString("FECHA_LIBERACION_PT");
                bean.fechaEvaluacion = rs.getString("FECHA_EVALUACION");
                bean.liberadorPE1 = rs.getString("LIBERADOR_PE_1");
                bean.liberadorPE2 = rs.getString("LIBERADOR_PE_2");
                bean.fechaLiberacionPE = rs.getString("FECHA_LIBERACION_PE");
                bean.mensajeAdjudicacion = rs.getString("MENSAJE_ADJUDICACION");
                bean.idArchivoActaResultados = rs.getString("ID_ARCHIVO_ACTA_RESULTADOS");
                bean.proveedorGanador = rs.getString("PROVEEDOR_GANADOR");
                bean.idArchivoResultados = rs.getString("ID_ARCHIVO_RESULTADO");
                bean.nombreArchivoResultados = rs.getString("NOMBRE_ARCHIVO_RESULTADO");
                bean.idArchivoSoporteAsignacion = rs.getString("ID_ARCHIVO_SOPORTE_ASIG");
                bean.nombreArchivoSoporteAsignacion = rs.getString("NOMBRE_ARCHIVO_SOPORTE_ASIG");
                
                bean.moneda = rs.getString("MONEDA");
                bean.proveedorReasignado = rs.getString("PROVEEDOR_REASIGNADO");
                bean.mensajeReasignacion = rs.getString("MENSAJE_REASIGNACION");
                bean.nombreArchivoPresupuesto = rs.getString("NOMBRE_ARCHIVO_PRESUPUESTO");
                bean.idArchivoPresupuesto = rs.getString("ID_ARCHIVO_PRESUPUESTO");
                bean.fechaVisitaObra = rs.getDate("FECHA_VISITA_OBRA") == null? null: dateFormatter.format(rs.getDate("FECHA_VISITA_OBRA"));

                DAOUsuario daou = new DAOUsuario();
        		HashMap<String, String> responsables = daou.listaNombres();
        		bean.nombreResponsable = responsables.get(bean.getResponsable());
        		bean.nombreCreador = responsables.get(bean.getCreador());


                // Proveedores
                st = conn.prepareStatement(
                		"select p.NUM_SAP, p.CORREO, p.NOMBRE, pl.CLAVE, p.RFC, "
                		+ "pl.ARCHIVO_PT, ARCHIVO_PE, ID_ARCHIVO_PT, ID_ARCHIVO_PE,"
                		+ "pl.IMPORTE, pl.LIBERADA, pl.FECHA_ENVIO, pl.ID, pl.ACTIVO "
                		+ "from T_PROV_LICITACION pl, T_PROVEEDOR p "
                		+ "where pl.NUM_SAP = p.NUM_SAP "
                		+ "and pl.NUMERO_LICITACION = ? "
                		+ "ORDER BY p.NUM_SAP, pl.ID desc ");
                st.setString(1, nl);
                rs = st.executeQuery();
                ArrayList lp = new ArrayList();
                while (rs.next()) {
                	HashMap map = new HashMap<>();
                	map.put("numeroSAP", rs.getString(1));
                	map.put("correo", rs.getString(2));
                	map.put("nombre", rs.getString(3));
                	map.put("clave", rs.getString(4));
                	map.put("rfc", rs.getString(5));
                	map.put("ARCHIVO_PT", rs.getString(6));
                	map.put("ARCHIVO_PE", rs.getString(7));
                	map.put("ID_ARCHIVO_PT", rs.getString(8));
                	map.put("ID_ARCHIVO_PE", rs.getString(9));
                	map.put("IMPORTE", rs.getDouble(10));
                	map.put("LIBERADA", rs.getBoolean(11));
                	map.put("NOLIBERADA", !rs.getBoolean(11));
                	map.put("ACTIVO", rs.getBoolean("ACTIVO"));
                	map.put("FECHA_ENVIO", rs.getTimestamp("FECHA_ENVIO") == null? "": dateTimeFormatter.format(rs.getTimestamp("FECHA_ENVIO")));
                	map.put("ID", rs.getInt("ID"));
            		map.put("NOT_LINEBREAK", true);
            		map.put("LINEBREAK", false);
                	lp.add(map);
                }
                ArrayList numerosSAP = new ArrayList();
                for (Iterator iterator = lp.iterator(); iterator.hasNext();) {
                	HashMap p = (HashMap) iterator.next();
                	if(!numerosSAP.contains(p.get("numeroSAP")))
                		numerosSAP.add(p.get("numeroSAP"));
                }
                ArrayList listaProveedores = new ArrayList();
                for (Iterator iteratorNS = numerosSAP.iterator(); iteratorNS.hasNext();) {
                	String ns = (String) iteratorNS.next();
                    ArrayList nestedLP = new ArrayList();
                	HashMap firstMap = null;
                	HashMap firstReleasedMap = null;
                    for (Iterator iterator = lp.iterator(); iterator.hasNext();) {
                    	HashMap p = (HashMap) iterator.next();
                    	if(ns.equals(p.get("numeroSAP"))) {
                    		if(firstMap == null)
                    			firstMap = p;
                    		if(firstReleasedMap == null && ((Boolean)p.get("LIBERADA")))
                    			firstReleasedMap = p;
                    		nestedLP.add(p);
                    	}
                    }
                    HashMap shallowCopy = null;
                    // Muestra la �ltima que se liber�
                	if(firstReleasedMap != null && ultimaOfertaLiberadaProveedor){
                		shallowCopy = (HashMap) firstReleasedMap.clone();
                	} else if(firstMap != null){
                		shallowCopy = (HashMap) firstMap.clone();
                	} else
                		continue;
                	shallowCopy.put("NOT_LINEBREAK", false);
                	shallowCopy.put("LINEBREAK", true);
                	shallowCopy.put("listaProveedores", nestedLP);
            		listaProveedores.add(shallowCopy);                    		
                	
                }

                bean.listaProveedores = listaProveedores;
                
                // Conceptos eval
                st = conn.prepareStatement(
                		"SELECT FASE ,CONCEPTO ,PORCENTAJE "
                		+ "FROM T_EVAL_LICITACION "
                		+ "where NUMERO_LICITACION = ?");
                st.setString(1, nl);
                rs = st.executeQuery();
                ArrayList lce = new ArrayList();
                while (rs.next()) {
                	HashMap map = new HashMap<>();
                	map.put("fase", rs.getLong(1));
                	map.put("concepto", rs.getString(2));
                	map.put("porcentaje", rs.getLong(3));
                	lce.add(map);
                }
                bean.lConceptosEvaluacion = lce;
                
                // Archivos Adicionales
                st = conn.prepareStatement(
                		"SELECT ID_ARCHIVO, NOMBRE_ARCHIVO "
                		+ "FROM T_ARCHIVOS_LICITACION "
                		+ "where NUMERO_LICITACION = ?");
                st.setString(1, nl);
                rs = st.executeQuery();
                ArrayList laa = new ArrayList();
                while (rs.next()) {
                	HashMap map = new HashMap<>();
                	map.put("id", rs.getString(1));
                	map.put("nombre", rs.getString(2));
                	laa.add(map);
                }
                bean.listaArchivosAdicionales = laa;
                
                // Resultados eval
                st = conn.prepareStatement(
                		"SELECT NUM_SAP                " +
        				"      ,FASE                   " +
        				"      ,CONCEPTO               " +
        				"      ,PORCENTAJE             " +
        				"      ,CALIFICACION           " +
        				"  FROM T_RES_EVAL_LICITACION  " +
        				" WHERE NUMERO_LICITACION = ? ");
                st.setString(1, nl);
                rs = st.executeQuery();
                ArrayList lre = new ArrayList();
                while (rs.next()) {
                	HashMap map = new HashMap<>();
                	map.put("numeroSAP", rs.getString(1));
                	map.put("fase", rs.getLong(2));
                	map.put("concepto", rs.getString(3));
                	map.put("porcentaje", rs.getLong(4));
                	map.put("calificacion", rs.getDouble(5));
                	lre.add(map);
                }
                for (Iterator iterator = bean.listaProveedores.iterator(); iterator.hasNext();) {
                	HashMap p = (HashMap) iterator.next();
                	boolean existenRE = false;
                    for (Iterator iteratorLRE = lre.iterator(); iteratorLRE.hasNext();) {
	                	HashMap re = (HashMap) iteratorLRE.next();
	                	if(re.get("numeroSAP").equals(p.get("numeroSAP"))) {
	                		existenRE = true;
	                		break;
	                	}
                    }
                    if(!existenRE)
		                for (Iterator ice = bean.lConceptosEvaluacion.iterator(); ice.hasNext();) {
		                	HashMap e = (HashMap) ice.next();
		                	HashMap map = new HashMap<>();
		                	map.put("numeroSAP", p.get("numeroSAP"));
		                	map.put("fase", (Long)e.get("fase"));
		                	map.put("concepto", e.get("concepto"));
		                	map.put("porcentaje", (Long)e.get("porcentaje"));
		                	map.put("calificacion", 0.0);
		                	lre.add(map);
						}
				}

//                // Primera vez que va a evaluar
//                if(lre.size() == 0) {
//	                for (Iterator iterator = bean.listaProveedores.iterator(); iterator.hasNext();) {
//	                	HashMap p = (HashMap) iterator.next();						
//		                for (Iterator ice = bean.lConceptosEvaluacion.iterator(); ice.hasNext();) {
//		                	HashMap e = (HashMap) ice.next();
//		                	HashMap map = new HashMap<>();
//		                	map.put("numeroSAP", p.get("numeroSAP"));
//		                	map.put("fase", (Long)e.get("fase"));
//		                	map.put("concepto", e.get("concepto"));
//		                	map.put("porcentaje", (Long)e.get("porcentaje"));
//		                	map.put("calificacion", 0.0);
//		                	lre.add(map);
//						}
//					}
//                }
                double montoGanador = -1;
                double calificacionGanador = -1;
                String proveedorPropuesto = null;
                int c = 0;
                for (HashMap<String, Object> pro : bean.listaProveedores) {
        			pro.put("ganador", bean.proveedorGanador != null && bean.proveedorGanador.equals(pro.get("numeroSAP")));
        			double t1 = getTotal(lre, (String) pro.get("numeroSAP"), 1);
        			pro.put("totalFase1", t1);
        			double t2 = getTotal(lre, (String) pro.get("numeroSAP"), 2);
        			pro.put("totalFase2", t2);
        			pro.put("total", t1 + t2);
        			pro.put("disponible", (t1 + t2) > 69);
        			double importe = Double.parseDouble(pro.get("IMPORTE")+"");
        			if((montoGanador < 0 && importe > 0 &&  (t1 + t2) > 69)|| 
        					(importe < montoGanador && importe > 0 &&  (t1 + t2) > 69) ||
        							(importe == montoGanador && Double.parseDouble(pro.get("total")+"") > calificacionGanador &&  (t1 + t2) > 69)){
        				montoGanador = importe;
        				proveedorPropuesto = (String) pro.get("numeroSAP");
        				calificacionGanador = t1 + t2;
        			}
                }
                bean.proveedorPropuesto = proveedorPropuesto;
                bean.lResultadosEvaluacion = lre;
                
                // Aprobaciones
                st = conn.prepareStatement(
                		"SELECT RESPONSABLE               " +
        				"      ,APRUEBA                   " +
        				"      ,MENSAJE                   " +
        				"      ,FECHA                     " +
        				"      ,ENVIADA                     " +
        				"  FROM T_APROBACIONES_LICITACION " +
        				" WHERE NUMERO_LICITACION = ? ");
                st.setString(1, nl);
                rs = st.executeQuery();
                ArrayList la = new ArrayList();
                while (rs.next()) {
                	HashMap map = new HashMap<>();
                	map.put("responsable", rs.getString(1));
                	map.put("aprueba", rs.getBoolean(2));
                	map.put("mensaje", rs.getString(3));
                	map.put("fecha", rs.getString(4));
                	map.put("enviada", rs.getBoolean(5));
                	la.add(map);
                }
                bean.lAprobaciones = la;
                
                // Log
                st = conn.prepareStatement(
                		"SELECT ESTATUS               " +
        				"      ,RESPONSABLE                   " +
        				"      ,ACCION                   " +
        				"      ,MENSAJE                     " +
        				"      ,FECHA,ID                     " +
        				"  FROM LOG_LICITACION " +
        				" WHERE NUMERO_LICITACION = ? order by ID");
                st.setString(1, nl);
                rs = st.executeQuery();
                ArrayList llog = new ArrayList();
                while (rs.next()) {
                	HashMap map = new HashMap<>();
                	map.put("estatus", rs.getInt(1));
                	map.put("responsable", rs.getString(2));
                	map.put("accion", rs.getString(3));
                	map.put("mensaje", rs.getString(4));
                	map.put("fecha", rs.getString(5));
                	llog.add(map);
                }
                bean.lMovimientos = llog;
                return bean;
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            cierraConexion(conn);
        }
        
		return null;
	}
	
	private double getTotal(ArrayList<HashMap<String, Object>> lResultadosEvaluacion, String proveedor, int fase) {
		float total = 0f;
		for (HashMap<String, Object> hashMap : lResultadosEvaluacion) {
			if(hashMap.get("numeroSAP").equals(proveedor)) 
				if(fase == 0 || fase == (Long) hashMap.get("fase"))
					total += (Double.parseDouble(hashMap.get("porcentaje")+"") / 5) * Double.parseDouble(hashMap.get("calificacion")+"");
		}
		return  total;
	}
	
	public int eliminaProveedores(BeanLicitacion bean, ArrayList<HashMap> listaProveedores) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
					"update T_PROV_LICITACION "
					+ "set ACTIVO = 0 "
					+ "where NUMERO_LICITACION = ? and NUM_SAP = ? " );
			for (Iterator iterator = listaProveedores.iterator(); iterator.hasNext();) {
				HashMap mapProveedor = (HashMap) iterator.next();
				st.setString(1, bean.numeroLicitacion);
				st.setString(2, (String)mapProveedor.get("numeroSAP"));
				st.addBatch();
			}
			st.executeBatch();
			st.close();
			return 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int agregaProveedores(BeanLicitacion bean, ArrayList<HashMap> listaProveedores) {
		Connection conn = getConexion();
		try {
//			PreparedStatement st = conn.prepareStatement(
//					"delete from T_PROV_LICITACION where NUMERO_LICITACION = ? and NUM_SAP = ? " );
//			for (Iterator iterator = listaProveedores.iterator(); iterator.hasNext();) {
//				HashMap mapProveedor = (HashMap) iterator.next();
//				st.setString(1, bean.numeroLicitacion);
//				st.setString(2, (String)mapProveedor.get("numeroSAP"));
//				st.addBatch();
//			}
//			st.executeBatch();
//			st.close();
//			PreparedStatement st2 = conn.prepareStatement(
//					"delete from T_RES_EVAL_LICITACION where NUMERO_LICITACION = ? and NUM_SAP = ? " );
//			for (Iterator iterator = listaProveedores.iterator(); iterator.hasNext();) {
//				HashMap mapProveedor = (HashMap) iterator.next();
//				st2.setString(1, bean.numeroLicitacion);
//				st2.setString(2, (String)mapProveedor.get("numeroSAP"));
//				st2.addBatch();
//			}
//			st2.executeBatch();
//			st2.close();

			PreparedStatement st, st2;
			st2 = conn.prepareStatement(
					"INSERT INTO T_PROV_LICITACION " +
					"           (NUMERO_LICITACION " +
					"           ,NUM_SAP           " +
					"           ,CLAVE,ACTIVO)            " +
					"     VALUES                   " +
					"           (?,?,?,1)          " );
			for (Iterator iterator = listaProveedores.iterator(); iterator.hasNext();) {
				HashMap mapProveedor = (HashMap) iterator.next();
				st2.setString(1, bean.numeroLicitacion);
				st2.setString(2, (String)mapProveedor.get("numeroSAP"));
				st2.setString(3, (String)mapProveedor.get("clave"));
				st2.addBatch();
			}
			st2.executeBatch();		
			st = conn.prepareStatement(
					"INSERT INTO T_RES_EVAL_LICITACION " +
					"           (NUMERO_LICITACION     " +
					"           ,NUM_SAP               " +
					"           ,FASE                  " +
					"           ,CONCEPTO              " +
					"           ,PORCENTAJE            " +
					"           ,CALIFICACION)         " +
					"     VALUES                       " +
					"           (?,?,?,?,?,?)          "  );
            for (Iterator iterator = listaProveedores.iterator(); iterator.hasNext();) {
            	HashMap p = (HashMap) iterator.next();						
                for (Iterator ice = bean.lConceptosEvaluacion.iterator(); ice.hasNext();) {
                	HashMap e = (HashMap) ice.next();
    				st.setString(1, bean.numeroLicitacion);
    				st.setString(2, p.get("numeroSAP").toString());
    				st.setInt(3, ((Long)e.get("fase")).intValue());
    				st.setString(4, (String)e.get("concepto"));
    				st.setInt(5, ((Long)e.get("porcentaje")).intValue());
    				st.setDouble(6, 0);
    				st.addBatch();
				}
			}
			st.executeBatch();
            
			return 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			if(ex.getMessage().indexOf("PRIMARY KEY") > 0)
				return -5;
			else
				return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int crea(BeanLicitacion bean, boolean nueva) {
		Connection conn = getConexion();
		try {
			PreparedStatement st;
			if(!nueva) {
				st = conn.prepareStatement(
						"delete from T_LICITACION where NUMERO_LICITACION = ?");
				st.setString(1, bean.numeroLicitacion);
				st.executeUpdate();
				st = conn.prepareStatement(
						"delete from T_ARCHIVOS_LICITACION where NUMERO_LICITACION = ?");
				st.setString(1, bean.numeroLicitacion);
				st.executeUpdate();
				st = conn.prepareStatement(
						"delete from T_EVAL_LICITACION where NUMERO_LICITACION = ?");
				st.setString(1, bean.numeroLicitacion);
				st.executeUpdate();
				st = conn.prepareStatement(
						"delete from T_PROV_LICITACION where NUMERO_LICITACION = ?");
				st.setString(1, bean.numeroLicitacion);
				st.executeUpdate();
			}

			st = conn.prepareStatement(
				"INSERT INTO T_LICITACION "
				+ "(NUMERO_LICITACION, DESCRIPCION, FECHA_LIMITE, RESPONSABLE, ELEMENTO_PEP, NOMBRE_ARCHIVO_BASES, "
				+ " NOMBRE_ARCHIVO_EVALUACION, ID_ARCHIVO_BASES, ID_ARCHIVO_EVALUACION, TIPO, IMPORTE_ESTIMADO, ESTATUS,"
				+ " CREADOR, MONEDA, FECHA_VISITA_OBRA, NOMBRE_ARCHIVO_PRESUPUESTO, ID_ARCHIVO_PRESUPUESTO) "
				+ "VALUES "
				+ "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)");
			st.setString(1, bean.numeroLicitacion);
			st.setString(2, bean.descripcion);
			st.setString(3, bean.fechaLimite);
			st.setString(4, bean.responsable);
			st.setString(5, bean.elementoPEP);
			st.setString(6, bean.nombreArchivoBases);
			st.setString(7, bean.nombreArchivoEvaluacion);
			st.setString(8, bean.idArchivoBases);
			st.setString(9, bean.idArchivoEvaluacion);
			st.setInt(10, bean.tipo);
			st.setDouble(11, bean.importeEstimado);
			st.setString(12, bean.creador);
			st.setString(13, bean.moneda);
			try {
				st.setDate(14, bean.fechaVisitaObra != null? new java.sql.Date(dateFormatter.parse(bean.fechaVisitaObra).getTime()): null);
			} catch (Exception e) {
				st.setDate(14, null);
			}
			st.setString(15, bean.nombreArchivoPresupuesto);
			st.setString(16, bean.idArchivoPresupuesto);
			int ok = st.executeUpdate();

			// Conceptos de Evaluaci�n
			st = conn.prepareStatement(
					"INSERT INTO T_EVAL_LICITACION "
					+ "(NUMERO_LICITACION, FASE, CONCEPTO, PORCENTAJE) "
					+ "VALUES "
					+ "(?, ?, ?, ?)");
			for (Iterator iterator = bean.lConceptosEvaluacion.iterator(); iterator.hasNext();) {
				HashMap mapConceptoEval = (HashMap) iterator.next();
				int valor = ((Long)mapConceptoEval.get("valor")).intValue();
				if(valor == 0)
					continue;
				st.setString(1, bean.numeroLicitacion);
				st.setInt(2, ((Long)mapConceptoEval.get("fase")).intValue());
				st.setString(3, (String)mapConceptoEval.get("concepto"));
				st.setInt(4, valor);
				st.addBatch();
			}
			st.executeBatch();
			
			// Proveedores
			st = conn.prepareStatement(
				"INSERT INTO T_PROV_LICITACION " +
				"           (NUMERO_LICITACION " +
				"           ,NUM_SAP           " +
				"           ,CLAVE,ACTIVO)            " +
				"     VALUES                   " +
				"           (?,?,?,1)          " );
			for (Iterator iterator = bean.listaProveedores.iterator(); iterator.hasNext();) {
				HashMap mapProveedor = (HashMap) iterator.next();
				st.setString(1, bean.numeroLicitacion);
				st.setString(2, (String)mapProveedor.get("numeroSAP"));
				st.setString(3, Util.generaPassword());
				st.addBatch();
			}
			st.executeBatch();
			
			// Archivos Adicionales
			if(bean.listaArchivosAdicionales != null) {
				st = conn.prepareStatement(
						"INSERT INTO T_ARCHIVOS_LICITACION " +
						"           (NUMERO_LICITACION " +
						"           ,ID_ARCHIVO        " +
						"           ,NOMBRE_ARCHIVO)   " +
						"     VALUES                   " +
						"           (?,?,?)          " );
				for (Iterator iterator = bean.listaArchivosAdicionales.iterator(); iterator.hasNext();) {
					HashMap mapAA = (HashMap) iterator.next();
					st.setString(1, bean.numeroLicitacion);
					st.setString(2, (String)mapAA.get("id"));
					st.setString(3, (String)mapAA.get("nombre"));
					st.addBatch();
				}
				st.executeBatch();
			}
			
			return 1;
		} catch (Exception ex) {
			System.err.println("Exception: " + bean.numeroLicitacion + " Nueva: " + nueva + " @ " + new Date());
			ex.printStackTrace();
			if(ex.getMessage().indexOf("PRIMARY KEY") > 0)
				return -5;
			else
				return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int actualiza(BeanLicitacion bean) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_LICITACION                 " +
				"   SET DESCRIPCION                  = ?" +
				"      ,FECHA_LIMITE                 = ?" +
				"      ,RESPONSABLE                  = ?" +
				"      ,ELEMENTO_PEP                 = ?" +
				"      ,NOMBRE_ARCHIVO_BASES         = ?" +
				"      ,NOMBRE_ARCHIVO_EVALUACION    = ?" +
				"      ,ID_ARCHIVO_BASES             = ?" +
				"      ,ID_ARCHIVO_EVALUACION        = ?" +
				"      ,TIPO                         = ?" +
				"      ,IMPORTE_ESTIMADO             = ?" +
				"      ,ESTATUS          		     = ?" +
			    "      ,LIBERADOR_PT                 = ?" +
			    "      ,FECHA_LIBERACION_PT          = ?" +
			    "      ,FECHA_EVALUACION             = ?" +
			    "      ,LIBERADOR_PE_1               = ?" +
			    "      ,LIBERADOR_PE_2               = ?" +
			    "      ,FECHA_LIBERACION_PE          = ?" +
			    "      ,MENSAJE_ADJUDICACION         = ?" +
			    "      ,ID_ARCHIVO_ACTA_RESULTADOS   = ?" +
			    "      ,PROVEEDOR_GANADOR            = ?" +
			    "      ,ID_ARCHIVO_RESULTADO         = ?" +
			    "      ,NOMBRE_ARCHIVO_RESULTADO     = ?" +

			    "      ,MONEDA                       = ?" +
			    "      ,PROVEEDOR_REASIGNADO         = ?" +
			    "      ,MENSAJE_REASIGNACION         = ?" +
			    "      ,NOMBRE_ARCHIVO_PRESUPUESTO   = ?" +
			    "      ,ID_ARCHIVO_PRESUPUESTO       = ?" +
			    "      ,FECHA_VISITA_OBRA            = ?" +
				" WHERE NUMERO_LICITACION            = ?" );

			st.setString(1, bean.descripcion);
			st.setString(2, bean.fechaLimite);
			st.setString(3, bean.responsable);
			st.setString(4, bean.elementoPEP);
			st.setString(5, bean.nombreArchivoBases);
			st.setString(6, bean.nombreArchivoEvaluacion);
			st.setString(7, bean.idArchivoBases);
			st.setString(8, bean.idArchivoEvaluacion);
			st.setInt(9, bean.tipo);
			st.setDouble(10, bean.importeEstimado);
			st.setInt(11, bean.estatus);
			st.setString(12, bean.liberadorPT);
			st.setString(13, bean.fechaLiberacionPT);
			st.setString(14, bean.fechaEvaluacion);
			st.setString(15, bean.liberadorPE1);
			st.setString(16, bean.liberadorPE2);
			st.setString(17, bean.fechaLiberacionPE);
			st.setString(18, bean.mensajeAdjudicacion);
			st.setString(19, bean.idArchivoActaResultados);
			st.setString(20, bean.proveedorGanador);
			st.setString(21, bean.idArchivoResultados);
			st.setString(22, bean.nombreArchivoResultados);

			st.setString(23, bean.moneda);
			st.setString(24, bean.proveedorReasignado);
			st.setString(25, bean.mensajeReasignacion);
			st.setString(26, bean.nombreArchivoPresupuesto);
			st.setString(27, bean.idArchivoPresupuesto);
			st.setDate(28, bean.fechaVisitaObra != null? new java.sql.Date(dateFormatter.parse(bean.fechaVisitaObra).getTime()): null);
			
			st.setString(29, bean.numeroLicitacion);

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int cambiaEstatus(String nl, int estatus) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_LICITACION                 " +
				"   SET ESTATUS			          = ?" +
				" WHERE NUMERO_LICITACION         = ?" );

			st.setInt(1, estatus);
			st.setString(2, nl);

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
	
	public int liberaPropuestaEconomica(String nl, ArrayList<Map> listaProv) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_PROV_LICITACION            " +
				"   SET LIBERADA			      = ?" +
				" WHERE ID = ?" );
			
			for (Map map : listaProv) 
				for (Map map2 : (ArrayList<Map>)map.get("listaProveedores")) {
					st.setBoolean(1, (boolean) map2.get("LIBERADA"));
					st.setInt(2, ((Long) map2.get("ID")).intValue());
					st.addBatch();
				}
			int ok = st.executeBatch().length;
			
//			Email.mensajeBaseProveedor(l, "Se le informa que su propuesta ha sido aceptada", abajo)
			
			return ok;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int actualizaPonderacion(String nl, ArrayList<Map> lConceptosEvaluacion) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_EVAL_LICITACION " +
				"   SET PORCENTAJE		  = ?" +
				" WHERE NUMERO_LICITACION = ? "
				+ " and FASE              = ? "
				+ " and CONCEPTO          = ?" );
			
			for (Map map : lConceptosEvaluacion) {
				st.setInt(1, ((Long) map.get("porcentaje")).intValue());
				st.setString(2, nl);
				st.setInt(3, ((Long) map.get("fase")).intValue());
				st.setString(4, (String) map.get("concepto"));
				st.addBatch();
			}
			int ok = st.executeBatch().length;

			st = conn.prepareStatement(
					"UPDATE T_RES_EVAL_LICITACION " +
					"   SET PORCENTAJE		  = ?" +
					" WHERE NUMERO_LICITACION = ? "
					+ " and FASE              = ? "
					+ " and CONCEPTO          = ?" );
				
			for (Map map : lConceptosEvaluacion) {
				st.setInt(1, ((Long) map.get("porcentaje")).intValue());
				st.setString(2, nl);
				st.setInt(3, ((Long) map.get("fase")).intValue());
				st.setString(4, (String) map.get("concepto"));
				st.addBatch();
			}
			ok = st.executeBatch().length;

			return ok;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int guardaAprobaciones(String nl, String descripcion, String creador, String solicitante, boolean incluyeDG, String contextPath) {
		ArrayList<String> la = new ArrayList<String>();
		la.add(creador);
//		la.add(solicitante); Se quita, solicitado 20161004
		String dg = "";
		DAOUsuario du = new DAOUsuario();
		DAOLicitacion dl = new DAOLicitacion();
		BeanLicitacion l = dl.obtiene(nl);
		HashMap<String, String> correos = new HashMap<String, String>();
		ArrayList<BeanUsuario> lu = du.obtenUsuarios();
		for (BeanUsuario beanUsuario : lu) {
			correos.put(beanUsuario.usuario, beanUsuario.correo);
			if(beanUsuario.usuario.equals(l.responsable) && !la.contains(beanUsuario.usuario)) {
				la.add(beanUsuario.usuario);
				if(beanUsuario.jefe != null && !beanUsuario.jefe.equals("") && !la.contains(beanUsuario.jefe))
					la.add(beanUsuario.jefe);
			}
			if(beanUsuario.comite && !la.contains(beanUsuario.usuario))
				la.add(beanUsuario.usuario);
			if(incluyeDG && beanUsuario.directorGeneral && !la.contains(beanUsuario.usuario)) {
				la.add(beanUsuario.usuario);
				dg = beanUsuario.usuario;
			}
		}
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
					"delete from T_APROBACIONES_LICITACION where NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();
			st = conn.prepareStatement(
					"INSERT INTO T_APROBACIONES_LICITACION" +
							"           (NUMERO_LICITACION        " +
							"           ,RESPONSABLE              " +
							"           ,ENVIADA)                   " +
							"     VALUES                          " +
							"           (?,?,?)               " );
			for (String aprobador : la) {
				if(aprobador == null)
					continue;
				st.setString(1, nl);
				st.setString(2, aprobador);
				st.setBoolean(3, false);
				st.addBatch();
			}
			st.executeBatch();
			
			String mensajeCorreo = l.proveedorReasignado != null 
					? Email.mensajeBase(l, "La siguiente licitaci�n ha sido reasignada",
							"Favor de proceder con la aprobaci�n de la licitaci�n para continuar con el proceso.<br>Mensaje de justificaci�n: "
									+ l.mensajeReasignacion,
							false, contextPath)
					: Email.mensajeBase(l,
							"Las propuestas t�cnicas y econ�micas de la siguiente licitaci�n han sido revisadas durante el Comit� de Apertura Econ�mica.",
							"Favor de proceder con la aprobaci�n de la licitaci�n para continuar con el proceso.",
							false, contextPath);
			for (String aprobador : la) {
				if(!dg.equals(aprobador))
					Email.enviarCorreo(contextPath, 
							correos.get(aprobador), 
							"Licitaci�n lista para aprobaci�n", 
							mensajeCorreo, null, null);
			}
			
			return 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
	
	public int borraLicitacion(String nl) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
					"delete from T_APROBACIONES_LICITACION where NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();
			st = conn.prepareStatement(
					"delete from T_ARCHIVOS_LICITACION where NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();
			st = conn.prepareStatement(
					"delete from T_EVAL_LICITACION where NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();
			st = conn.prepareStatement(
					"delete from T_LICITACION where NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();
			st = conn.prepareStatement(
					"delete from T_PROV_LICITACION where NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();
			st = conn.prepareStatement(
					"delete from T_RES_EVAL_LICITACION where NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();

			return 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int guardaAprobacion(String nl, String responsable, boolean aprueba, String mensaje) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
					"UPDATE T_APROBACIONES_LICITACION " +
							"   SET ENVIADA = 1               " +
							"      ,APRUEBA = ?               " +
							"      ,MENSAJE = ?               " +
							"      ,FECHA   = ?               " +
							" WHERE NUMERO_LICITACION = ? and  RESPONSABLE = ? " );
			st.setBoolean(1, aprueba);
			st.setString(2, mensaje);
			st.setString(3, dateFormatter.format(new Date()));
			st.setString(4, nl);
			st.setString(5, responsable);

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
	
	public boolean licitacionAprobada(String nl) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
					"select count(RESPONSABLE), "
					+ "sum(CONVERT(int,enviada)), "
					+ "sum(CONVERT(int,COALESCE(APRUEBA,0))) "
					+ "from T_APROBACIONES_LICITACION " +
					" WHERE NUMERO_LICITACION = ? " );
			st.setString(1, nl);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				int total = rs.getInt(1);
				int enviadas = rs.getInt(2);
				int aprobadas = rs.getInt(3);
				return total == enviadas && total == aprobadas;
			}

			return false;

		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		} finally {
			cierraConexion(conn);
		}
	}

	public int log(String nl, String responsable, int estatus, String accion, String mensaje) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
					"INSERT INTO LOG_LICITACION    " +
							"           (NUMERO_LICITACION " +
							"           ,ESTATUS           " +
							"           ,RESPONSABLE       " +
							"           ,ACCION            " +
							"           ,FECHA             " +
							"           ,MENSAJE)          " +
							"     VALUES                   " +
							"           (?,?,?,?,?,?)          " );
			st.setString(1, nl);
			st.setInt(2, estatus);
			st.setString(3, responsable);
			st.setString(4, accion);
			st.setString(5, dateTimeFormatter.format(new Date()));
			st.setString(6, mensaje != null && mensaje.length() > 7999? mensaje.substring(0,7998): mensaje);

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int guardaPropuesta(String nl, int id, 
			String nombrePropuestaTecnica, String idPropuestaTecnica,
			String nombrePropuestaEconomica, String idPropuestaEconomica,
			double importe) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
					"select " +
					"       NUM_SAP            " +
					"      ,CLAVE              " +
					"      ,ARCHIVO_PT         " +
					"      ,ARCHIVO_PE         " +
					"      ,ID_ARCHIVO_PT      " +
					"      ,ID_ARCHIVO_PE      " +
					"      ,IMPORTE            " +
					"      ,FECHA_ENVIO  " +
					"FROM T_PROV_LICITACION     " +
					"WHERE ID = ? and NUMERO_LICITACION = ? ");
			st.setInt(1, id);
			st.setString(2, nl);
			ResultSet rs = st.executeQuery();
			
			String numSAP = null, clave = null;
			boolean firstTime = true;
			if(rs.next()) {
				numSAP = rs.getString("NUM_SAP");
				clave = rs.getString("CLAVE");
				firstTime = rs.getDouble("IMPORTE") == 0 || rs.getString("ID_ARCHIVO_PT") == null || rs.getString("ID_ARCHIVO_PT").length() == 0;
			}
			
			if(firstTime) {
				st = conn.prepareStatement(
						"UPDATE T_PROV_LICITACION     " +
						"   SET ARCHIVO_PT = ?        " +
						"      ,ARCHIVO_PE = ?        " +
						"      ,ID_ARCHIVO_PT = ?     " +
						"      ,ID_ARCHIVO_PE = ?     " +
						"      ,IMPORTE = ?           " +
						"      ,FECHA_ENVIO = GETDATE() " +
						" WHERE ID = ? and NUMERO_LICITACION = ? ");
				st.setString(1, nombrePropuestaTecnica);
				st.setString(2, nombrePropuestaEconomica);
				st.setString(3, idPropuestaTecnica);
				st.setString(4, idPropuestaEconomica);
				st.setDouble(5, importe);
				st.setInt(6, id);
				st.setString(7, nl);
			}
			else {
				st = conn.prepareStatement(
						"INSERT INTO T_PROV_LICITACION " +
								"   (NUMERO_LICITACION " +
								"   ,NUM_SAP           " +
								"   ,CLAVE" +
								"   ,ARCHIVO_PT         " +
								"   ,ARCHIVO_PE         " +
								"   ,ID_ARCHIVO_PT      " +
								"   ,ID_ARCHIVO_PE      " +
								"   ,IMPORTE            " +
								"   ,FECHA_ENVIO        " +
								"   ,LIBERADA   ) " +
								"     VALUES                   " +
								"           (?,?,?,?,?,?,?,?,GETDATE(),0)  " );
				st.setString(1, nl);
				st.setString(2, numSAP);
				st.setString(3, clave);
				st.setString(4, nombrePropuestaTecnica);
				st.setString(5, nombrePropuestaEconomica);
				st.setString(6, idPropuestaTecnica);
				st.setString(7, idPropuestaEconomica);
				st.setDouble(8, importe);
			}

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int guardaResultadosEvaluacion(String nl, ArrayList<HashMap> resultados) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"DELETE FROM T_RES_EVAL_LICITACION " +
					" WHERE NUMERO_LICITACION = ?" );
			st.setString(1, nl);
			st.executeUpdate();
//					" WHERE NUMERO_LICITACION = ? and NUM_SAP = ? " );
//			for (Iterator iterator = resultados.iterator(); iterator.hasNext();) {
//				HashMap map = (HashMap) iterator.next();
//				st.setString(1, nl);
//				st.setString(2, (String)map.get("numeroSAP"));
//				st.addBatch();
//			}
//			st.executeBatch();
			
			st = conn.prepareStatement(
					"INSERT INTO T_RES_EVAL_LICITACION " +
					"           (NUMERO_LICITACION     " +
					"           ,NUM_SAP               " +
					"           ,FASE                  " +
					"           ,CONCEPTO              " +
					"           ,PORCENTAJE            " +
					"           ,CALIFICACION)         " +
					"     VALUES                       " +
					"           (?,?,?,?,?,?)          "  );
			for (Iterator iterator = resultados.iterator(); iterator.hasNext();) {
				HashMap map = (HashMap) iterator.next();
				st.setString(1, nl);
				st.setString(2, (String)map.get("numeroSAP"));
				st.setInt(3, ((Long)map.get("fase")).intValue());
				st.setString(4, (String)map.get("concepto"));
				st.setInt(5, ((Long)map.get("porcentaje")).intValue());
				st.setDouble(6, Double.parseDouble(map.get("calificacion") + ""));
				st.addBatch();
			}
			st.executeBatch();

			return 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
	
}
