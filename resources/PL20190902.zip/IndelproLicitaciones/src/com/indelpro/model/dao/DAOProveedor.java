package com.indelpro.model.dao;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.indelpro.model.BeanProveedor;

public class DAOProveedor extends DAO {

	public BeanProveedor obtenProveedor(String numeroSAP) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn
					.prepareStatement("SELECT NUM_SAP, RFC, CORREO, NOMBRE, NOTAS "
							+ "FROM T_PROVEEDOR "
							+ "WHERE NUM_SAP = ?");
			st.setString(1, numeroSAP);
			ResultSet rs = st.executeQuery();

			if (rs.next()) {
				BeanProveedor dProv = new BeanProveedor();
				dProv.setNumeroSAP(rs.getString("NUM_SAP"));
				dProv.setRfc(rs.getString("RFC"));
				dProv.setNombre(rs.getString("NOMBRE"));
				dProv.setCorreo(rs.getString("CORREO"));
				dProv.setNotas(rs.getString("NOTAS"));
				return dProv;
			}

			return null;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		} finally {
			cierraConexion(conn);
		}
		
	}
	
	public BeanProveedor obtenProveedorPorRFC(String rfc) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn
					.prepareStatement("SELECT NUM_SAP, RFC, CORREO, NOMBRE, NOTAS "
							+ "FROM T_PROVEEDOR "
							+ "WHERE RFC = ?");
			st.setString(1, rfc);
			ResultSet rs = st.executeQuery();

			if (rs.next()) {
				BeanProveedor dProv = new BeanProveedor();
				dProv.setNumeroSAP(rs.getString("NUM_SAP"));
				dProv.setRfc(rs.getString("RFC"));
				dProv.setNombre(rs.getString("NOMBRE"));
				dProv.setCorreo(rs.getString("CORREO"));
				dProv.setNotas(rs.getString("NOTAS"));
				return dProv;
			}

			return null;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		} finally {
			cierraConexion(conn);
		}
		
	}

	public List<Map> listaProveedores() {
		ArrayList<BeanProveedor> lProv = null;

		Connection conn = getConexion();
		try {
			PreparedStatement st = conn
					.prepareStatement("SELECT NUM_SAP, RFC, CORREO, NOMBRE, NOTAS " + "  FROM T_PROVEEDOR");
			ResultSet rs = st.executeQuery();

			lProv = new ArrayList<BeanProveedor>();
			while (rs.next()) {
				BeanProveedor dProv = new BeanProveedor();
				dProv.setNumeroSAP(rs.getString("NUM_SAP"));
				dProv.setRfc(rs.getString("RFC"));
				dProv.setNombre(rs.getString("NOMBRE"));
				dProv.setCorreo(rs.getString("CORREO"));
				dProv.setNotas(rs.getString("NOTAS"));
				lProv.add(dProv);
			}

		} catch (Exception ex) {
			lProv = null;
			ex.printStackTrace();
		} finally {
			cierraConexion(conn);
		}

		List<Map> provs = new ArrayList<Map>();
		Field[] fields = BeanProveedor.class.getFields();
		for (Iterator iterator = lProv.iterator(); iterator.hasNext();) {
			BeanProveedor bu = (BeanProveedor) iterator.next();
			Map<String, Object> pro = new HashMap<String, Object>();
			for (Field field : fields) {
				try {
					pro.put(field.getName(), field.get(bu));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					e.printStackTrace();
				}

			}
			provs.add(pro);
		}

		return provs;
	}

	public int crear(BeanProveedor bp) {
		Connection conn = getConexion();
		if(obtenProveedor(bp.numeroSAP) != null || obtenProveedorPorRFC(bp.rfc) != null)
			return -5;
		
		try {
			PreparedStatement st = conn.prepareStatement(
				"INSERT INTO T_PROVEEDOR"
				+ " (NUM_SAP,RFC,CORREO,NOMBRE,NOTAS)"
				+ " VALUES" + "	(?, ?, ?, ?, ?)");

			st.setString(1, bp.getNumeroSAP());
			st.setString(2, bp.getRfc());
			st.setString(3, bp.getCorreo());
			st.setString(4, bp.getNombre());
			st.setString(5, bp.getNotas());

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int actualizar(BeanProveedor bp) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_PROVEEDOR"
				+ "   SET RFC = ?, CORREO = ?, NOMBRE = ?, NOTAS = ? "
				+ "WHERE NUM_SAP = ?");

			st.setString(1, bp.getRfc());
			st.setString(2, bp.getCorreo());
			st.setString(3, bp.getNombre());
			st.setString(4, bp.getNotas());
			st.setString(5, bp.getNumeroSAP());

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
	
	public int actualizaEmail(String numSAP, String email) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_PROVEEDOR"
				+ "   SET CORREO = ? "
				+ "WHERE NUM_SAP = ?");

			st.setString(1, email);
			st.setString(2, numSAP);

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
}
