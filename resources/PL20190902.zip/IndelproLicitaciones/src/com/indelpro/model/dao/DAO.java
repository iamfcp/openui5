package com.indelpro.model.dao;

import javax.sql.DataSource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DAO {

	private static DataSource ds = null;
	static {
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			ds = (DataSource) envContext.lookup("jdbc/DB_LICITACIONES");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Connection getConexion() {
		try {
			Connection conn = ds.getConnection();
			if (!conn.isClosed())
				return conn;
			else
				return ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
//			return null;
			Properties connectionProps = new Properties();
		    connectionProps.put("user", "SQLAPPUSER");
		    connectionProps.put("password", "invsapur#2089");
		    Connection conn = null;
			try {
				conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=INDELPRO",
						connectionProps);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		    return conn;
		}
	}

	public void cierraConexion(Connection conn) {
		try {
			conn.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
