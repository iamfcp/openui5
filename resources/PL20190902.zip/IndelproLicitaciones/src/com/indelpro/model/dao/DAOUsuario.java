package com.indelpro.model.dao;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.indelpro.model.BeanProveedor;
import com.indelpro.model.BeanUsuario;

public class DAOUsuario extends DAO {

	public ArrayList<BeanUsuario> obtenUsuarios() {
		ArrayList<BeanUsuario> listaUsuarios = null;
        
		Connection conn = getConexion();
        try{
            PreparedStatement st = conn.prepareStatement(
        		"SELECT USUARIO, ACTIVO, NOMBRE, DEPARTAMENTO, CORREO, LIBERA_PT, LIBERA_PE, "
        		+ "COMITE, ABASTECIMIENTOS, EVAL_TECNICO, DIRECTOR_GENERAL, JEFE"
        		+ "  FROM T_USUARIO");
            ResultSet rs = st.executeQuery();
            
            listaUsuarios = new ArrayList<BeanUsuario>();
            while (rs.next()){
            	BeanUsuario datosUsuario = new BeanUsuario();
                datosUsuario.setUsuario(rs.getString("USUARIO"));
                datosUsuario.setJefe(rs.getString("JEFE"));
                datosUsuario.setActivo(rs.getBoolean("ACTIVO"));
                datosUsuario.setNombre(rs.getString("NOMBRE"));
                datosUsuario.setDepartamento(rs.getString("DEPARTAMENTO"));
                datosUsuario.setCorreo(rs.getString("CORREO"));
                datosUsuario.setLiberaPT(rs.getBoolean("LIBERA_PT"));
                datosUsuario.setLiberaPE(rs.getBoolean("LIBERA_PE"));
                datosUsuario.setComite(rs.getBoolean("COMITE"));
                datosUsuario.setAbastecimientos(rs.getBoolean("ABASTECIMIENTOS"));
                datosUsuario.setEvalTecnico(rs.getBoolean("EVAL_TECNICO"));
                datosUsuario.setDirectorGeneral(rs.getBoolean("DIRECTOR_GENERAL"));
                listaUsuarios.add(datosUsuario);
            }
            
        }catch(Exception ex){
            listaUsuarios = null;
            ex.printStackTrace();
        }finally{
            cierraConexion(conn);
        }
        
        return listaUsuarios;
	}
	
	public HashMap<String, String> listaNombres() {
		ArrayList<BeanUsuario> listaUsuarios = obtenUsuarios();
		HashMap<String, String> nombres = new HashMap<>();
        for (Iterator iterator = listaUsuarios.iterator(); iterator.hasNext();) {
			BeanUsuario bu = (BeanUsuario) iterator.next();
        	nombres.put(bu.usuario, bu.nombre);
        }
        return nombres;
	}
	
	public List<Map> lista() {
		ArrayList<BeanUsuario> listaUsuarios = obtenUsuarios();

		List<Map> usuarios = new ArrayList<Map>();
		Field[] fields = BeanUsuario.class.getFields();
        for (Iterator iterator = listaUsuarios.iterator(); iterator.hasNext();) {
			BeanUsuario bu = (BeanUsuario) iterator.next();
			Map<String, Object> usr = new HashMap<String, Object>(); 
			for (Field field : fields) {
				try {
					usr.put(field.getName(), field.get(bu));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					e.printStackTrace();
				}
				
			}
			usuarios.add(usr);
		}
		
		return usuarios;
	}
	
	public BeanUsuario obtenUsuario(String usuario) {
		Connection conn = getConexion();
        try{
            PreparedStatement st = conn.prepareStatement(
        		"SELECT USUARIO, ACTIVO, NOMBRE, DEPARTAMENTO, CORREO, LIBERA_PT, LIBERA_PE, "
        		+ "COMITE, ABASTECIMIENTOS, EVAL_TECNICO, HASH, HASHL, SALT, DIRECTOR_GENERAL, JEFE "
        		+ "  FROM T_USUARIO"
        		+ "  WHERE USUARIO COLLATE Latin1_General_CS_AI = ?");
            st.setString(1, usuario);
            ResultSet rs = st.executeQuery();
            
        	BeanUsuario datosUsuario = new BeanUsuario();
            if (rs.next()){
                datosUsuario.setUsuario(rs.getString("USUARIO"));
                datosUsuario.setJefe(rs.getString("JEFE"));
                datosUsuario.setActivo(rs.getBoolean("ACTIVO"));
                datosUsuario.setNombre(rs.getString("NOMBRE"));
                datosUsuario.setDepartamento(rs.getString("DEPARTAMENTO"));
                datosUsuario.setCorreo(rs.getString("CORREO"));
                datosUsuario.setLiberaPT(rs.getBoolean("LIBERA_PT"));
                datosUsuario.setLiberaPE(rs.getBoolean("LIBERA_PE"));
                datosUsuario.setComite(rs.getBoolean("COMITE"));
                datosUsuario.setAbastecimientos(rs.getBoolean("ABASTECIMIENTOS"));
                datosUsuario.setEvalTecnico(rs.getBoolean("EVAL_TECNICO"));
                datosUsuario.setHash(rs.getString("HASH"));
                datosUsuario.setHashl(rs.getString("HASHL"));
                datosUsuario.setSalt(rs.getString("SALT"));
                datosUsuario.setDirectorGeneral(rs.getBoolean("DIRECTOR_GENERAL"));
                return datosUsuario;
            }
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            cierraConexion(conn);
        }      
		return null;
	}

	public int insertaUsuario(BeanUsuario bdu) {

		Connection conn = getConexion();
		try {

			PreparedStatement st = conn.prepareStatement(
				"INSERT INTO T_USUARIO "
				+ "(USUARIO, ACTIVO, NOMBRE, DEPARTAMENTO, CORREO, LIBERA_PT, LIBERA_PE, COMITE, "
				+ " ABASTECIMIENTOS, EVAL_TECNICO, DIRECTOR_GENERAL, JEFE) "
				+ "VALUES "
				+ "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			st.setString(1, bdu.getUsuario());
			st.setBoolean(2,bdu.getActivo());
			st.setString(3, bdu.getNombre());
			st.setString(4, bdu.getDepartamento());
			st.setString(5, bdu.getCorreo());
			st.setBoolean(6, bdu.getLiberaPT());
			st.setBoolean(7, bdu.getLiberaPE());
			st.setBoolean(8, bdu.getComite());
			st.setBoolean(9, bdu.getAbastecimientos());
			st.setBoolean(10, bdu.getEvalTecnico());
			st.setBoolean(11, bdu.getDirectorGeneral());
			st.setString(12, bdu.getJefe());

			return st.executeUpdate();
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}

	public int actualizar(BeanUsuario bu) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_USUARIO"
				+ "   SET ACTIVO =           ?"
				+ "      ,NOMBRE =           ?"
				+ "      ,DEPARTAMENTO =     ?"
				+ "      ,CORREO =           ?"
				+ "      ,LIBERA_PT =        ?"
				+ "      ,LIBERA_PE =        ?"
				+ "      ,COMITE =           ?"
				+ "      ,ABASTECIMIENTOS =  ?"
				+ "      ,EVAL_TECNICO =     ?"
				+ "      ,DIRECTOR_GENERAL = ?"
				+ "      ,JEFE =             ?"
				+ " WHERE USUARIO =          ?");

			st.setBoolean(1, bu.getActivo());
			st.setString(2, bu.getNombre());
			st.setString(3, bu.getDepartamento());
			st.setString(4, bu.getCorreo());
			st.setBoolean(5, bu.getLiberaPT());
			st.setBoolean(6, bu.getLiberaPE());
			st.setBoolean(7, bu.getComite());
			st.setBoolean(8, bu.getAbastecimientos());
			st.setBoolean(9, bu.getEvalTecnico());
			st.setBoolean(10, bu.getDirectorGeneral());
			st.setString(11, bu.getJefe());
			st.setString(12, bu.getUsuario());

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
	
	public int actualizarCompleto(BeanUsuario bu) {
		Connection conn = getConexion();
		try {
			PreparedStatement st = conn.prepareStatement(
				"UPDATE T_USUARIO"
				+ "   SET ACTIVO =           ?"
				+ "      ,NOMBRE =           ?"
				+ "      ,DEPARTAMENTO =     ?"
				+ "      ,CORREO =           ?"
				+ "      ,LIBERA_PT =        ?"
				+ "      ,LIBERA_PE =        ?"
				+ "      ,COMITE =           ?"
				+ "      ,ABASTECIMIENTOS =  ?"
				+ "      ,EVAL_TECNICO =     ?"
				+ "      ,HASH =		     ?"
				+ "      ,HASHL =		     ?"
				+ "      ,SALT =		     ?"
				+ "      ,DIRECTOR_GENERAL = ?"
				+ "      ,JEFE =             ?"
				+ " WHERE USUARIO =          ?");

			st.setBoolean(1, bu.getActivo());
			st.setString(2, bu.getNombre());
			st.setString(3, bu.getDepartamento());
			st.setString(4, bu.getCorreo());
			st.setBoolean(5, bu.getLiberaPT());
			st.setBoolean(6, bu.getLiberaPE());
			st.setBoolean(7, bu.getComite());
			st.setBoolean(8, bu.getAbastecimientos());
			st.setBoolean(9, bu.getEvalTecnico());
			st.setString(10, bu.getHash());
			st.setString(11, bu.getHashl());
			st.setString(12, bu.getSalt());
			st.setBoolean(13, bu.getDirectorGeneral());
			st.setString(14, bu.getJefe());
			st.setString(15, bu.getUsuario());

			return st.executeUpdate();

		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		} finally {
			cierraConexion(conn);
		}
	}
	
}
